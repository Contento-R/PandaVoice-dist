"""Тесты механизма обновления. Запуск: python tests/test_updater.py"""
import sys
import tempfile
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import updater


def test_parse_ver():
    assert updater.parse_ver("PandaVoiceApp-v1.2.3-update.zip") == (1, 2, 3)
    assert updater.parse_ver("v10.0.1") == (10, 0, 1)
    assert updater.parse_ver("мусор.zip") is None
    assert updater.parse_ver("v1.2.10") > updater.parse_ver("v1.2.9")


def test_find_update_picks_newest():
    d = Path(tempfile.mkdtemp())
    for name in ["PandaVoiceApp-v1.0.0-windows.zip",
                 "PandaVoiceApp-v1.2.0-update.zip",
                 "PandaVoiceApp-v1.1.2-update.zip", "другое.zip"]:
        (d / name).write_bytes(b"x")
    ver, path = updater.find_update(d)
    assert ver == (1, 2, 0) and path.name == "PandaVoiceApp-v1.2.0-update.zip"
    assert updater.find_update(Path(tempfile.mkdtemp())) is None


def test_apply_zip_preserves_user_data():
    app = Path(tempfile.mkdtemp())
    updater.APP_DIR = app
    (app / "config.json").write_text('{"мои": "настройки"}', encoding="utf-8")
    (app / "history.jsonl").write_text("старая история\n", encoding="utf-8")
    (app / "main.py").write_text("старый код", encoding="utf-8")
    (app / "venv").mkdir()
    (app / "venv" / "big.bin").write_bytes(b"venv")

    z = Path(tempfile.mkdtemp()) / "PandaVoiceApp-v9.9.9-update.zip"
    with zipfile.ZipFile(z, "w") as f:
        f.writestr("main.py", "новый код")
        f.writestr("config.json", '{"дефолт": true}')       # НЕ должен затереть
        f.writestr("history.jsonl", "")                     # НЕ должен затереть
        f.writestr("venv/pwn.txt", "x")                     # НЕ должен попасть
        f.writestr("tests/test_x.py", "тест")
        f.writestr("VERSION", "v9.9.9")

    n = updater.apply_zip(z)
    assert (app / "main.py").read_text(encoding="utf-8") == "новый код"
    assert "мои" in (app / "config.json").read_text(encoding="utf-8")
    assert (app / "history.jsonl").read_text(encoding="utf-8") == "старая история\n"
    assert not (app / "venv" / "pwn.txt").exists()
    assert (app / "tests" / "test_x.py").exists()
    assert (app / "VERSION").read_text(encoding="utf-8") == "v9.9.9"
    assert n == 3  # main.py, tests/test_x.py, VERSION


def test_check_remote_disabled():
    assert updater.check_remote({"update_check": False}) is None


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов апдейтера прошли")
