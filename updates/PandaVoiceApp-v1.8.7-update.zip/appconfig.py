"""config.json: загрузка с дефолтами и сохранение."""
import json
import logging
from pathlib import Path

log = logging.getLogger("config")
APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "config.json"


def version():
    try:
        return (APP_DIR / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:
        return "v?"

DEFAULTS = {
    "hotkey": "left alt+`",           # запись: комбинация (toggle) или одиночная клавиша
    "mode": "toggle",                 # toggle | push_to_talk
    "push_to_talk_key": "f8",
    "repaste_key": "right alt+`",     # повторная вставка последнего текста
    "correct_key": "f8",              # исправить вставленный текст (F7 занят Chrome)
    "open_window_key": "left alt+p",  # открыть окно приложения
    "block_hotkeys": False,           # забирать одиночные доп. клавиши у ОС
    "double_press_interval_ms": 400,
    "debounce_ms": 500,
    "input_device": None,             # null = микрофон по умолчанию
    "model_id": "Qwen/Qwen3-ASR-0.6B-hf",
    "device": "auto",                 # auto | cpu | xpu
    "offline_mode": True,
    "max_recording_sec": 600,
    "language": "auto",          # auto | ru | en | zh | ... (подсказка модели)
    "multilingual_mode": True,   # при auto: фразы 3-12 c, каждая на своём языке
    "chunk_min_sec": 15,
    "chunk_max_sec": 30,
    "stream_min_sec": 4,         # мелкие куски = быстрый финиш; точность
    "stream_max_sec": 8,         # держит контекст; ограничивает «хвост» после стоп
    "eager_pause_sec": 0.9,      # пауза речи, по которой забираем фрагмент (сек)
    "streaming_enabled": True,   # распознавать фрагменты прямо во время записи
    "live_transcript": False,    # показывать распознанный текст во время диктовки (опц.)
    "live_fast": False,          # транскрипт чаще мелкими кусками (опц.)
    "ui_theme": "classic",       # classic | animated | obsidian — тема (опц.)
    "ui_mode": "classic",        # classic | aura — окно приложения (опц., эксп.)
    "dict_suggestions": False,   # предлагать добавлять частые слова в словарь (опц.)
    "dict_suggest_min_count": 4, # порог частоты слова для предложения
    "asr_context": "",           # подсказка модели: тематика/имена (опц.)
    "final_repass": False,       # перераспознать запись целиком после стопа (опц.)
    "num_beams": 1,              # >1 = beam search: точнее, медленнее (опц.)
    "normalize_audio": False,    # выравнивать тихий микрофон перед ASR (опц.)
    "context_chars": 300,        # сколько распознанного текста давать как контекст
    "quantize_int8": False,      # int8 быстрее, но портит качество русского
    "cpu_dtype": "auto",         # auto: bf16 на AVX512/AMX (быстрее, качество то же)
    "torch_threads": 0,          # 0 = авто (физические ядра)
    "high_priority": True,       # ABOVE_NORMAL: не ждать за фоновыми задачами
    "beeps": True,
    "beep_style": "classic",     # classic | soft — мягкие тихие сигналы (опц.)
    "restore_clipboard": True,
    "restore_clipboard_delay_sec": 1.0,
    "tokens_per_sec": 16,
    "history_enabled": True,
    "history_max_entries": 500,
    "update_check": True,        # проверять обновления при запуске
    "github_token": "",          # нужен для проверки, пока репозиторий приватный
    "setup_done": False,
}


def load():
    cfg = dict(DEFAULTS)
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg.update(json.load(f))
    except FileNotFoundError:
        pass
    except Exception:
        log.exception("config.json повреждён — использую значения по умолчанию")
    # миграция: у кого остался старый одиночный Alt (он плохо работал) —
    # перевести на комбинацию left alt+` / right alt+`
    if not cfg.get("_hotkey_v2"):
        if cfg.get("hotkey") == "alt":
            cfg["hotkey"] = "left alt+`"
        if cfg.get("repaste_key") in ("right alt", "f9"):
            cfg["repaste_key"] = "right alt+`"
        cfg["_hotkey_v2"] = True
        try:
            save(cfg)
        except Exception:
            log.exception("Не удалось сохранить миграцию хоткеев")
    return cfg


def save(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
