"""Обновление Panda Voice из скачанного архива, без переустановки.

Ищет в папке «Загрузки» самый свежий PandaVoiceApp-v*-*.zip, распаковывает
поверх папки приложения (сохраняя config.json, history.jsonl, venv, hf-cache),
доустанавливает pip-зависимости. Файлы пишет Python, поэтому метка «файл из
интернета» на них не появляется — Smart App Control обновлению не мешает.

Запуск: update.bat или кнопка «Установить обновление» в окне приложения.
"""
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

log = logging.getLogger("updater")
REPO = "Contento-R/PandaVoice"

APP_DIR = Path(__file__).resolve().parent
# что НЕ трогаем при обновлении (данные пользователя и тяжёлые артефакты)
PRESERVE = {"config.json", "history.jsonl", "app.log", "venv", "hf-cache",
            "last_recording.wav"}


def parse_ver(s):
    m = re.search(r"v(\d+)\.(\d+)\.(\d+)", str(s))
    return tuple(map(int, m.groups())) if m else None


def current_version():
    try:
        return parse_ver((APP_DIR / "VERSION").read_text(encoding="utf-8"))
    except Exception:
        return None


def _downloads_dir_win():
    """Реальная папка «Загрузки» из реестра (её можно перенести на др. диск,
    и тогда %USERPROFILE%\\Downloads уже неверен)."""
    try:
        import winreg
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders"
        ) as k:
            val, _ = winreg.QueryValueEx(
                k, "{374DE290-123F-4565-9164-39C4925E467B}")
        return Path(os.path.expandvars(val))
    except Exception:
        return None


def search_dirs(folder=None):
    """Где искать скачанный архив: если folder задан — только он; иначе
    реальные «Загрузки» + рабочий стол + домашняя папка (без дублей)."""
    if folder:
        return [Path(folder)]
    dirs = []
    if sys.platform == "win32":
        d = _downloads_dir_win()
        if d:
            dirs.append(d)
    dirs += [Path.home() / "Downloads", Path.home() / "Desktop", Path.home()]
    seen, out = set(), []
    for d in dirs:
        try:
            key = d.resolve()
        except Exception:
            key = d
        if key not in seen:
            seen.add(key)
            if d.is_dir():
                out.append(d)
    return out


def find_update(folder=None):
    best = None
    dirs = search_dirs(folder)
    for d in dirs:
        try:
            files = list(d.glob("PandaVoiceApp-v*.zip"))
        except Exception:
            continue
        for p in files:
            v = parse_ver(p.name)
            if v and (best is None or v > best[0]):
                best = (v, p)
    log.info("Поиск обновления в: %s — найдено: %s",
             [str(d) for d in dirs], best[1].name if best else "нет")
    return best


def apply_zip(zpath):
    n_files = 0
    with zipfile.ZipFile(zpath) as z:
        for name in z.namelist():
            parts = Path(name).parts
            if not parts or name.endswith("/"):
                continue
            if parts[0] in PRESERVE:
                continue
            target = APP_DIR / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(name) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)
            n_files += 1
    return n_files


def check_remote(cfg, timeout=10):
    """Есть ли на GitHub релиз новее текущей версии: (тег, url) или None.

    Для приватного репозитория нужен github_token в config.json (fine-grained
    токен с правом чтения репозитория); для публичного работает без токена.
    """
    if not cfg.get("update_check", True):
        return None
    req = urllib.request.Request(
        f"https://api.github.com/repos/{REPO}/releases/latest",
        headers={"Accept": "application/vnd.github+json",
                 "User-Agent": "PandaVoice"})
    token = (cfg.get("github_token") or "").strip()
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.load(r)
    ver = parse_ver(data.get("tag_name", ""))
    cur = current_version()
    if ver and cur and ver > cur:
        return data.get("tag_name"), data.get("html_url")
    return None


def run(folder=None):
    """Возвращает (статус, сообщение): updated | none | error."""
    cur = current_version()
    found = find_update(folder)
    if not found:
        return "error", ("В папке «Загрузки» не найден архив "
                         "PandaVoiceApp-v*.zip.\nСкачайте обновление со "
                         "страницы Releases и повторите.")
    ver, path = found
    if cur and ver <= cur:
        return "none", (f"Установлена версия v{'.'.join(map(str, cur))} — "
                        f"новее не найдено. Самый свежий архив: {path.name} "
                        f"(в {path.parent}).")
    n = apply_zip(path)
    msg = f"Обновлено до {path.name}: заменено файлов — {n}."
    # доустановить зависимости (мгновенно, если ничего не менялось)
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "-q", "-r",
             str(APP_DIR / "requirements.txt")],
            check=True, timeout=900,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:
        msg += "\nЗависимости обновить не удалось — запустите install.bat."
    return "updated", msg


if __name__ == "__main__":
    status, message = run()
    print(message)
    if status == "updated":
        print("Перезапустите Panda Voice, чтобы применить обновление.")
    sys.exit(1 if status == "error" else 0)
