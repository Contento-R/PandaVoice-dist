"""Словарь исправлений: «распознанное слово → правильное».

Practical-замена дообучению модели (fine-tuning на CPU в десктоп-приложении
нереален): пользователь правит распознанный текст, приложение запоминает
пословные замены и применяет их к каждому следующему результату.
"""
import difflib
import json
import logging
import re

from appconfig import APP_DIR

log = logging.getLogger("corrections")
PATH = APP_DIR / "corrections.json"
_WORD = re.compile(r"\w+", re.UNICODE)
_STRIP = " \t\n.,!?;:—-«»\"'()"

# короткие служебные слова (предлоги/союзы/частицы): глобальная замена
# «в»→«на» разрушительна — оба верны в большинстве фраз. Их учим ТОЛЬКО в
# паре со следующим словом (контекст), чтобы правка не портила весь текст.
_AMBIG = {
    "в", "во", "на", "с", "со", "к", "ко", "по", "о", "об", "обо", "у",
    "за", "из", "от", "ото", "до", "при", "про", "для", "над", "под",
    "перед", "между", "через", "без", "и", "а", "но", "или", "же", "бы",
    "ли", "не", "ни", "то", "как", "что", "уже", "еще", "ещё",
}


def _cap_like(src, dst):
    """Перенести регистр первой буквы src на dst."""
    return dst[0].upper() + dst[1:] if src[:1].isupper() else dst


def _norm_yo(w):
    return w.replace("ё", "е").replace("Ё", "Е")


def _form_variant(a, b):
    """Одно и то же слово в РАЗНЫХ формах (терминала/терминалу,
    использую/используй, все/всё)?

    Такие правки нельзя учить как глобальную замену: правильная форма
    зависит от падежа/лица в конкретной фразе, и подстановка испортит все
    будущие тексты (жалоба пользователя: «терминала» превращалось в
    «терминалу»). Их учим только в паре с соседним словом.

    Ошибка распознавания слова (полоникс→poloniex, меганье→мигание,
    шрифт→shift) выглядит иначе: слова расходятся уже в начале."""
    a, b = a.lower().strip(), b.lower().strip()
    if not a or not b or a == b:
        return False
    if _norm_yo(a) == _norm_yo(b):
        return True                      # различие только в ё/е
    n = 0                                # длина общей основы
    while n < min(len(a), len(b)) and a[n] == b[n]:
        n += 1
    if n >= 3 and (len(a) - n) <= 3 and (len(b) - n) <= 3:
        return True                      # общая основа, разные окончания
    return difflib.SequenceMatcher(None, a, b).ratio() >= 0.8


def load():
    try:
        with open(PATH, encoding="utf-8") as f:
            d = json.load(f)
        d = {str(k).lower(): str(v) for k, v in d.items()}
    except FileNotFoundError:
        return {}
    except Exception:
        log.exception("corrections.json повреждён")
        return {}
    # чистка мин, записанных старыми версиями: одиночная замена предлога
    # («на»→«в») или формы слова («терминала»→«терминалу») применялась ко
    # ВСЕМУ тексту и ломала его. Удаляем и переписываем файл один раз.
    poison = [k for k, v in d.items()
              if " " not in k and (k in _AMBIG or _form_variant(k, v))]
    if poison:
        for k in poison:
            d.pop(k, None)
        log.info("Удалены разрушительные замены (предлоги/формы слов): %s",
                 poison)
        save(d)
    return d


def save(d):
    try:
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2, sort_keys=True)
    except Exception:
        log.exception("Не удалось сохранить corrections.json")


def apply(text, table=None):
    """Заменить слова/пары из словаря (регистр первой буквы сохраняется).
    Ключи с пробелом — контекстные пары (напр. «в стол»→«на стол»):
    срабатывают только в этом сочетании, а не на каждом предлоге."""
    table = load() if table is None else table
    if not table or not text:
        return text
    # сперва фразы (длинные вперёд), затем одиночные слова
    for k in sorted((k for k in table if " " in k), key=len, reverse=True):
        pat = r"(?<!\w)" + r"\s+".join(re.escape(w) for w in k.split()) + r"(?!\w)"
        text = re.sub(pat, lambda m, v=table[k]: _cap_like(m.group(0), v),
                      text, flags=re.IGNORECASE)
    singles = {k: v for k, v in table.items() if " " not in k}
    if singles:
        def repl(m):
            r = singles.get(m.group(0).lower())
            return _cap_like(m.group(0), r) if r else m.group(0)
        text = _WORD.sub(repl, text)
    return text


def clear():
    """Стереть весь словарь замен (если накопился мусор от больших правок)."""
    try:
        PATH.unlink(missing_ok=True)
        log.info("Словарь замен очищен")
    except OSError:
        log.exception("Не удалось очистить словарь замен")


def vocab(limit=40):
    """Содержательные слова из правок — подсказка модели (hotwords) в
    системном промте Qwen3-ASR. Короткие предлоги/пары не берём."""
    words = set()
    for v in load().values():
        for w in v.split():
            if len(w) > 2:
                words.add(w)
    return sorted(words)[:limit]


def learn(old, new):
    """Сравнить старый и новый текст пословно, запомнить замены.
    Возвращает словарь добавленных пар. Предлоги/союзы (в/на/с/…) учим
    только в паре со следующим словом — иначе глобальная замена испортит
    весь будущий текст."""
    ow = [w.strip(_STRIP) for w in old.split()]
    nw = [w.strip(_STRIP) for w in new.split()]
    sm = difflib.SequenceMatcher(
        None, [w.lower() for w in ow], [w.lower() for w in nw])
    pairs = {}
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        # заменённые участки одинаковой длины — сопоставляем 1:1
        if tag != "replace" or (i2 - i1) != (j2 - j1):
            continue
        for oi, nj in zip(range(i1, i2), range(j1, j2)):
            o, n = ow[oi], nw[nj]
            if not (o and n and o.lower() != n.lower() and _WORD.fullmatch(o)):
                continue
            # предлоги/союзы и разные ФОРМЫ одного слова — только в паре
            # с соседним словом: глобальная замена сломала бы будущий текст
            if o.lower() in _AMBIG or _form_variant(o, n):
                if (oi + 1 < len(ow) and nj + 1 < len(nw)
                        and ow[oi + 1].lower() == nw[nj + 1].lower()
                        and _WORD.fullmatch(ow[oi + 1])):
                    pairs[o.lower() + " " + ow[oi + 1].lower()] = \
                        n + " " + nw[nj + 1]
                elif (oi > 0 and nj > 0
                      and ow[oi - 1].lower() == nw[nj - 1].lower()
                      and _WORD.fullmatch(ow[oi - 1])):
                    # соседа справа нет (конец фразы) — берём слева
                    pairs[ow[oi - 1].lower() + " " + o.lower()] = \
                        nw[nj - 1] + " " + n
            else:
                pairs[o.lower()] = n
    if pairs:
        table = load()
        table.update(pairs)
        save(table)
        log.info("Выучены исправления: %s", pairs)
    return pairs
