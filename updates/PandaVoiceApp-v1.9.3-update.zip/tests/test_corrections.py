"""Тесты словаря исправлений. Запуск: python tests/test_corrections.py"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import corrections


def _tmp():
    corrections.PATH = Path(tempfile.mkdtemp()) / "corrections.json"


def test_apply_basic():
    _tmp()
    corrections.save({"войс": "Voice", "цекс": "CEX"})
    assert corrections.apply("это панда войс") == "это панда Voice"
    # регистр первой буквы источника переносится
    assert corrections.apply("Войс работает") == "Voice работает"
    assert corrections.apply("на бирже Цекс") == "на бирже CEX"


def test_apply_no_table():
    _tmp()
    assert corrections.apply("любой текст") == "любой текст"


def test_learn_word_replacements():
    _tmp()
    pairs = corrections.learn(
        "у нас есть пулы по блокчейну робин хун",
        "у нас есть пулы по блокчейну робин гуд")
    assert pairs == {"хун": "гуд"}
    # выученное сразу применяется
    assert corrections.apply("робин хун") == "робин гуд"


def test_learn_multiple():
    _tmp()
    pairs = corrections.learn("это цекс и декс терминал",
                              "это CEX и DEX терминал")
    assert pairs == {"цекс": "CEX", "декс": "DEX"}


def test_learn_ignores_length_mismatch():
    _tmp()
    # вставка/удаление слов не порождает ложных пар
    pairs = corrections.learn("привет мир", "привет прекрасный мир")
    assert pairs == {}


def test_apply_preserves_untouched():
    _tmp()
    corrections.save({"хун": "гуд"})
    assert corrections.apply("робин хундай хун") == "робин хундай гуд"  # целое слово


def test_preposition_learned_as_context_pair():
    _tmp()
    # правка предлога учится ТОЛЬКО в паре со следующим словом
    pairs = corrections.learn("я положил книгу в стол",
                              "я положил книгу на стол")
    assert pairs == {"в стол": "на стол"}
    # применяется в этом сочетании...
    assert corrections.apply("положил в стол") == "положил на стол"
    # ...но НЕ трогает другие «в» — глобальной замены нет
    assert corrections.apply("живу в москве в центре") == "живу в москве в центре"


def test_preposition_bigram_word_boundary():
    _tmp()
    corrections.save({"в стол": "на стол"})
    # «в столе» (другое слово) не задевается
    assert corrections.apply("книга в столе") == "книга в столе"
    # регистр первой буквы сохраняется
    assert corrections.apply("В стол posit, положил") == "На стол posit, положил"


def test_form_variant_detects_inflections():
    # разные ФОРМЫ одного слова — глобально учить нельзя
    for a, b in [("терминала", "терминалу"), ("использую", "используй"),
                 ("все", "всё"), ("сканера", "сканеров"),
                 ("документацию", "документации"), ("главное", "главный"),
                 ("перестался", "перестал")]:
        assert corrections._form_variant(a, b), (a, b)
    # ошибки распознавания слова — учить МОЖНО
    for a, b in [("полоникс", "poloniex"), ("шрифт", "shift"),
                 ("меганье", "мигание"), ("цекс", "CEX"), ("мен", "main"),
                 ("войс", "Voice")]:
        assert not corrections._form_variant(a, b), (a, b)


def test_inflection_learned_only_with_context():
    _tmp()
    pairs = corrections.learn("обнови состояние терминалу сейчас",
                              "обнови состояние терминала сейчас")
    assert pairs == {"терминалу сейчас": "терминала сейчас"}, pairs
    # в этом сочетании правится...
    assert corrections.apply("терминалу сейчас") == "терминала сейчас"
    # ...а другие падежи не ломаются
    assert corrections.apply("доступ к терминалу открыт") == \
        "доступ к терминалу открыт"


def test_inflection_at_phrase_end_uses_left_neighbour():
    _tmp()
    pairs = corrections.learn("проверь состояние терминалу",
                              "проверь состояние терминала")
    assert pairs == {"состояние терминалу": "состояние терминала"}, pairs


def test_word_error_still_learned_globally():
    _tmp()
    pairs = corrections.learn("смотрю на полоникс сегодня",
                              "смотрю на poloniex сегодня")
    assert pairs == {"полоникс": "poloniex"}
    assert corrections.apply("открой полоникс") == "открой poloniex"


def test_load_cleans_old_inflection_poison():
    _tmp()
    corrections.save({"терминала": "терминалу", "на": "в",
                      "полоникс": "poloniex", "состояние терминалу":
                      "состояние терминала"})
    tbl = corrections.load()
    assert "терминала" not in tbl and "на" not in tbl      # мины убраны
    assert tbl["полоникс"] == "poloniex"                   # полезное цело
    assert tbl["состояние терминалу"] == "состояние терминала"
    assert corrections.apply("состояние терминала") == "состояние терминала"


def test_lone_preposition_not_learned():
    _tmp()
    # без надёжного контекста (следующее слово тоже изменилось) — не учим
    pairs = corrections.learn("он был в кафе", "он был на пляже")
    assert "в" not in pairs and all(" " in k or k != "в" for k in pairs)


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов исправлений прошли")
