"""Тесты склейки фрагментов с пунктуацией. Запуск: python tests/test_textproc.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from textproc import _strip_seam_period, join_texts


def test_empty_and_single():
    assert join_texts([]) == ""
    assert join_texts(["", "  ", None]) == ""
    assert join_texts(["привет мир"]) == "Привет мир."
    assert join_texts(["Привет, мир!"]) == "Привет, мир!"


def test_no_dot_added_between_pieces():
    # пауза для обдумывания не завершает предложение — точки на стыке нет
    got = join_texts(["я хочу увидеть как ты распознаешь",
                      "и как долго я могу говорить"])
    assert got == "Я хочу увидеть как ты распознаешь и как долго я могу говорить."


def test_seam_period_stripped():
    # точка в конце промежуточного фрагмента — «привычка» модели, убираем
    got = join_texts(["Смотри, сейчас я попробую наговорить текст.",
                      "что из этого выйдет?"])
    assert got == "Смотри, сейчас я попробую наговорить текст что из этого выйдет?"


def test_question_kept_at_seam():
    # «?» — настоящая интонация: сохраняется, следующий кусок с заглавной
    got = join_texts(["Ты меня слышишь?", "отлично, продолжаем"])
    assert got == "Ты меня слышишь? Отлично, продолжаем."


def test_inner_periods_preserved():
    # точки ВНУТРИ фрагмента модель ставит с контекстом — не трогаем
    got = join_texts(["Первое предложение. Второе началось", "и продолжилось"])
    assert got == "Первое предложение. Второе началось и продолжилось."


def test_ellipsis_kept_at_seam():
    got = join_texts(["Ну не знаю...", "может быть"])
    assert got == "Ну не знаю... Может быть."


def test_comma_ending_continues_phrase():
    got = join_texts(["Соответственно, я хочу,", "Чтобы ты внимательно слушал"])
    assert got == "Соответственно, я хочу, чтобы ты внимательно слушал."


def test_continuation_lowercased():
    got = join_texts(["  первый   кусок ", "Второй кусок"])
    assert got == "Первый кусок второй кусок."


def test_seam_periods_stripped_in_chain():
    got = join_texts(["Первое предложение.", "второе продолжается",
                      "и ещё кусок"])
    assert got == "Первое предложение второе продолжается и ещё кусок."


def test_pause_cut_keeps_sentence_period():
    # разрез по настоящей паузе речи = конец предложения: точку сохраняем
    got = join_texts(["Обнови документацию в репозитории.",
                      "мне нужно, чтобы данные приходили без задержек"],
                     at_pause=[True, True])
    assert got == ("Обнови документацию в репозитории. Мне нужно, чтобы "
                   "данные приходили без задержек.")


def test_forced_cut_still_strips_period():
    # вынужденный разрез посреди фразы — точка модели ложная, снимаем
    got = join_texts(["Обнови документацию в репозитории.",
                      "мне нужно, чтобы данные приходили"],
                     at_pause=[False, True])
    assert got == ("Обнови документацию в репозитории мне нужно, чтобы "
                   "данные приходили.")


def test_mixed_cuts():
    got = join_texts(["Первый кусок.", "второй кусок.", "третий кусок"],
                     at_pause=[False, True, True])
    assert got == "Первый кусок второй кусок. Третий кусок."


def test_without_flags_behaves_as_before():
    got = join_texts(["Первое предложение.", "второе продолжается"])
    assert got == "Первое предложение второе продолжается."


def test_strip_seam_period_helper():
    assert _strip_seam_period("слово.") == "слово"
    assert _strip_seam_period("слово. ") == "слово"
    assert _strip_seam_period("вопрос?") == "вопрос?"
    assert _strip_seam_period("стой!") == "стой!"
    assert _strip_seam_period("хм…") == "хм…"
    assert _strip_seam_period("хм...") == "хм..."
    assert _strip_seam_period("слово") == "слово"


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов склейки прошли")
