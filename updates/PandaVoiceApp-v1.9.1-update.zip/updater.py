"""Обновление Panda Voice из скачанного архива, без переустановки.

Ищет в папке «Загрузки» самый свежий PandaVoiceApp-v*-*.zip, распаковывает
поверх папки приложения (сохраняя config.json, history.jsonl, venv, hf-cache),
доустанавливает pip-зависимости. Файлы пишет Python, поэтому метка «файл из
интернета» на них не появляется — Smart App Control обновлению не мешает.

Запуск: update.bat или кнопка «Установить обновление» в окне приложения.
"""
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

log = logging.getLogger("updater")
REPO = "Contento-R/PandaVoice"
# Публичный репозиторий раздачи: приложение читает оттуда манифест latest.json
# и качает архив обновления. Публичный — значит токен не нужен ни для чего.
DIST_REPO = "Contento-R/PandaVoice-dist"
MANIFEST = "latest.json"

APP_DIR = Path(__file__).resolve().parent
# что НЕ трогаем при обновлении (данные пользователя и тяжёлые артефакты)
PRESERVE = {"config.json", "history.jsonl", "app.log", "venv", "hf-cache",
            "last_recording.wav"}


def parse_ver(s):
    m = re.search(r"v(\d+)\.(\d+)\.(\d+)", str(s))
    return tuple(map(int, m.groups())) if m else None


def current_version():
    try:
        return parse_ver((APP_DIR / "VERSION").read_text(encoding="utf-8"))
    except Exception:
        return None


def _downloads_dir_win():
    """Реальная папка «Загрузки» из реестра (её можно перенести на др. диск,
    и тогда %USERPROFILE%\\Downloads уже неверен)."""
    try:
        import winreg
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders"
        ) as k:
            val, _ = winreg.QueryValueEx(
                k, "{374DE290-123F-4565-9164-39C4925E467B}")
        return Path(os.path.expandvars(val))
    except Exception:
        return None


def search_dirs(folder=None):
    """Где искать скачанный архив: если folder задан — только он; иначе
    реальные «Загрузки» + рабочий стол + домашняя папка (без дублей)."""
    if folder:
        return [Path(folder)]
    dirs = []
    if sys.platform == "win32":
        d = _downloads_dir_win()
        if d:
            dirs.append(d)
    dirs += [Path.home() / "Downloads", Path.home() / "Desktop", Path.home()]
    seen, out = set(), []
    for d in dirs:
        try:
            key = d.resolve()
        except Exception:
            key = d
        if key not in seen:
            seen.add(key)
            if d.is_dir():
                out.append(d)
    return out


def find_update(folder=None):
    best = None
    dirs = search_dirs(folder)
    for d in dirs:
        try:
            files = list(d.glob("PandaVoiceApp-v*.zip"))
        except Exception:
            continue
        for p in files:
            v = parse_ver(p.name)
            if v and (best is None or v > best[0]):
                best = (v, p)
    log.info("Поиск обновления в: %s — найдено: %s",
             [str(d) for d in dirs], best[1].name if best else "нет")
    return best


def apply_zip(zpath):
    n_files = 0
    with zipfile.ZipFile(zpath) as z:
        for name in z.namelist():
            parts = Path(name).parts
            if not parts or name.endswith("/"):
                continue
            if parts[0] in PRESERVE:
                continue
            target = APP_DIR / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(name) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)
            n_files += 1
    return n_files


def manifest_url(cfg):
    repo = (cfg.get("update_repo") or DIST_REPO).strip()
    return f"https://raw.githubusercontent.com/{repo}/main/{MANIFEST}"


def fetch_manifest(cfg, timeout=10):
    """Манифест обновлений из публичного репозитория раздачи (dict).

    Формат latest.json: {"version": "v1.8.8", "url": "...update.zip",
    "sha256": "...", "notes": "что нового"}. Токен не нужен — репозиторий
    публичный; сеть недоступна/файла нет — исключение (обрабатывает вызывающий).
    """
    # raw.githubusercontent кеширует ответ на CDN (~5 минут) — добавляем
    # уникальный параметр, иначе новая версия «появляется» с задержкой
    url = f"{manifest_url(cfg)}?t={int(time.time())}"
    req = urllib.request.Request(
        url, headers={"User-Agent": "PandaVoice", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def check_remote(cfg, timeout=10):
    """Есть ли обновление новее текущей версии: (версия, манифест) или None."""
    if not cfg.get("update_check", True):
        return None
    data = fetch_manifest(cfg, timeout=timeout)
    ver = parse_ver(data.get("version", ""))
    cur = current_version()
    if ver and cur and ver > cur:
        return data.get("version"), data
    return None


def download_update(info, dest_dir=None, timeout=300, progress=None):
    """Скачать архив обновления по манифесту. Возвращает путь к файлу.

    Пишем во временный файл и переименовываем — оборванная закачка не
    выглядит как готовый архив. sha256 из манифеста (если есть) проверяем:
    битый/подменённый файл до установки не дойдёт."""
    url = info.get("url")
    if not url:
        raise ValueError("в манифесте нет ссылки на архив")
    name = info.get("name") or url.rsplit("/", 1)[-1]
    dest_dir = Path(dest_dir) if dest_dir else (
        _downloads_dir_win() or (Path.home() / "Downloads"))
    dest_dir.mkdir(parents=True, exist_ok=True)
    target = dest_dir / name
    tmp = target.with_name(target.name + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "PandaVoice"})
    h = hashlib.sha256()
    log.info("Качаю обновление: %s -> %s", url, target)
    with urllib.request.urlopen(req, timeout=timeout) as r, open(tmp, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = r.read(65536)
            if not chunk:
                break
            f.write(chunk)
            h.update(chunk)
            done += len(chunk)
            if progress and total:
                try:
                    progress(done, total)
                except Exception:
                    pass
    want = (info.get("sha256") or "").strip().lower()
    if want and h.hexdigest() != want:
        tmp.unlink(missing_ok=True)
        raise ValueError("контрольная сумма архива не совпала — файл повреждён")
    tmp.replace(target)
    log.info("Обновление скачано: %s (%d байт)", target, done)
    return target


def run(folder=None):
    """Возвращает (статус, сообщение): updated | none | error."""
    cur = current_version()
    found = find_update(folder)
    if not found:
        return "error", ("В папке «Загрузки» не найден архив "
                         "PandaVoiceApp-v*.zip.\nСкачайте обновление со "
                         "страницы Releases и повторите.")
    ver, path = found
    if cur and ver <= cur:
        return "none", (f"Установлена версия v{'.'.join(map(str, cur))} — "
                        f"новее не найдено. Самый свежий архив: {path.name} "
                        f"(в {path.parent}).")
    n = apply_zip(path)
    msg = f"Обновлено до {path.name}: заменено файлов — {n}."
    # доустановить зависимости (мгновенно, если ничего не менялось)
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "-q", "-r",
             str(APP_DIR / "requirements.txt")],
            check=True, timeout=900,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:
        msg += "\nЗависимости обновить не удалось — запустите install.bat."
    return "updated", msg


if __name__ == "__main__":
    status, message = run()
    print(message)
    if status == "updated":
        print("Перезапустите Panda Voice, чтобы применить обновление.")
    sys.exit(1 if status == "error" else 0)
