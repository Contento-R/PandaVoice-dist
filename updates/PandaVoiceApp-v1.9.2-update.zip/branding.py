"""Panda Voice: иконка приложения (Pillow) — микрофон, цвет капсулы = состояние,
маленькая голова панды в правом нижнем углу. Общая для трея, окна, ярлыков."""
from PIL import Image, ImageDraw

APP_NAME = "Panda Voice"
_DEFAULT = (110, 110, 115)  # цвет капсулы без состояния


def app_icon(state_color=None, size=64):
    s = size / 64.0
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    def xy(*coords):
        return [c * s for c in coords]

    cap = (state_color or _DEFAULT) + (255,)
    grey = (200, 200, 205, 255)
    # микрофон: капсула, держатель-дужка, ножка, база
    d.rounded_rectangle(xy(22, 4, 42, 34), radius=10 * s, fill=cap,
                        outline=(255, 255, 255, 90), width=max(1, int(1.5 * s)))
    d.line(xy(27, 12, 37, 12), fill=(255, 255, 255, 120), width=max(1, int(2 * s)))
    d.arc(xy(14, 14, 50, 44), 0, 180, fill=grey, width=max(2, int(4 * s)))
    d.line(xy(32, 44, 32, 52), fill=grey, width=max(2, int(4 * s)))
    d.line(xy(22, 53, 42, 53), fill=grey, width=max(2, int(4 * s)))
    # маленькая панда в правом нижнем углу
    px0, py0, pw = 40, 40, 22  # квадрат панды
    black = (25, 25, 28, 255)
    white = (248, 248, 248, 255)
    d.ellipse(xy(px0, py0 + 3, px0 + 7, py0 + 10), fill=black)            # уши
    d.ellipse(xy(px0 + pw - 7, py0 + 3, px0 + pw, py0 + 10), fill=black)
    d.ellipse(xy(px0 + 1, py0 + 5, px0 + pw - 1, py0 + pw), fill=white)   # морда
    d.ellipse(xy(px0 + 4, py0 + 9, px0 + 9, py0 + 16), fill=black)        # глаза-пятна
    d.ellipse(xy(px0 + pw - 9, py0 + 9, px0 + pw - 4, py0 + 16), fill=black)
    d.ellipse(xy(px0 + 9, py0 + 15, px0 + 13, py0 + 19), fill=black)      # нос
    return img


# обратная совместимость со старыми вызовами
panda_icon = app_icon


def save_ico(path):
    """panda.ico для ярлыков Windows."""
    app_icon(size=256).save(path, format="ICO",
                            sizes=[(16, 16), (32, 32), (48, 48), (256, 256)])


def save_png(path, size=128):
    """panda.png для .desktop-ярлыков Linux."""
    app_icon(size=size).save(path, format="PNG")
