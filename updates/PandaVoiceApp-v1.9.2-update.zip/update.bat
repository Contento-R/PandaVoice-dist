@echo off
rem Update Panda Voice from a downloaded PandaVoiceApp-v*.zip in Downloads
cd /d "%~dp0"
"venv\Scripts\python.exe" updater.py
pause
