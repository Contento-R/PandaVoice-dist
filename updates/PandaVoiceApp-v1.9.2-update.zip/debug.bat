@echo off
rem Start with a visible console - for troubleshooting
cd /d "%~dp0"
"venv\Scripts\python.exe" main.py
pause
