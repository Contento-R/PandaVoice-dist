"""Настройка микрофона в окне (запускается в venv, где есть sounddevice).

Открывается установщиком (--first-run), при первом запуске приложения и по
команде `main.py --setup`. Заменяет консольный мастер (setup_wizard остаётся
фолбэком без tkinter).
"""
import logging
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

import numpy as np

import appconfig

log = logging.getLogger("setup_gui")
SR = 16000


class SetupWindow:
    def __init__(self, cfg, first_run=False):
        self.cfg = cfg
        self.first_run = first_run
        self.audio = None
        self.rec = None
        self.root = tk.Tk()
        self.root.title("Panda Voice — настройка микрофона")
        self.root.geometry("520x360")
        self.root.resizable(False, False)
        try:
            from PIL import ImageTk
            from branding import panda_icon
            self._icon = ImageTk.PhotoImage(panda_icon(size=64))
            self.root.iconphoto(True, self._icon)
        except Exception:
            pass

        pad = {"padx": 14}
        ttk.Label(self.root, text="Настройка микрофона",
                  font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(12, 0), **pad)
        ttk.Label(self.root, foreground="#666", text=(
            "Выберите микрофон, запишите пробу и прослушайте её.")).pack(
            anchor="w", **pad)

        row = ttk.Frame(self.root)
        row.pack(fill="x", pady=(10, 4), **pad)
        ttk.Label(row, text="Микрофон:").pack(side="left")
        self.v_device = tk.StringVar()
        self.box = ttk.Combobox(row, textvariable=self.v_device,
                                state="readonly", width=44,
                                values=self._devices())
        self.box.pack(side="left", padx=(8, 0), fill="x", expand=True)
        self.box.current(0)

        row2 = ttk.Frame(self.root)
        row2.pack(fill="x", pady=6, **pad)
        self.rec_btn = ttk.Button(row2, text="Записать 3 секунды",
                                  command=self._record)
        self.rec_btn.pack(side="left")
        self.play_btn = ttk.Button(row2, text="Прослушать", state="disabled",
                                   command=self._play)
        self.play_btn.pack(side="left", padx=8)

        ttk.Label(self.root, text="Уровень:").pack(anchor="w", **pad)
        self.level = ttk.Progressbar(self.root, maximum=1.0)
        self.level.pack(fill="x", **pad)
        self.status = tk.StringVar(value="Скажите что-нибудь после нажатия «Записать».")
        ttk.Label(self.root, textvariable=self.status,
                  foreground="#666").pack(anchor="w", pady=(4, 8), **pad)

        self.v_autostart = tk.BooleanVar(value=self._autostart_state())
        ttk.Checkbutton(self.root, text="Запускать вместе с Windows (автозагрузка)",
                        variable=self.v_autostart).pack(anchor="w", **pad)
        self.v_launch = tk.BooleanVar(value=first_run)
        if first_run:
            ttk.Checkbutton(self.root, text="Запустить Panda Voice после закрытия",
                            variable=self.v_launch).pack(anchor="w", **pad)

        ttk.Button(self.root, text="Сохранить и закрыть",
                   command=self._save).pack(side="bottom", pady=12)

    # --- устройства ---

    def _devices(self):
        out = ["По умолчанию"]
        try:
            import sounddevice as sd
            for i, d in enumerate(sd.query_devices()):
                if d["max_input_channels"] > 0:
                    out.append(f"{i}: {d['name']}")
        except Exception:
            log.exception("Список микрофонов недоступен")
        return out

    def _picked_device(self):
        v = self.v_device.get()
        if not v or v.startswith("По умолчанию"):
            return None
        try:
            return int(v.split(":")[0])
        except ValueError:
            return None

    def _autostart_state(self):
        try:
            import setup_wizard
            return setup_wizard.autostart_enabled()
        except Exception:
            return False

    # --- запись/воспроизведение ---

    def _record(self):
        from recorder import Recorder
        try:
            self.rec = Recorder(self._picked_device())
            self.rec.start()
        except Exception as e:
            self.status.set(f"Не удалось начать запись: {e}")
            return
        self.rec_btn.configure(state="disabled")
        self.play_btn.configure(state="disabled")
        self.status.set("Идёт запись — говорите...")
        self._tick_level()
        self.root.after(3000, self._stop_record)

    def _tick_level(self):
        if self.rec and self.rec.recording:
            hist = list(self.rec.level_history)
            self.level["value"] = min(1.0, (hist[-1] if hist else 0) * 6)
            self.root.after(100, self._tick_level)

    def _stop_record(self):
        if not self.rec:
            return
        self.audio = self.rec.stop()
        self.rec = None
        peak = float(np.abs(self.audio).max()) if self.audio.size else 0.0
        self.level["value"] = 0
        self.rec_btn.configure(state="normal")
        if peak < 0.01:
            self.status.set("Очень тихо! Проверьте микрофон или выберите другой.")
        else:
            self.play_btn.configure(state="normal")
            self.status.set(f"Записано (пик {peak:.0%}). Нажмите «Прослушать».")

    def _play(self):
        def run():
            try:
                import sounddevice as sd
                sd.play(self.audio, SR)
                sd.wait()
            except Exception:
                log.exception("Воспроизведение не удалось")
        threading.Thread(target=run, daemon=True).start()

    # --- сохранение ---

    def _save(self):
        self.cfg["input_device"] = self._picked_device()
        self.cfg["setup_done"] = True
        appconfig.save(self.cfg)
        try:
            import setup_wizard
            if self.v_autostart.get() != setup_wizard.autostart_enabled():
                if self.v_autostart.get():
                    setup_wizard.enable_autostart()
                else:
                    setup_wizard.disable_autostart()
        except Exception:
            log.exception("Автозагрузка не изменена")
            messagebox.showwarning("Panda Voice",
                                   "Автозагрузку изменить не удалось — см. app.log")
        if self.first_run and self.v_launch.get():
            import subprocess
            py = sys.executable
            if sys.platform == "win32":
                py = str(Path(py).with_name("pythonw.exe"))
            subprocess.Popen([py, str(appconfig.APP_DIR / "main.py")],
                             cwd=appconfig.APP_DIR)
        self.root.destroy()

    def run(self):
        self.root.mainloop()


def run(cfg, first_run=False):
    SetupWindow(cfg, first_run=first_run).run()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    cfg = appconfig.load()
    run(cfg, first_run="--first-run" in sys.argv)
