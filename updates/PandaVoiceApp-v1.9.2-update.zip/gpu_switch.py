"""Переключение torch между CPU и Intel Arc (XPU) — прямо из приложения.

Скачивает XPU-сборку torch с официального индекса PyTorch и проверяет
доступность GPU. Всё в venv приложения; при неудаче — откат на CPU.
"""
import logging
import subprocess
import sys
from pathlib import Path

log = logging.getLogger("gpu")
APP_DIR = Path(__file__).resolve().parent
XPU_INDEX = "https://download.pytorch.org/whl/xpu"
_NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _pip(*args, timeout=1800):
    return subprocess.run([sys.executable, "-m", "pip", *args],
                          capture_output=True, text=True, timeout=timeout,
                          encoding="utf-8", errors="replace",
                          creationflags=_NOWIN)


def probe_xpu():
    """(доступен?, текст) — есть ли рабочий XPU в текущей сборке torch."""
    r = subprocess.run(
        [sys.executable, "-c",
         "import torch;print(torch.__version__);"
         "print(hasattr(torch,'xpu') and torch.xpu.is_available())"],
        capture_output=True, text=True, timeout=120,
        encoding="utf-8", errors="replace", creationflags=_NOWIN)
    out = (r.stdout or "").strip().splitlines()
    ok = len(out) > 1 and out[1].strip() == "True"
    return ok, (r.stdout or "") + (r.stderr or "")


def switch(to_xpu: bool):
    """Переставить torch на XPU или CPU. Возвращает (успех, сообщение)."""
    log.info("Переключаю torch на %s", "XPU" if to_xpu else "CPU")
    u = _pip("uninstall", "-y", "torch")
    if u.returncode != 0:
        return False, "Не удалось удалить старый torch:\n" + u.stderr[-400:]
    if to_xpu:
        i = _pip("install", "torch", "--index-url", XPU_INDEX)
    else:
        i = _pip("install", "torch")
    if i.returncode != 0:
        _pip("install", "torch")  # аварийный откат на CPU
        return False, ("Не удалось поставить нужную сборку torch — вернул CPU:\n"
                       + i.stderr[-400:])
    if to_xpu:
        ok, info = probe_xpu()
        if not ok:
            return False, ("XPU-сборка установлена, но видеокарта недоступна.\n"
                           "Обновите драйвер Intel Graphics (32.0.101.6739+) и "
                           "включите Resizable BAR в BIOS.\n\n" + info[-400:])
        return True, (
            "Intel Arc (XPU) включён. Приложение перезапустится.\n\n"
            "ВАЖНО: на начальных видеокартах Arc (например A380) распознавание "
            "может оказаться МЕДЛЕННЕЕ, чем на быстром процессоре — "
            "авторегрессионное декодирование плохо ложится на слабый GPU. "
            "Сравните время «Распознано за … c» в «Журнале» до и после. "
            "Если стало дольше — нажмите «Вернуть CPU».")
    return True, "Возвращена CPU-сборка torch. Приложение перезапустится."
