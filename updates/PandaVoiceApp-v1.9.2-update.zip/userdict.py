"""Пользовательская библиотека слов: userdict.json рядом с приложением.

В отличие от corrections.json (замены «распознанное → правильное»), здесь
лежат просто ВЕРНЫЕ формы специфических терминов (крипто и т.п.). Они
подсказываются модели распознавания как hotwords — она узнаёт их сразу,
даже без предыдущей ошибки. Плюс приложение может само предложить добавить
часто встречающееся специфическое слово (по истории диктовок).

Всё опционально и не разрушительно: файла нет / список пуст — поведение
приложения не меняется. Формат:
    {"terms": ["CEX", "стейкинг", ...], "dismissed": ["слово", ...]}
terms — форма сохраняется как ввёл пользователь (регистр важен: CEX≠cex);
dismissed — отклонённые предложения (в нижнем регистре), чтобы не повторять.
"""
import json
import logging
import os
import re
from collections import Counter

from appconfig import APP_DIR

log = logging.getLogger("userdict")
PATH = APP_DIR / "userdict.json"
# слова из букв (Unicode), без цифр/подчёркиваний — работает для кириллицы
_WORD = re.compile(r"[^\W\d_]+", re.UNICODE)


def _empty():
    return {"terms": [], "dismissed": []}


def load():
    try:
        with open(PATH, encoding="utf-8") as f:
            d = json.load(f)
        if not isinstance(d, dict):
            return _empty()
        # строгая проверка типов: строка вместо списка иначе рассыпалась
        # бы на отдельные буквы при итерации
        raw_t = d.get("terms")
        raw_d = d.get("dismissed")
        raw_t = raw_t if isinstance(raw_t, list) else []
        raw_d = raw_d if isinstance(raw_d, list) else []
        terms = [str(w).strip() for w in raw_t if str(w).strip()]
        dismissed = [str(w).strip().lower() for w in raw_d if str(w).strip()]
        return {"terms": terms, "dismissed": dismissed}
    except FileNotFoundError:
        return _empty()
    except Exception:
        log.exception("userdict.json повреждён — начинаю с пустого словаря")
        return _empty()


def save(d):
    try:
        tmp = PATH.with_name(PATH.name + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2, sort_keys=True)
        os.replace(tmp, PATH)  # атомарно: обрыв записи не портит библиотеку
    except Exception:
        log.exception("Не удалось сохранить userdict.json")


def terms():
    """Слова библиотеки — уходят модели как hotwords."""
    return load()["terms"]


def add(word):
    """Добавить термин (регистр сохраняется). Дубли — без учёта регистра.
    Если слово было отклонено как предложение — снимаем отметку."""
    word = str(word).strip()
    if not word:
        return
    d = load()
    low = word.lower()
    if not any(t.lower() == low for t in d["terms"]):
        d["terms"].append(word)
    d["dismissed"] = [w for w in d["dismissed"] if w != low]
    save(d)


def add_many(text):
    """Импорт списка: разделители — переводы строк, запятые, точки с
    запятой, табы. Термин может быть фразой из нескольких слов. Дубли
    (без учёта регистра) пропускаются. Возвращает число добавленных."""
    import re as _re
    d = load()
    have = {t.lower() for t in d["terms"]}
    added = 0
    for raw in _re.split(r"[\n,;\t]+", str(text or "")):
        w = raw.strip(" \t\r.–—-•·")
        if not w or w.lower() in have:
            continue
        d["terms"].append(w)
        have.add(w.lower())
        d["dismissed"] = [x for x in d["dismissed"] if x != w.lower()]
        added += 1
    if added:
        save(d)
        log.info("Импортировано терминов: %d", added)
    return added


def remove(word):
    low = str(word).strip().lower()
    d = load()
    d["terms"] = [t for t in d["terms"] if t.lower() != low]
    save(d)


def dismiss(word):
    """Больше не предлагать это слово."""
    low = str(word).strip().lower()
    if not low:
        return
    d = load()
    if low not in d["dismissed"]:
        d["dismissed"].append(low)
    save(d)


def suggest(entries, min_count=4, min_len=4, limit=10, extra_known=()):
    """Кандидаты в библиотеку: частые специфические слова из истории.

    entries — записи истории (dict с полем 'text'). Возвращает список пар
    (слово, сколько_раз) по убыванию частоты, исключая уже известные слова
    (библиотека, отклонённые, extra_known — например словарь исправлений).
    Слово показывается в самой частой его форме (CEX, а не cex)."""
    d = load()
    known = {t.lower() for t in d["terms"]} | set(d["dismissed"])
    known |= {str(w).strip().lower() for w in extra_known if str(w).strip()}
    forms, keys = Counter(), Counter()
    for e in entries:
        for w in _WORD.findall(str(e.get("text") or "")):
            if len(w) < min_len:
                continue
            forms[w] += 1
            keys[w.lower()] += 1
    out = []
    for low, cnt in keys.most_common():
        if cnt < min_count or low in known:
            continue
        # самая частая форма слова: CEX важнее cex
        best = max((f for f in forms if f.lower() == low),
                   key=lambda f: forms[f])
        out.append((best, cnt))
        if len(out) >= limit:
            break
    return out
