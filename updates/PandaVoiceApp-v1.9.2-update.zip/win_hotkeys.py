"""Глобальные хоткеи (Windows) на scan-кодах — независимо от раскладки.

Поддерживает:
- КОМБИНАЦИЮ модификатор+клавиша ("left alt+`"): для записи — toggle
  (нажал — старт, нажал ещё — стоп); для повторной вставки — по нажатию;
- одиночную клавишу (toggle через hotkey_fsm: 2 тапа старт, 1 тап стоп);
- push-to-talk (запись, пока зажата клавиша).

Клавиша `` ` `` (слева от 1) ловится по scan-коду 41 — одинаково на любой
раскладке (на русской это «ё»). Комбинация Alt+клавиша, в отличие от
одиночного Alt, НЕ активирует меню окна — фокус остаётся в поле ввода.
"""
import ctypes
import logging
import threading
import time

import keyboard

import hotkey_fsm as fsm_mod

log = logging.getLogger("hotkeys")

GRAVE_SCAN = 41  # клавиша ` / ~ / ё — один scan-код во всех раскладках

# scan-коды букв/цифр/знаков QWERTY: комбинации ловятся НЕЗАВИСИМО от
# раскладки (на русской P приходит как «з», но scan-код тот же — 25)
_SCAN = {c: i for i, c in enumerate("1234567890-=", start=2)}
_SCAN.update({c: i for i, c in enumerate("qwertyuiop[]", start=16)})
_SCAN.update({c: i for i, c in enumerate("asdfghjkl;'`", start=30)})
_SCAN.update({c: i for i, c in enumerate("\\zxcvbnm,./", start=43)})


def _neutralize_alt():
    try:
        ctypes.windll.user32.keybd_event(0xE8, 0, 0, 0)
        ctypes.windll.user32.keybd_event(0xE8, 0, 2, 0)
    except Exception:
        log.exception("Не удалось нейтрализовать Alt-меню")


def _mod_of(name):
    n = (name or "").lower()
    if n == "alt" or n == "left alt":
        return "left alt"
    if n in ("right alt", "alt gr"):
        return "right alt"
    if n in ("ctrl", "left ctrl"):
        return "left ctrl"
    if n == "right ctrl":
        return "right ctrl"
    if n in ("shift", "left shift"):
        return "left shift"
    if n == "right shift":
        return "right shift"
    if n in ("windows", "left windows", "right windows", "cmd"):
        return "win"
    return None


_MOD_CANON = {"alt": "left alt", "left alt": "left alt", "right alt": "right alt",
              "altgr": "right alt", "ctrl": "left ctrl", "left ctrl": "left ctrl",
              "right ctrl": "right ctrl", "shift": "left shift",
              "left shift": "left shift", "right shift": "right shift",
              "win": "win", "windows": "win"}


def _parse_combo(s):
    """'left alt+`' -> ({'left alt'}, '`'); одиночная клавиша -> None."""
    parts = [p.strip().lower() for p in str(s).split("+") if p.strip()]
    if len(parts) < 2:
        return None
    *mods, main = parts
    return {_MOD_CANON.get(m, m) for m in mods}, main


class HotkeyListener:
    def __init__(self, fsm, cfg, on_start, on_stop, on_repaste=None,
                 is_recording=None, on_correct=None, on_open=None):
        self.fsm = fsm
        self.key = str(cfg.get("hotkey", "left alt+`")).lower().strip()
        self.mode = cfg.get("mode", "toggle")
        self.ptt_key = str(cfg.get("push_to_talk_key", "f8")).lower().strip()
        self.on_start = on_start
        self.on_stop = on_stop
        self.on_repaste = on_repaste
        self.is_recording = is_recording or (lambda: False)
        rp = str(cfg.get("repaste_key", "right alt+`")).lower().strip()

        self.rec_combo = _parse_combo(self.key)
        self.rp_combo = _parse_combo(rp)
        # одиночная клавиша повторной вставки (если задана не комбинацией)
        if self.rp_combo is None and rp:
            self.repaste_names = {"right alt", "alt gr"} if rp == "right alt" else {rp}
        else:
            self.repaste_names = set()

        # доп. действия: исправить вставленный текст, открыть окно приложения.
        # Формат тот же: комбинация ИЛИ одиночная клавиша (f7, f13-f24 —
        # подходят и доп. клавиши макро-клавиатур)
        self.extra = []  # (combo|None, names, action_key, callback)
        for cfg_key, default, cb in (("correct_key", "f7", on_correct),
                                     ("open_window_key", "left alt+p", on_open)):
            k = str(cfg.get(cfg_key, default) or "").lower().strip()
            if not k or cb is None:
                continue
            combo = _parse_combo(k)
            names = set() if combo else {k}
            self.extra.append((combo, names, cfg_key, cb))

        self._mods = set()          # зажатые модификаторы (по имени)
        self._ptt_down = False
        self._hook = None
        self._blocked = []
        self._block = bool(cfg.get("block_hotkeys", False))
        self._fire_t = {}           # анти-повтор по действию
        self._rp_down_t = None
        self._rp_combo_flag = False
        self._last_thread = None

    def start(self):
        self._hook = keyboard.hook(self._handler)
        if self._block:  # забрать одиночные доп. клавиши у ОС (block_hotkeys)
            for _combo, names, akey, _cb in self.extra:
                for n in names:
                    if n in _MOD_CANON:
                        continue  # модификаторы не блокируем никогда
                    try:
                        self._blocked.append(keyboard.block_key(n))
                        log.info("Клавиша %s заблокирована для других программ", n)
                    except Exception:
                        log.exception("Не удалось заблокировать клавишу %s", n)
        log.info("Хук клавиатуры: запись=%s, вставка=%s, mode=%s, доп=%s",
                 self.key, "combo" if self.rp_combo else self.repaste_names,
                 self.mode, [a for _c, _n, a, _f in self.extra])

    def stop(self):
        try:
            if self._hook:
                keyboard.unhook(self._hook)
                self._hook = None
            for h in self._blocked:  # block_key возвращает remover-функцию
                try:
                    h() if callable(h) else keyboard.unhook(h)
                except Exception:
                    pass
            self._blocked = []
        except Exception:
            log.exception("Не удалось снять хук клавиатуры")

    def _dispatch(self, fn):
        prev = self._last_thread

        def run():
            if prev is not None and prev.is_alive():
                prev.join(timeout=30)
            try:
                fn()
            except Exception:
                log.exception("Ошибка обработчика записи")

        t = threading.Thread(target=run, daemon=True)
        self._last_thread = t
        t.start()

    def _throttle(self, key, gap=0.6):
        t = time.monotonic()
        if t - self._fire_t.get(key, 0) < gap:
            return False
        self._fire_t[key] = t
        return True

    def _is_main(self, main, event):
        if main in ("~", "grave", "ё", "combo_grave"):
            main = "`"
        sc = _SCAN.get(main)
        if sc is not None and getattr(event, "scan_code", None) == sc:
            return True
        return (event.name or "").lower() == main

    def _combo_active(self, combo, event):
        mods, main = combo
        return mods.issubset(self._mods) and self._is_main(main, event)

    def _handler(self, event):
        try:
            name = (event.name or "unknown").lower()
            down = event.event_type == "down"
            m = _mod_of(name)
            if m:
                if down:
                    self._mods.add(m)
                else:
                    self._mods.discard(m)

            if self.mode == "push_to_talk":
                self._ptt_handler(event, name)
                return

            # запись комбинацией: старт/стоп
            if self.rec_combo and down and self._combo_active(self.rec_combo, event):
                if self._throttle("rec"):
                    if self.is_recording():
                        self.fsm.force_stop()
                        self._dispatch(self.on_stop)
                    else:
                        self._dispatch(self.on_start)
                return
            # повторная вставка комбинацией
            if (self.on_repaste and self.rp_combo and down
                    and self._combo_active(self.rp_combo, event)):
                if self._throttle("rp"):
                    self._dispatch(self.on_repaste)
                return
            # одиночная клавиша повторной вставки (тап)
            if self.on_repaste and self.repaste_names and name in self.repaste_names:
                self._repaste_tap(event, time.monotonic())
                return
            # доп. действия: комбинация или одиночная клавиша (по нажатию)
            for combo, names, akey, cb in self.extra:
                if combo and down and self._combo_active(combo, event):
                    if self._throttle(akey):
                        self._dispatch(cb)
                    return
                if names and down and name in names:
                    if self._throttle(akey):
                        self._dispatch(cb)
                    return
            # одиночная клавиша записи через FSM (двойной/одиночный тап)
            if self.rec_combo is None and name == self.key:
                t = time.monotonic()
                action = (self.fsm.on_key_down(t) if down
                          else self.fsm.on_key_up(t))
                if action == fsm_mod.NEUTRALIZE:
                    _neutralize_alt()
                elif action == fsm_mod.START:
                    self._dispatch(self.on_start)
                elif action == fsm_mod.STOP:
                    self._dispatch(self.on_stop)
            elif down and self.rec_combo is None:
                self.fsm.on_other_key(time.monotonic())
        except Exception:
            log.exception("Ошибка обработчика хоткея")

    def _repaste_tap(self, event, t):
        if event.event_type == "down":
            if self._rp_down_t is None:
                self._rp_down_t = t
                self._rp_combo_flag = False
                _neutralize_alt()
        else:
            fire = (self._rp_down_t is not None and not self._rp_combo_flag
                    and t - self._rp_down_t <= 0.6)
            self._rp_down_t = None
            if fire:
                self._dispatch(self.on_repaste)

    def _ptt_handler(self, event, name):
        if name != self.ptt_key or self.fsm.state == fsm_mod.PAUSED:
            return
        if event.event_type == "down":
            if not self._ptt_down:
                self._ptt_down = True
                self._dispatch(self.on_start)
        else:
            if self._ptt_down:
                self._ptt_down = False
                self._dispatch(self.on_stop)
