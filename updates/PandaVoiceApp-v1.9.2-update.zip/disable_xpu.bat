@echo off
REM Revert to the standard CPU build of torch.
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
  echo venv not found - run install.bat first
  pause
  exit /b 1
)
venv\Scripts\python.exe -m pip uninstall -y torch
venv\Scripts\python.exe -m pip install torch
venv\Scripts\python.exe -c "import torch; print('torch', torch.__version__, 'CPU build restored')"
pause
