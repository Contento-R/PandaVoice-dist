"""Опциональная тема интерфейса (ui_theme: "animated" | "obsidian").

По умолчанию ("classic") модуль полностью пассивен: обработчики сразу
выходят, вид и поведение приложения не меняются. tkinter не умеет плавных
переходов, поэтому анимации — интерполяция цвета/позиции шагами after()
(~30 мс на шаг). Режимы:
  "animated" — только анимации на родной палитре: плавная подсветка
      меню, «подъём» кнопок высветлением (теней в tkinter нет), пружинка
      тумблеров, печатная машинка транскрипта, проявление окон (alpha),
      дыхание статусной точки при записи;
  "obsidian" — все анимации ПЛЮС стиль Obsidian Pro Terminal (выбор
      оператора по макетам, источник — skills/obsidian-pro-terminal):
      слои чёрного #050505/#0C0C0C/#1A1A1A, единственный изумрудный
      акцент, моноширинные цифры (Consolas), КАПС-ярлыки меню.
      apply_style() подменяет цвета-константы gui/overlay при старте,
      поэтому включение/выключение obsidian требует перезапуска.

tkinter импортируется лениво внутри функций: модуль (и его тесты)
работает и в окружении без GUI.
"""
import logging

log = logging.getLogger("theme")

# палитра приложения (те же значения, что в gui.py); при "obsidian"
# apply_style() подменяет и эти значения, чтобы анимации рисовались
# в цветах активного стиля
SIDEBAR = "#141417"
SURFACE = "#26262c"
NAV_ON_BG = "#1f1f24"
TEXT = "#e8e8ec"
MUTED = "#9a9aa3"
ACCENT = "#4cc38a"
ACCENT_HOVER = "#5fd39c"
ACCENT_PRESS = "#3da878"
ACCENT_FG = "#10241a"
BTN_HOVER = "#34343c"
BTN_PRESS = "#1f1f24"
TRACK_OFF = "#3d3d46"

# Obsidian Pro Terminal. rgba-рамки из скилла заменены сплошными
# эквивалентами поверх чёрного (tkinter не умеет полупрозрачность).
OBSIDIAN_GUI = {
    "BG": "#0c0c0c", "SIDEBAR": "#080808", "SURFACE": "#1a1a1a",
    "FIELD": "#050505", "BORDER": "#232327", "TEXT": "#e6e8e4",
    "MUTED": "#9aa29c", "ACCENT": "#2ecc7a", "SELECT": "#123326",
    "DANGER": "#f87171", "NAV_BG": "#131313", "CHIP": "#1a1a1a",
    "ZEBRA": "#101010",
}
OBSIDIAN_OVERLAY = {"BG": "#0c0c0c", "EDGE": "#2a2a2e",
                    "ACCENT": "#2ecc7a", "DANGER": "#f87171"}
_OBSIDIAN_SELF = {
    "SIDEBAR": "#080808", "SURFACE": "#1a1a1a", "NAV_ON_BG": "#131313",
    "TEXT": "#e6e8e4", "MUTED": "#9aa29c", "ACCENT": "#2ecc7a",
    "ACCENT_HOVER": "#3be087", "ACCENT_PRESS": "#1fa862",
    "ACCENT_FG": "#04130b", "BTN_HOVER": "#222226", "BTN_PRESS": "#131313",
    "TRACK_OFF": "#222226",
}
MONO = "Consolas"  # моноширинный шрифт для цифр в стиле obsidian

STEP_MS = 30
# пружинка тумблера: доли пути с лёгким перелётом (заканчивается ровно в 1)
SPRING = (0.0, 0.35, 0.72, 0.94, 1.08, 1.03, 0.99, 1.0)

_cfg = None  # ссылка на живой cfg приложения (apply_config мутирует его же)


def set_cfg(cfg):
    global _cfg
    _cfg = cfg


def _mode(cfg=None):
    c = _cfg if cfg is None else cfg
    try:
        return str(c.get("ui_theme", "classic")).lower() if c else "classic"
    except Exception:
        return "classic"


def animated(cfg=None):
    """Включены ли анимации (режимы animated и obsidian)."""
    return _mode(cfg) in ("animated", "obsidian")


def styled(cfg=None):
    """Включён ли стиль Obsidian Pro Terminal."""
    return _mode(cfg) == "obsidian"


def apply_style(gui_mod):
    """Подменить цвета-константы gui/overlay на Obsidian-набор. Звать ДО
    построения окна (_theme/_build). При classic/animated — no-op.
    Возвращает True, если стиль применён."""
    if not styled():
        return False
    try:
        for k, v in OBSIDIAN_GUI.items():
            if hasattr(gui_mod, k):
                setattr(gui_mod, k, v)
        gui_mod.STATE_DOT = {
            "loading": OBSIDIAN_GUI["MUTED"], "idle": OBSIDIAN_GUI["ACCENT"],
            "recording": OBSIDIAN_GUI["DANGER"], "processing": "#fbbf24",
            "paused": OBSIDIAN_GUI["MUTED"]}
        import overlay as _ov
        for k, v in OBSIDIAN_OVERLAY.items():
            setattr(_ov, k, v)
        g = globals()
        g.update(_OBSIDIAN_SELF)
        log.info("Тема Obsidian Pro применена")
        return True
    except Exception:
        log.exception("Не удалось применить стиль Obsidian")
        return False


def retheme_ttk(st):
    """Поверх _theme(): hover/pressed-цвета ttk, зашитые там литералами,
    приводим к Obsidian. При classic/animated — no-op."""
    if not styled():
        return
    try:
        st.configure("Accent.TButton", background=ACCENT, foreground=ACCENT_FG)
        st.map("Accent.TButton", background=[("pressed", ACCENT_PRESS),
                                             ("active", ACCENT_HOVER)])
        st.map("TButton", background=[("pressed", BTN_PRESS),
                                      ("active", BTN_HOVER)])
    except Exception:
        log.exception("Не удалось довести ttk-стили Obsidian")


def nav_label(text):
    """Пункт меню в стиле терминала: «История» → «И С Т О Р И Я»."""
    if not styled():
        return text
    return " ".join(text.upper())


def fade_in(win, ms=140):
    """Плавное проявление окна через -alpha; без анимаций — no-op,
    без поддержки alpha — окно просто остаётся видимым."""
    if not animated():
        return
    try:
        win.attributes("-alpha", 0.0)
        n = max(3, int(ms // STEP_MS))

        def fn(i):
            win.attributes("-alpha", ease_out((i + 1) / n))

        _steps(win, fn, n)
    except Exception:
        try:
            win.attributes("-alpha", 1.0)
        except Exception:
            pass


def ease_out(t):
    """Квадратичный ease-out (правило ui-ux-pro-max: linear в UI нельзя)."""
    t = max(0.0, min(1.0, t))
    return 1.0 - (1.0 - t) ** 2


def lerp_hex(a, b, t):
    """Промежуточный цвет между #rrggbb a и b, t зажимается в [0..1]."""
    t = max(0.0, min(1.0, t))
    av = [int(a[i:i + 2], 16) for i in (1, 3, 5)]
    bv = [int(b[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(
        round(x + (y - x) * t) for x, y in zip(av, bv))


def _steps(widget, fn, n):
    """n шагов fn(i) через after(); тихо обрывается, если виджет умер."""
    def step(i):
        try:
            if not widget.winfo_exists():
                return
            fn(i)
        except Exception:
            return
        if i + 1 < n:
            try:
                widget.after(STEP_MS, step, i + 1)
            except Exception:
                pass
    step(0)


def nav_pulse(item, bar, lbl):
    """Плавная подсветка активного пункта меню («Меню — B»).
    Возвращает True, если анимация запущена (иначе gui красит мгновенно)."""
    if not animated():
        return False
    try:
        item.configure(bg=NAV_ON_BG)
        lbl.configure(bg=NAV_ON_BG)
        n = 5

        def fn(i):
            t = ease_out((i + 1) / n)
            bar.configure(bg=lerp_hex(SIDEBAR, ACCENT, t))
            lbl.configure(fg=lerp_hex(MUTED, TEXT, t))

        _steps(bar, fn, n)
        return True
    except Exception:
        log.exception("Анимация меню не удалась")
        return False


def install_buttons(root):
    """«Подъём» кнопок высветлением («Кнопки — D», упрощённо). Один
    class-bind на все ttk-кнопки — точки создания кнопок не меняются;
    при classic-теме обработчики не делают ничего."""
    try:
        from tkinter import ttk
        st = ttk.Style(root)
    except Exception:
        log.exception("Тема кнопок недоступна")
        return

    def unique(w):
        """Личный стиль кнопки (нужен, чтобы анимировать только её)."""
        name = getattr(w, "_anim_style", None)
        if name:
            return name
        accent = "Accent" in str(w.cget("style") or "")
        base, hover, press, fg = (
            (ACCENT, ACCENT_HOVER, ACCENT_PRESS, ACCENT_FG) if accent
            else (SURFACE, BTN_HOVER, BTN_PRESS, TEXT))
        name = "Anim%s.TButton" % w.winfo_id()
        st.configure(name, background=base, foreground=fg,
                     borderwidth=0, padding=(12, 6))
        st.map(name, background=[("pressed", press)])
        w.configure(style=name)
        w._anim_style = name
        w._anim_colors = (base, hover)
        return name

    def fade(w, frm, to, n):
        name = w._anim_style

        def fn(i):
            st.configure(name, background=lerp_hex(frm, to,
                                                   ease_out((i + 1) / n)))

        _steps(w, fn, n)

    def enter(e):
        if not animated():
            return
        try:
            unique(e.widget)
            base, hover = e.widget._anim_colors
            fade(e.widget, base, hover, 5)  # вход ~150 мс
        except Exception:
            pass

    def leave(e):
        w = e.widget
        if not getattr(w, "_anim_style", None):
            return
        try:
            base, hover = w._anim_colors
            if animated():
                fade(w, hover, base, 3)  # выход быстрее входа (~90 мс)
            else:
                st.configure(w._anim_style, background=base)
        except Exception:
            pass

    try:
        root.bind_class("TButton", "<Enter>", enter, add="+")
        root.bind_class("TButton", "<Leave>", leave, add="+")
    except Exception:
        log.exception("Не удалось включить анимацию кнопок")
