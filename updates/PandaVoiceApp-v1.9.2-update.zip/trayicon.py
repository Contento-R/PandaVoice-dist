"""Иконка Panda Voice в системном трее (pystray). Цвет индикатора = состояние."""
import logging

import pystray

from branding import APP_NAME, panda_icon

log = logging.getLogger("tray")

COLORS = {
    "loading": (128, 128, 128),
    "idle": (46, 160, 67),
    "recording": (218, 54, 51),
    "processing": (227, 160, 8),
    "paused": (9, 105, 218),
}
LABELS = {
    "loading": f"{APP_NAME}: загрузка модели...",
    "idle": f"{APP_NAME}: готово (Left Alt+` — запись)",
    "recording": f"{APP_NAME}: ЗАПИСЬ (Left Alt+` — стоп)",
    "processing": f"{APP_NAME}: распознавание...",
    "paused": f"{APP_NAME}: пауза",
}


class Tray:
    def __init__(self, on_open, on_toggle_pause, on_mic_test, on_update,
                 on_restart, on_quit, is_paused):
        self._icons = {k: panda_icon(c) for k, c in COLORS.items()}
        menu = pystray.Menu(
            # default=True: окно открывается и двойным кликом по иконке
            pystray.MenuItem("Открыть окно", on_open, default=True),
            pystray.MenuItem(
                lambda item: "Возобновить" if is_paused() else "Пауза",
                on_toggle_pause),
            pystray.MenuItem("Проверка микрофона", on_mic_test),
            pystray.MenuItem("Обновление", on_update),
            pystray.MenuItem("Перезапустить", on_restart),
            pystray.MenuItem("Выход", on_quit),
        )
        self.icon = pystray.Icon("panda-voice", self._icons["loading"],
                                 LABELS["loading"], menu)

    def set_state(self, state):
        # update_menu тут НЕ зовём: DestroyMenu из рабочего потока рушит
        # открытое меню; подпись «Пауза/Возобновить» и так динамическая
        try:
            self.icon.icon = self._icons.get(state, self._icons["idle"])
            self.icon.title = LABELS.get(state, APP_NAME)
        except Exception:  # сбой трея (перезапуск explorer) не должен ломать логику
            log.exception("Не удалось обновить иконку трея")

    def notify(self, msg, title=APP_NAME):
        try:
            self.icon.notify(msg, title)
        except Exception:
            log.exception("Не удалось показать уведомление")

    def run(self, setup):
        self.icon.run(setup=setup)

    def run_detached(self, setup):
        """Трей в фоновом потоке — главный поток остаётся за tkinter."""
        self.icon.run_detached(setup=setup)

    def stop(self):
        try:
            self.icon.stop()
        except Exception:
            pass
