"""Глобальные хоткеи для Linux (X11) через pynput. Тот же интерфейс, что у
win_hotkeys.HotkeyListener; логика тапов — общая (hotkey_fsm).

Ограничения: подавить системную реакцию клавиши нельзя (NEUTRALIZE
игнорируется); на Wayland глобальные хоткеи могут не работать — см. README.
"""
import logging
import threading
import time

import hotkey_fsm as fsm_mod

log = logging.getLogger("hotkeys")


def _keyset(name):
    from pynput.keyboard import Key, KeyCode
    name = (name or "alt").lower()
    specials = {
        "alt": ("alt", "alt_l"),  # правый Alt — отдельная клавиша (вставка)
        "right alt": ("alt_r", "alt_gr"),
        "right ctrl": ("ctrl_r",),
        "right shift": ("shift_r",),
        "ctrl": ("ctrl", "ctrl_l", "ctrl_r"),
        "shift": ("shift", "shift_l", "shift_r"),
        "win": ("cmd", "cmd_l", "cmd_r"),
        "cmd": ("cmd", "cmd_l", "cmd_r"),
    }
    if name in specials:
        return {getattr(Key, n) for n in specials[name] if hasattr(Key, n)}
    if hasattr(Key, name):  # f8, esc, tab, space...
        return {getattr(Key, name)}
    return {KeyCode.from_char(name)}


class HotkeyListener:
    def __init__(self, fsm, cfg, on_start, on_stop, on_repaste=None,
                 is_recording=None):
        self.fsm = fsm
        self.mode = cfg.get("mode", "toggle")
        hotkey = str(cfg.get("hotkey", "alt")).lower().strip()
        if "+" in hotkey:  # ponytail: комбинации на Linux пока не поддержаны
            log.warning("Комбинации клавиш на Linux не поддерживаются — "
                        "используйте одиночную клавишу (сейчас: %s)", hotkey)
            hotkey = "alt"
        self.keys = _keyset(hotkey)
        self.ptt_keys = _keyset(cfg.get("push_to_talk_key", "f8"))
        rp = str(cfg.get("repaste_key", "right alt")).lower().strip()
        self.repaste_keys = _keyset(rp) if rp else set()
        self.on_start = on_start
        self.on_stop = on_stop
        self.on_repaste = on_repaste
        self.is_recording = is_recording or (lambda: False)
        self._ptt_down = False
        self._listener = None
        self._last_thread = None

    def start(self):
        from pynput import keyboard as pk
        self._listener = pk.Listener(on_press=self._on_press,
                                     on_release=self._on_release)
        self._listener.daemon = True
        self._listener.start()
        log.info("pynput-хук установлен (mode=%s)", self.mode)

    def stop(self):
        try:
            if self._listener:
                self._listener.stop()
                self._listener = None
        except Exception:
            log.exception("Не удалось снять pynput-хук")

    def _dispatch(self, fn):
        prev = self._last_thread

        def run():
            if prev is not None and prev.is_alive():
                prev.join(timeout=30)
            try:
                fn()
            except Exception:
                log.exception("Ошибка обработчика записи")

        t = threading.Thread(target=run, daemon=True)
        self._last_thread = t
        t.start()

    def _on_press(self, key):
        try:
            t = time.monotonic()
            if self.mode == "push_to_talk":
                if key in self.ptt_keys and not self._ptt_down \
                        and self.fsm.state != fsm_mod.PAUSED:
                    self._ptt_down = True
                    self._dispatch(self.on_start)
                return
            if key in self.keys:
                action = self.fsm.on_key_down(t)
            else:
                self.fsm.on_other_key(t)
                action = None
            self._act(action)
        except Exception:
            log.exception("Ошибка обработчика хоткея")

    def _on_release(self, key):
        try:
            t = time.monotonic()
            if self.on_repaste and key in self.repaste_keys:
                self._dispatch(self.on_repaste)
                return
            if self.mode == "push_to_talk":
                if key in self.ptt_keys and self._ptt_down:
                    self._ptt_down = False
                    self._dispatch(self.on_stop)
                return
            if key in self.keys:
                self._act(self.fsm.on_key_up(t))
        except Exception:
            log.exception("Ошибка обработчика хоткея")

    def _act(self, action):
        if action == fsm_mod.START:
            self._dispatch(self.on_start)
        elif action == fsm_mod.STOP:
            self._dispatch(self.on_stop)
        # NEUTRALIZE на Linux невозможен и не нужен
