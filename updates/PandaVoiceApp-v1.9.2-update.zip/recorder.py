"""Запись с микрофона: 16 kHz mono float32, в память.

Дополнительно: история уровней (для эквалайзера в оверлее) и выдача готовых
фрагментов прямо во время записи (take_chunk) — для потокового распознавания.
"""
import logging
import threading
from collections import deque

import numpy as np

from chunking import _window_rms, find_cut_points

log = logging.getLogger("recorder")
SR = 16000


class Recorder:
    def __init__(self, device=None):
        self.device = device
        self._lock = threading.Lock()
        self._chunks = []
        self._stream = None
        self._total = 0  # всего записано сэмплов (включая отданные take_chunk)
        self.level_history = deque(maxlen=32)  # свежие RMS-уровни для оверлея

    @property
    def recording(self):
        return self._stream is not None

    def start(self):
        import sounddevice as sd
        with self._lock:
            if self._stream:
                return
            self._chunks = []
            self._total = 0
            self.level_history.clear()
            self._stream = sd.InputStream(
                samplerate=SR, channels=1, dtype="float32",
                device=self.device, callback=self._callback)
            try:
                self._stream.start()
            except Exception:
                self._stream = None
                raise

    def _callback(self, indata, frames, time_info, status):
        if status:
            log.warning("Статус аудиопотока: %s", status)
        block = indata[:, 0].copy()
        try:
            self.level_history.append(float(np.sqrt((block ** 2).mean())))
        except Exception:
            pass
        with self._lock:
            self._chunks.append(block)
            self._total += len(block)

    def take_chunk(self, min_sec=15.0, max_sec=30.0, eager=False,
                   eager_pause_sec=0.7):
        """Отдать готовый фрагмент для потокового распознавания, иначе None.

        Обычный режим: буфер превысил max_sec — режем по паузе (или жёстко).
        eager: пользователь замолчал (~0.7 c тишины в хвосте буфера) и
        накопилось >= min_sec — забираем фразу сразу, не дожидаясь max_sec.
        Так к моменту остановки почти всё уже распознано."""
        with self._lock:
            if not self._chunks:
                return None
            total = sum(len(c) for c in self._chunks)
            if total < min_sec * SR:
                return None
            audio = np.concatenate(self._chunks)
            if total > max_sec * SR:
                cuts = find_cut_points(audio, SR, min_chunk_sec=min_sec,
                                       max_chunk_sec=max_sec)
                cut = cuts[0] if cuts else int(max_sec * SR)
                self._chunks = [audio[cut:]]
                return audio[:cut]
            if eager:
                import vad
                silent = vad.tail_is_silent(audio, eager_pause_sec)
                if silent is None:  # VAD недоступен — старый RMS-порог
                    win = SR // 20  # окна по 50 мс, как в chunking
                    rms = _window_rms(audio, win)
                    n = max(2, int(eager_pause_sec / 0.05))
                    if len(rms) >= n:
                        thr = max(1e-4, 0.08 * float(np.percentile(rms, 95)))
                        silent = float(rms[-n:].max()) < thr
                if silent:
                    cut = len(audio) - int(0.25 * SR)
                    self._chunks = [audio[cut:]]
                    return audio[:cut]
            return None

    def stop(self) -> np.ndarray:
        """Останавливает запись и возвращает НЕзабранный остаток аудио."""
        with self._lock:
            if not self._stream:
                return np.zeros(0, dtype=np.float32)
            stream = self._stream
            self._stream = None
        try:
            stream.stop()
            stream.close()
        except Exception:
            log.exception("Ошибка остановки аудиопотока")
        with self._lock:
            if not self._chunks:
                return np.zeros(0, dtype=np.float32)
            audio = np.concatenate(self._chunks)
            self._chunks = []
            return audio

    def total_duration(self):
        """Полная длительность записи в секундах (включая отданные фрагменты)."""
        with self._lock:
            return self._total / SR

    def norm_levels(self, n=17):
        """Последние n уровней, нормированные в 0..1 для волны в оверлее.

        Шумовой пол (20-й перцентиль истории) вычитается, поэтому тишина
        даёт честный ноль, а не «дыхание»; шкала не короче 0.03 RMS, чтобы
        тихий комнатный шум не растягивался на всю высоту."""
        lh = list(self.level_history)
        if not lh:
            return []
        floor = sorted(lh)[int(len(lh) * 0.2)]
        gate = floor * 1.6 + 0.0015
        ref = max(max(lh), gate * 3, 0.03)
        return [round(max(0.0, min(1.0, (v - gate) / (ref - gate))) ** 0.7, 3)
                for v in lh[-n:]]
