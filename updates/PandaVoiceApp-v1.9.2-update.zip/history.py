"""История голосовых вводов: history.jsonl рядом с приложением."""
import json
import logging
import time

from appconfig import APP_DIR

log = logging.getLogger("history")
HISTORY_PATH = APP_DIR / "history.jsonl"


def append(text, audio_sec, recog_sec, max_entries=500):
    try:
        rec = {
            "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
            "audio_sec": round(float(audio_sec), 1),
            "recog_sec": round(float(recog_sec), 1),
            "text": text,
        }
        with open(HISTORY_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        _trim(max_entries)
    except Exception:
        log.exception("Не удалось записать историю")


def _trim(max_entries):
    # переписываем файл только когда он вдвое превысил лимит
    lines = HISTORY_PATH.read_text(encoding="utf-8").splitlines()
    if len(lines) > max_entries * 2:
        HISTORY_PATH.write_text("\n".join(lines[-max_entries:]) + "\n",
                                encoding="utf-8")


def read_last(n=300):
    """Последние n записей, от старых к новым."""
    try:
        lines = HISTORY_PATH.read_text(encoding="utf-8").splitlines()
    except FileNotFoundError:
        return []
    except Exception:
        log.exception("Не удалось прочитать историю")
        return []
    out = []
    for line in lines[-n:]:
        try:
            out.append(json.loads(line))
        except Exception:
            pass
    return out


def save_all(entries):
    """Перезаписать весь файл истории (после ручной правки записи)."""
    try:
        with open(HISTORY_PATH, "w", encoding="utf-8") as f:
            for e in entries:
                f.write(json.dumps(e, ensure_ascii=False) + "\n")
    except Exception:
        log.exception("Не удалось сохранить историю")


def clear():
    try:
        HISTORY_PATH.unlink(missing_ok=True)
    except Exception:
        log.exception("Не удалось очистить историю")
