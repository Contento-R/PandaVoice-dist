@echo off
REM Switch torch to Intel GPU (XPU) build - for Intel Arc graphics.
REM Requirements: Intel graphics driver 32.0.101.6739+ and Resizable BAR ON.
REM Revert anytime with disable_xpu.bat
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
  echo venv not found - run install.bat first
  pause
  exit /b 1
)
echo Removing CPU torch...
venv\Scripts\python.exe -m pip uninstall -y torch
echo Installing XPU torch (several hundred MB, please wait)...
venv\Scripts\python.exe -m pip install torch --index-url https://download.pytorch.org/whl/xpu
echo.
venv\Scripts\python.exe -c "import torch; print('torch', torch.__version__); print('XPU available:', torch.xpu.is_available())"
echo.
echo If "XPU available: True" - restart Panda Voice, it will use the GPU
echo automatically (check the Journal tab for device=xpu).
echo If False - update the Intel graphics driver and enable Resizable BAR,
echo or run disable_xpu.bat to go back to CPU.
pause
