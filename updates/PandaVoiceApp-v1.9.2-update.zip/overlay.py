"""Всплывающий индикатор записи: окошко с эквалайзером в центре активного окна.

Слева «✕» — отменить запись, в центре — уровень микрофона живыми столбиками,
справа «■» — остановить и распознать. В состоянии распознавания — бегущие
точки. Живёт в Tk-потоке (владелец — Gui). Размеры масштабируются под DPI
экрана (процесс должен быть DPI-aware — main.py включает это при старте).
"""
import logging
import sys
import threading
import tkinter as tk

import theme

log = logging.getLogger("overlay")

BASE_W, BASE_H = 208, 30  # компактная пилюля
BG = "#1c1c21"            # тёмный графит
EDGE = "#41414b"          # тонкий кант пилюли
TEXT = "#e8e8ec"
MUTED = "#77777f"
ACCENT = "#4cc38a"        # эквалайзер — фирменный зелёный
DANGER = "#e5484d"
TRANSPARENT = "#ff00fe"  # цветовой ключ прозрачности (Windows)


def _caret_screen_pos():
    """Экранные координаты текстовой каретки активного окна (Windows).
    None — каретку определить нельзя (браузеры с своим рендерингом и т.п.)."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        class RECT(ctypes.Structure):
            _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                        ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

        class GUITHREADINFO(ctypes.Structure):
            _fields_ = [("cbSize", wintypes.DWORD), ("flags", wintypes.DWORD),
                        ("hwndActive", wintypes.HWND), ("hwndFocus", wintypes.HWND),
                        ("hwndCapture", wintypes.HWND), ("hwndMenuOwner", wintypes.HWND),
                        ("hwndMoveSize", wintypes.HWND), ("hwndCaret", wintypes.HWND),
                        ("rcCaret", RECT)]

        u = ctypes.windll.user32
        hwnd = u.GetForegroundWindow()
        if not hwnd:
            return None
        tid = u.GetWindowThreadProcessId(hwnd, None)
        info = GUITHREADINFO()
        info.cbSize = ctypes.sizeof(GUITHREADINFO)
        if not u.GetGUIThreadInfo(tid, ctypes.byref(info)) or not info.hwndCaret:
            return None
        pt = wintypes.POINT(info.rcCaret.left, info.rcCaret.bottom)
        u.ClientToScreen(info.hwndCaret, ctypes.byref(pt))
        return pt.x, pt.y
    except Exception:
        return None


def _active_monitor_rect(hwnd=None):
    """Границы монитора, где активное окно (или окно hwnd). None иначе."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        class RECT(ctypes.Structure):
            _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                        ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

        class MONITORINFO(ctypes.Structure):
            _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", RECT),
                        ("rcWork", RECT), ("dwFlags", wintypes.DWORD)]

        u = ctypes.windll.user32
        hwnd = hwnd or u.GetForegroundWindow() or 0
        hmon = u.MonitorFromWindow(hwnd, 2)  # MONITOR_DEFAULTTONEAREST
        mi = MONITORINFO()
        mi.cbSize = ctypes.sizeof(MONITORINFO)
        if not u.GetMonitorInfoW(hmon, ctypes.byref(mi)):
            return None
        r = mi.rcMonitor
        return r.left, r.top, r.right, r.bottom
    except Exception:
        return None


def _foreground_window_rect():
    """Прямоугольник активного окна (только Windows)."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        hwnd = u.GetForegroundWindow()
        if not hwnd:
            return None
        r = wintypes.RECT()
        if not u.GetWindowRect(hwnd, ctypes.byref(r)):
            return None
        if r.right - r.left < 50 or r.bottom - r.top < 50:
            return None
        return r.left, r.top, r.right, r.bottom
    except Exception:
        return None


class Overlay:
    def __init__(self, root, app):
        self.app = app
        # масштаб под DPI: при 200% окно должно быть вдвое больше в пикселях
        try:
            self.k = max(1.0, root.winfo_fpixels("1i") / 96.0)
        except Exception:
            self.k = 1.0
        # современная пилюля (крупнее, волна точек в стиле Aqua) — только
        # при включённой теме; classic по умолчанию остаётся прежним
        self._modern = theme.animated()
        bw, bh = (238, 36) if self._modern else (BASE_W, BASE_H)
        self.W = int(bw * self.k)
        self.H = int(bh * self.k)
        self.win = tk.Toplevel(root)
        self.win.withdraw()
        self.win.overrideredirect(True)
        try:
            self.win.attributes("-topmost", True)
        except Exception:
            pass
        self._round = False
        if sys.platform == "win32":
            try:  # скругление через цветовой ключ прозрачности
                self.win.attributes("-transparentcolor", TRANSPARENT)
                self._round = True
            except Exception:
                pass
        self.canvas = tk.Canvas(self.win, width=self.W, height=self.H,
                                highlightthickness=0,
                                bg=TRANSPARENT if self._round else BG)
        self.canvas.pack()
        self.state = None  # None | recording | processing
        self._tick = 0
        self._hover = None  # None | cancel | stop — подсветка под курсором
        self.canvas.bind("<Button-1>", self._on_click)
        self.canvas.bind("<Motion>", self._on_motion)
        self.canvas.bind("<Leave>", lambda e: self._set_hover(None))
        self._make_noactivate()
        # живой транскрипт (опц.): отдельное окошко над пилюлей, создаётся
        # лениво только когда функция включена и пошли распознанные фрагменты
        self._live_win = None
        self._live_canvas = None
        self._live_round = False
        self._live_shown = ""
        self._live_text = None
        # obsidian: таймер моноширинным (Overlay создаётся после apply_style)
        self._tfont = ((theme.MONO, 9, "bold") if theme.styled()
                       else ("Segoe UI", 9, "bold"))
        self._animate()

    def _make_noactivate(self, win=None):
        """Клики по оверлею НЕ должны забирать фокус у окна пользователя —
        иначе Ctrl+V после «■» прилетает в оверлей, а не в текстовое поле."""
        if sys.platform != "win32":
            return
        try:
            import ctypes
            win = win or self.win
            win.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(win.winfo_id())
            GWL_EXSTYLE = -20
            style = ctypes.windll.user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)
            # WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW
            style |= 0x08000000 | 0x00000080
            ctypes.windll.user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, style)
        except Exception:
            log.exception("Не удалось сделать оверлей неактивируемым")

    def _s(self, v):
        return int(v * self.k)

    # --- показ/скрытие (звать только из Tk-потока, через Gui.call) ---

    def show(self, state):
        first = self.state is None
        self.state = state
        if first:
            self._place()
        self.win.deiconify()
        self.win.lift()

    def hide(self):
        self.state = None
        self.win.withdraw()
        self._hide_live()

    # --- живой транскрипт (опционально, cfg.live_transcript) ---

    def _live_enabled(self):
        try:
            return bool(self.app.cfg.get("live_transcript"))
        except Exception:
            return False

    def _ensure_live_win(self):
        if self._live_win is not None:
            return
        try:
            w = tk.Toplevel(self.win)
            w.withdraw()
            w.overrideredirect(True)
            try:
                w.attributes("-topmost", True)
            except Exception:
                pass
            self._live_round = False
            if sys.platform == "win32":
                try:  # скругление колор-ключом — как у пилюли
                    w.attributes("-transparentcolor", TRANSPARENT)
                    self._live_round = True
                except Exception:
                    pass
            self._live_canvas = tk.Canvas(
                w, highlightthickness=0,
                bg=TRANSPARENT if self._live_round else BG)
            self._live_canvas.pack()
            self._live_win = w
            self._make_noactivate(w)  # клики не крадут фокус у поля ввода
        except Exception:
            log.exception("Не удалось создать окно живого транскрипта")
            self._live_win = None

    def _round_panel(self, c, W, H, r):
        """Скруглённая тёмная панель с кантом — в одном языке с пилюлей."""
        if not self._live_round:
            c.create_rectangle(0, 0, W - 1, H - 1, fill=BG, outline=EDGE)
            return
        for x, y in ((0, 0), (W - 2 * r, 0), (0, H - 2 * r),
                     (W - 2 * r, H - 2 * r)):
            c.create_oval(x, y, x + 2 * r, y + 2 * r, fill=BG, outline=BG)
        c.create_rectangle(r, 0, W - r, H, fill=BG, outline="")
        c.create_rectangle(0, r, W, H - r, fill=BG, outline="")
        c.create_line(r, 0, W - r, 0, fill=EDGE)
        c.create_line(r, H - 1, W - r, H - 1, fill=EDGE)
        c.create_line(0, r, 0, H - r, fill=EDGE)
        c.create_line(W - 1, r, W - 1, H - r, fill=EDGE)

    def _draw_live(self, text):
        """Панель транскрипта под размер текста: точка записи + ярлык
        сверху, текст ниже; ширина/высота подгоняются по содержимому."""
        self._live_shown = text
        c, s = self._live_canvas, self._s
        pad, top = s(12), s(24)
        body = ("Segoe UI", 10)
        c.delete("all")
        tid = c.create_text(pad, top, anchor="nw", width=s(300),
                            text=text, fill=TEXT, font=body)
        box = c.bbox(tid)
        if not box:  # канва ещё не готова — попробуем в следующем тике
            c.delete("all")
            self._live_shown = ""
            return
        y1 = box[3]
        # ширина фиксированная: панель не «дышит» по горизонтали от текста
        W, H = s(324), y1 + s(10)
        c.delete(tid)
        self._round_panel(c, W, H, s(10))
        c.create_oval(pad, s(9), pad + s(6), s(15), fill=DANGER, outline="")
        c.create_text(pad + s(11), s(12), anchor="w", fill=MUTED,
                      text="ЖИВОЙ ТРАНСКРИПТ",
                      font=((theme.MONO if theme.styled() else "Segoe UI"),
                            7, "bold"))
        c.create_text(pad, top, anchor="nw", width=s(300), text=text,
                      fill=TEXT, font=body)
        c.configure(width=W, height=H)

    def _place_live(self):
        """Над пилюлей, по её центру; если сверху нет места — под ней."""
        try:
            self.win.update_idletasks()
            px = self.win.winfo_rootx()
            py = self.win.winfo_rooty()
            pw = self.win.winfo_width() or self.W
            ph = self.win.winfo_height() or self.H
            self._live_win.update_idletasks()
            lw = self._live_win.winfo_reqwidth()
            lh = self._live_win.winfo_reqheight()
            mon = None  # монитор пилюли: на мультимониторе координаты бывают
            if sys.platform == "win32":  # отрицательными — с нулём не сравнить
                try:
                    import ctypes
                    hwnd = ctypes.windll.user32.GetParent(self.win.winfo_id())
                    mon = _active_monitor_rect(hwnd)
                except Exception:
                    mon = None
            top = mon[1] if mon else 0
            x = px + pw // 2 - lw // 2
            if mon:  # не выйти за края монитора по горизонтали
                x = max(mon[0] + 4, min(x, mon[2] - lw - 4))
            y = py - lh - self._s(8)
            if y < top + self._s(4):  # у верхней кромки — покажем под пилюлей
                y = py + ph + self._s(8)
            self._live_win.geometry(f"{lw}x{lh}+{int(x)}+{int(y)}")
        except Exception:
            pass

    def _update_live(self):
        """Звать из Tk-потока (из _animate). Показывает накопленные фрагменты
        _partials во время записи; читает их снимком, как эквалайзер."""
        rec = False
        try:  # пауза из трея останавливает рекордер, не трогая state оверлея —
            rec = bool(self.app.recorder and self.app.recorder.recording)
        except Exception:  # без этой проверки окно зависло бы с текстом
            pass
        if not (self._live_enabled() and self.state == "recording" and rec):
            self._hide_live()
            return
        try:
            frags = list(getattr(self.app, "_partials", []) or [])
        except Exception:
            frags = []
        text = " ".join(f for f in frags if f).strip()
        if not text:
            self._hide_live()
            return
        if len(text) > 300:  # длинная диктовка: показываем хвост, окно
            text = "…" + text[-300:]  # не разрастается на весь экран
        self._ensure_live_win()
        if self._live_win is None:
            return
        changed = text != self._live_text
        if changed:
            shown = self._live_shown
            try:
                import theme
                typing = (theme.animated() and len(text) > len(shown)
                          and text.startswith(shown))
            except Exception:
                typing = False
            if typing:
                # печатная машинка: допечатываем хвост порции по кусочку
                # за тик _animate (~90 мс); classic-путь ниже не меняется
                missing = len(text) - len(shown)
                self._live_text = text[:len(shown) + max(3, missing // 3)]
                self._draw_live(self._live_text)
            else:
                self._live_text = text
                self._draw_live(text)
        try:
            hidden = self._live_win.state() != "normal"
        except Exception:
            hidden = True
        if changed or hidden:  # геометрию дёргаем только при изменении
            self._place_live()
            if hidden:
                try:
                    self._live_win.deiconify()
                    self._live_win.lift()
                    if not self._live_round:  # alpha не мешаем колор-ключу
                        theme.fade_in(self._live_win, 120)
                except Exception:
                    pass

    def _hide_live(self):
        self._live_text = None
        self._live_shown = ""
        if self._live_win is not None:
            try:
                self._live_win.withdraw()
            except Exception:
                pass

    def _virtual_screen(self):
        """Границы ВСЕГО рабочего пространства (все мониторы), не первичного."""
        if sys.platform == "win32":
            try:
                import ctypes
                m = ctypes.windll.user32.GetSystemMetrics
                x0, y0 = m(76), m(77)  # SM_X/YVIRTUALSCREEN
                return x0, y0, x0 + m(78), y0 + m(79)  # + SM_CX/CYVIRTUALSCREEN
            except Exception:
                pass
        return (0, 0, self.win.winfo_screenwidth(),
                self.win.winfo_screenheight())

    def _place(self):
        """Внизу по центру монитора активного окна, на ~1 см выше нижнего
        края экрана; поверх всех окон (-topmost). Фолбэк — низ основного
        экрана."""
        mon = _active_monitor_rect()
        if mon:
            left, top, right, bottom = mon
        else:
            left, top = 0, 0
            right = self.win.winfo_screenwidth()
            bottom = self.win.winfo_screenheight()
        cm = int(96 * self.k / 2.54)  # ~1 см в пикселях с учётом DPI
        x = (left + right) // 2 - self.W // 2
        y = bottom - self.H - cm
        # не выйти за пределы монитора
        x = max(left + 4, min(x, right - self.W - 4))
        y = max(top + 4, min(y, bottom - self.H - 2))
        self.win.geometry(f"{self.W}x{self.H}+{int(x)}+{int(y)}")
        try:
            self.win.attributes("-topmost", True)
        except Exception:
            pass

    # --- клики ---

    def _zone(self, x):
        b = self._s(34 if self._modern else 30)
        if x < b:
            return "cancel"
        if x > self.W - b:
            return "stop"
        return None

    def _on_click(self, event):
        if self.state != "recording":
            return
        z = self._zone(event.x)
        if z == "cancel":  # ✕ отменить
            threading.Thread(target=self.app.cancel_recording, daemon=True).start()
        elif z == "stop":  # ■ стоп и распознать
            threading.Thread(target=self.app.request_stop, daemon=True).start()

    def _on_motion(self, event):
        self._set_hover(self._zone(event.x) if self.state == "recording"
                        else None)

    def _set_hover(self, z):
        if z != self._hover:
            self._hover = z
            try:
                self.canvas.configure(cursor="hand2" if z else "")
            except Exception:
                pass

    # --- отрисовка ---

    def _animate(self):
        try:
            if self.state:
                self._draw()
                self._tick += 1
                self._update_live()  # опц. окно живого транскрипта
        except Exception:
            log.exception("Ошибка отрисовки оверлея")
        try:
            self.win.after(90, self._animate)
        except Exception:
            pass  # окно уничтожено

    def _rec_time(self):
        try:
            sec = int(self.app.recorder.total_duration())
            return f"{sec // 60}:{sec % 60:02d}"
        except Exception:
            return "0:00"

    def _pill(self):
        """Тёмная пилюля с тонким кантом (скругление — цветовым ключом)."""
        c, W, H = self.canvas, self.W, self.H
        r = H // 2
        if self._round:
            c.create_oval(0, 0, H - 1, H - 1, fill=BG, outline=EDGE)
            c.create_oval(W - H, 0, W - 1, H - 1, fill=BG, outline=EDGE)
            c.create_rectangle(r, 0, W - r, H, fill=BG, outline="")
            c.create_line(r, 0, W - r, 0, fill=EDGE)
            c.create_line(r, H - 1, W - r, H - 1, fill=EDGE)

    def _draw_modern(self):
        """Современная пилюля (тема animated/obsidian): крупные кнопки,
        моно-таймер, волна дышащих точек в стиле Aqua Voice."""
        c, s = self.canvas, self._s
        c.delete("all")
        W, H = self.W, self.H
        mid = H // 2
        self._pill()
        if self.state == "recording":
            r = s(12)
            # ✕ отмена
            bg = "#3a3a44" if self._hover == "cancel" else "#2b2b32"
            cx = s(7) + r
            c.create_oval(cx - r, mid - r, cx + r, mid + r, fill=bg, outline="")
            a = s(4)
            c.create_line(cx - a, mid - a, cx + a, mid + a,
                          fill="#b6b6bf", width=s(2), capstyle="round")
            c.create_line(cx + a, mid - a, cx - a, mid + a,
                          fill="#b6b6bf", width=s(2), capstyle="round")
            # пульс записи + таймер
            pr = s(2.6) + s(1.3) * abs((self._tick % 14) / 7.0 - 1.0)
            c.create_oval(s(38) - pr, mid - pr, s(38) + pr, mid + pr,
                          fill=DANGER, outline="")
            c.create_text(s(45), mid, anchor="w", fill=TEXT,
                          text=self._rec_time(), font=self._tfont)
            # волна точек: размер и яркость дышат громкостью голоса;
            # основной путь — сглаженный Pillow-рендер со свечением
            try:
                levels = self.app.recorder.norm_levels(15)
            except Exception:
                levels = []
            x0, x1 = s(98), W - s(40)
            if not self._wave_pil(levels, x0, x1):
                n = 13
                lv15 = levels[-n:]
                step = (x1 - x0) / max(1, n - 1)
                for i in range(n):
                    lv = lv15[i] if i < len(lv15) else 0.0
                    rad = s(2.0) + s(2.9) * lv
                    try:
                        col = theme.lerp_hex("#2a5240", ACCENT,
                                             0.35 + 0.65 * lv)
                    except Exception:
                        col = ACCENT
                    x = x0 + i * step
                    c.create_oval(x - rad, mid - rad, x + rad, mid + rad,
                                  fill=col, outline="")
            # ■ стоп
            bg = "#f2626a" if self._hover == "stop" else DANGER
            cx = W - s(7) - r
            c.create_oval(cx - r, mid - r, cx + r, mid + r, fill=bg, outline="")
            q = s(4.2)
            c.create_rectangle(cx - q, mid - q, cx + q, mid + q,
                               fill="#ffffff", outline="")
        else:  # processing
            c.create_text(s(18), mid, anchor="w", fill=TEXT,
                          text="распознаю…", font=("Segoe UI", 10))
            for i in range(3):
                on = (self._tick // 2) % 3 == i
                x = W - s(24) - (2 - i) * s(12)
                rr = s(3.2) if on else s(2.2)
                c.create_oval(x - rr, mid - rr, x + rr, mid + rr,
                              fill=ACCENT if on else "#4a4a52", outline="")

    def _wave_pil(self, levels, x0, x1):
        """Волна точек через Pillow: сглаживание и мягкое свечение (канва
        так не умеет). Рисуем полосу 3x и сжимаем LANCZOS; полоса лежит
        целиком на теле пилюли, с колор-ключом не пересекается.
        False — Pillow недоступна, рисуем фолбэк на канве."""
        try:
            from PIL import Image, ImageDraw, ImageFilter, ImageTk
        except Exception:
            return False
        try:
            S = 3
            w, h = int(x1 - x0), self.H
            n = 15
            lv15 = levels[-n:]  # уже нормированы norm_levels (0..1)
            if not hasattr(self, "_dots"):
                self._dots = {}
            im = Image.new("RGB", (w * S, h * S), BG)
            step = (w * S) / max(1, n - 1)
            pad_edge = self._s(4) * S
            for i in range(n):
                lv = lv15[i] if i < len(lv15) else 0.0
                b = min(9, int(lv * 9))
                sp = self._dots.get(b)
                if sp is None:
                    rad = int((self._s(2.1) + self._s(3.1) * b / 9) * S)
                    box = rad * 5
                    try:
                        col = theme.lerp_hex("#2a5240", ACCENT,
                                             0.3 + 0.7 * b / 9)
                    except Exception:
                        col = ACCENT
                    sp = Image.new("RGBA", (box, box), (0, 0, 0, 0))
                    d = ImageDraw.Draw(sp)
                    cx = box // 2
                    d.ellipse((cx - rad, cx - rad, cx + rad, cx + rad),
                              fill=col)
                    sp = sp.filter(ImageFilter.GaussianBlur(rad * 0.55))
                    d = ImageDraw.Draw(sp)
                    cr = max(1, int(rad * 0.66))
                    d.ellipse((cx - cr, cx - cr, cx + cr, cx + cr), fill=col)
                    self._dots[b] = sp
                x = int(pad_edge + i * (w * S - 2 * pad_edge) /
                        max(1, n - 1)) - sp.width // 2
                y = (h * S) // 2 - sp.height // 2
                im.paste(sp, (x, y), sp)
            im = im.resize((w, h), Image.LANCZOS)
            self._wave_img = ImageTk.PhotoImage(im)
            self.canvas.create_image(x0, 0, anchor="nw",
                                     image=self._wave_img)
            return True
        except Exception:
            return False

    def _draw(self):
        if self._modern:
            return self._draw_modern()
        c = self.canvas
        s = self._s
        c.delete("all")
        W, H = self.W, self.H
        mid = H // 2
        self._pill()
        if self.state == "recording":
            # ✕ (отмена)
            bg = "#3a3a44" if self._hover == "cancel" else "#2e2e35"
            c.create_oval(s(6), s(6), s(24), s(24), fill=bg, outline="")
            c.create_line(s(11), s(11), s(19), s(19), fill="#b6b6bf", width=s(2))
            c.create_line(s(19), s(11), s(11), s(19), fill="#b6b6bf", width=s(2))
            # ■ (стоп) в красном круге
            bg = "#f2626a" if self._hover == "stop" else DANGER
            c.create_oval(W - s(24), s(6), W - s(6), s(24), fill=bg, outline="")
            c.create_rectangle(W - s(19), s(11), W - s(11), s(19),
                               fill="#ffffff", outline="")
            # пульсирующая точка записи + таймер
            pr = s(2.4) + s(1.2) * abs((self._tick % 14) / 7.0 - 1.0)
            c.create_oval(s(32) - pr, mid - pr, s(32) + pr, mid + pr,
                          fill=DANGER, outline="")
            c.create_text(s(39), mid, anchor="w", fill=TEXT,
                          text=self._rec_time(), font=self._tfont)
            # эквалайзер по уровням микрофона (norm_levels: тишина -> ноль)
            try:
                levels = self.app.recorder.norm_levels(17)
            except Exception:
                levels = []
            n = 17
            x0, x1 = s(76), W - s(32)
            step = (x1 - x0) / n
            bw = max(1, int(1.6 * self.k))
            for i in range(n):
                lv = levels[i] if i < len(levels) else 0.0
                h = s(1.4) + s(7) * lv
                c.create_line(x0 + i * step, mid - h, x0 + i * step, mid + h,
                              fill=ACCENT, width=bw, capstyle="round")
        else:  # processing: только текст и бегущие точки (кнопки уже неактивны)
            c.create_text(s(16), mid, anchor="w", fill=TEXT,
                          text="распознаю…", font=("Segoe UI", 9))
            for i in range(3):
                on = (self._tick // 2) % 3 == i
                x = W - s(22) - (2 - i) * s(11)
                rr = s(3) if on else s(2)
                c.create_oval(x - rr, mid - rr, x + rr, mid + rr,
                              fill=ACCENT if on else "#4a4a52", outline="")
