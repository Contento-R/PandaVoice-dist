@echo off
rem ASCII only in this file! Cyrillic in .bat breaks cmd.exe parsing on
rem non-Russian Windows locales (codepage line-splitting bug).
setlocal EnableExtensions
cd /d "%~dp0"
title Panda Voice App - install

echo ============================================================
echo  Panda Voice App - installer (offline speech-to-text)
echo ============================================================
echo.

echo [0/6] Removing Windows "downloaded file" locks (SmartScreen)...
powershell -NoProfile -Command "Get-ChildItem -Recurse -File | Unblock-File" >nul 2>&1

echo [1/6] Looking for Python 3.12 / 3.11...
set "PYCMD="
py -3.12 -V >nul 2>&1
if not errorlevel 1 set "PYCMD=py -3.12"
if not defined PYCMD (
  py -3.11 -V >nul 2>&1
  if not errorlevel 1 set "PYCMD=py -3.11"
)
if not defined PYCMD (
  python -c "import sys; sys.exit(0 if sys.version_info[:2] in ((3,11),(3,12)) else 1)" >nul 2>&1
  if not errorlevel 1 set "PYCMD=python"
)
if not defined PYCMD (
  echo     Python not found - trying to install via winget...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  py -3.12 -V >nul 2>&1
  if not errorlevel 1 set "PYCMD=py -3.12"
)
if not defined PYCMD if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PYCMD="%LocalAppData%\Programs\Python\Python312\python.exe""
if not defined PYCMD (
  echo.
  echo ERROR: Python 3.11/3.12 is not installed.
  echo Install it manually from https://www.python.org/downloads/
  echo ^(check "Add python.exe to PATH" in the installer^) and run install.bat again.
  pause
  exit /b 1
)
echo     Found: %PYCMD%

rem --- graphical installer window when tkinter is available ---
set "PYWCMD="
if "%PYCMD%"=="py -3.12" set "PYWCMD=pyw -3.12"
if "%PYCMD%"=="py -3.11" set "PYWCMD=pyw -3.11"
if "%PYCMD%"=="python" set "PYWCMD=pythonw"
if defined PYWCMD (
  %PYCMD% -c "import tkinter" >nul 2>&1
  if not errorlevel 1 (
    echo     Opening the graphical installer window...
    start "" %PYWCMD% install_gui.py
    exit /b 0
  )
)
echo     No graphical toolkit found - continuing in this console window.

echo.
echo [2/6] Creating virtual environment...
if not exist "venv\Scripts\python.exe" (
  %PYCMD% -m venv venv
  if errorlevel 1 goto :fail
)
set "VPY=venv\Scripts\python.exe"
"%VPY%" -m pip install --upgrade pip
if errorlevel 1 goto :fail

echo.
echo [3/6] Installing dependencies: PyTorch CPU build ^(NO CUDA^) + libraries...
echo     This may take 5-15 minutes depending on your internet speed.
"%VPY%" -m pip install torch --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto :fail
"%VPY%" -m pip install -r requirements.txt
if errorlevel 1 goto :fail
rem transformers from a pinned git snapshot (Qwen3-ASR is not in a pip release
rem yet); exactly the commit the app was tested with. No git binary required.
"%VPY%" -m pip install "https://github.com/huggingface/transformers/archive/7ea2320c76117e6742364808a666ef6f2fb40a67.zip"
if errorlevel 1 goto :fail

echo.
echo [4/6] Downloading the speech model (~1.5 GB, one time)...
"%VPY%" download_model.py
if errorlevel 1 goto :fail

echo.
echo [5/6] Creating desktop shortcut...
"%VPY%" -c "import setup_wizard; setup_wizard.make_desktop_shortcut()"
if errorlevel 1 echo     Could not create the shortcut - use start.bat instead.

echo.
echo [6/6] Installation finished!
echo.
echo   Hotkeys: press Alt TWICE to start recording,
echo            press Alt ONCE to stop, recognize and paste the text.
echo.
set /p RUNSETUP="Run the microphone setup wizard now? [Y/n]: "
if /i not "%RUNSETUP%"=="n" "%VPY%" main.py --setup
echo.
echo All set. Start Panda Voice with the desktop shortcut.
pause
exit /b 0

:fail
echo.
echo ERROR at the current step - details above.
echo Most common fix: check your internet connection and run install.bat
echo again - installation resumes from where it stopped.
pause
exit /b 1
