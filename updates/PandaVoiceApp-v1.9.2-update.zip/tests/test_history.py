"""Тесты истории вводов. Запуск: python tests/test_history.py"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import history


def _use_tmp():
    history.HISTORY_PATH = Path(tempfile.mkdtemp()) / "history.jsonl"


def test_append_and_read():
    _use_tmp()
    assert history.read_last() == []
    history.append("привет мир", 3.2, 1.1)
    history.append("вторая запись", 5.0, 2.0)
    got = history.read_last()
    assert len(got) == 2
    assert got[0]["text"] == "привет мир"
    assert got[1]["text"] == "вторая запись"
    assert got[0]["audio_sec"] == 3.2
    assert got[1]["ts"]


def test_read_last_n():
    _use_tmp()
    for i in range(10):
        history.append(f"запись {i}", 1, 1)
    got = history.read_last(3)
    assert [e["text"] for e in got] == ["запись 7", "запись 8", "запись 9"]


def test_trim():
    _use_tmp()
    for i in range(25):
        history.append(f"з{i}", 1, 1, max_entries=10)
    lines = history.HISTORY_PATH.read_text(encoding="utf-8").splitlines()
    assert len(lines) <= 20  # не больше 2×лимита
    got = history.read_last(100)
    assert got[-1]["text"] == "з24"  # свежие записи не теряются


def test_clear():
    _use_tmp()
    history.append("что-то", 1, 1)
    history.clear()
    assert history.read_last() == []
    history.clear()  # повторная очистка не падает


def test_corrupt_line_skipped():
    _use_tmp()
    history.append("нормальная", 1, 1)
    with open(history.HISTORY_PATH, "a", encoding="utf-8") as f:
        f.write("НЕ JSON\n")
    history.append("ещё одна", 1, 1)
    got = history.read_last()
    assert [e["text"] for e in got] == ["нормальная", "ещё одна"]


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов истории прошли")
