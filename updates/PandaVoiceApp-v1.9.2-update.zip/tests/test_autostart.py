"""Тесты пути автозапуска. Запуск: python tests/test_autostart.py

Проверяем чтение папки, на которую ведёт автозапуск: по нему приложение
понимает, что ярлык остался от СТАРОЙ установки, и перенаправляет его.
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import setup_wizard as sw


def _tmp_entry(text):
    p = Path(tempfile.mkdtemp()) / "panda-voice.desktop"
    p.write_text(text, encoding="utf-8")
    sw._LINUX_AUTOSTART = p
    return p


def test_no_autostart_returns_none():
    sw._LINUX_AUTOSTART = Path(tempfile.mkdtemp()) / "нет.desktop"
    assert sw.autostart_enabled() is False
    assert sw.autostart_target_dir() is None


def test_reads_target_dir():
    _tmp_entry("[Desktop Entry]\nType=Application\nName=Panda Voice\n"
               "Exec=/opt/py /home/u/PandaVoiceApp-v1.1.2/main.py\n"
               "Path=/home/u/PandaVoiceApp-v1.1.2\nTerminal=false\n")
    assert sw.autostart_enabled() is True
    assert sw.autostart_target_dir() == Path("/home/u/PandaVoiceApp-v1.1.2")


def test_entry_without_path_line():
    _tmp_entry("[Desktop Entry]\nType=Application\nName=Panda Voice\n")
    assert sw.autostart_target_dir() is None


def test_written_entry_points_to_current_dir():
    # enable_autostart пишет ТЕКУЩУЮ папку приложения — на неё и чинится ярлык
    _tmp_entry("[Desktop Entry]\nPath=/старая/папка\n")
    sw.enable_autostart()
    assert sw.autostart_target_dir().resolve() == sw.APP_DIR.resolve()


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов автозапуска прошли")
