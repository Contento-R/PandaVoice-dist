"""Тест потоковой выдачи фрагментов рекордером (без микрофона и модели).

Запуск: python tests/test_streaming.py
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import vad
vad._failed = True  # синтетический шум — не «речь» для VAD; тестируем RMS-путь

from recorder import SR, Recorder


def _fill(rec, audio, block=1600):
    """Загоняем аудио в рекордер так, как это делает аудио-callback."""
    for i in range(0, len(audio), block):
        b = audio[i:i + block]
        rec.level_history.append(float(np.sqrt((b ** 2).mean())))
        with rec._lock:
            rec._chunks.append(b)
            rec._total += len(b)


def _speech(sec, seed=0):
    return np.random.default_rng(seed).normal(0, 0.25, int(sec * SR)).astype(np.float32)


def _pause(sec):
    return np.random.default_rng(1).normal(0, 0.001, int(sec * SR)).astype(np.float32)


def test_no_chunk_until_enough():
    r = Recorder()
    assert r.take_chunk(15, 30) is None  # пусто
    _fill(r, _speech(20))
    assert r.take_chunk(15, 30) is None  # 20 c < max 30 — рано


def test_chunk_cut_in_pause_and_rest_preserved():
    r = Recorder()
    audio = np.concatenate([_speech(18, 2), _pause(1.0), _speech(18, 3)])
    _fill(r, audio)
    c = r.take_chunk(15, 30)
    assert c is not None
    assert 15 * SR <= len(c) <= 30 * SR
    # срез в паузе
    tail_of_chunk = c[-800:]
    assert float(np.abs(tail_of_chunk).max()) < 0.05
    # ничего не потеряно: фрагмент + остаток == исходник
    with r._lock:
        rest = np.concatenate(r._chunks)
    assert np.array_equal(np.concatenate([c, rest]), audio)
    # остатка (<30 c) уже не хватает на второй фрагмент
    assert r.take_chunk(15, 30) is None


def test_levels_tracked():
    r = Recorder()
    _fill(r, _speech(2))
    assert len(r.level_history) > 0
    assert max(r.level_history) > 0.1


def test_total_duration():
    r = Recorder()
    audio = np.concatenate([_speech(35, 4), _pause(1.0), _speech(5, 5)])
    _fill(r, audio)
    r.take_chunk(15, 30)  # забрали кусок
    assert abs(r.total_duration() - len(audio) / SR) < 0.01  # total не уменьшился


def test_eager_drain_on_silence():
    r = Recorder()
    # 6 c речи + 1 c тишины: eager должен забрать фразу, не дожидаясь max
    _fill(r, np.concatenate([_speech(6, 7), _pause(1.0)]))
    assert r.take_chunk(4, 9, eager=False) is None  # без eager — ждём max
    c = r.take_chunk(4, 9, eager=True)
    assert c is not None and len(c) >= 4 * SR
    # остаток — только хвостик тишины
    with r._lock:
        rest = sum(len(x) for x in r._chunks)
    assert rest <= int(0.3 * SR)


def test_eager_no_drain_while_speaking():
    r = Recorder()
    _fill(r, _speech(6, 8))  # речь без паузы в хвосте
    assert r.take_chunk(4, 9, eager=True) is None


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов стриминга прошли")
