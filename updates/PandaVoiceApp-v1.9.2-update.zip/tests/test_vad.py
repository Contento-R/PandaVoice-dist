"""Тесты Silero VAD. Запуск: python tests/test_vad.py"""
import sys
import wave
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import vad


def _speech():
    with wave.open(str(vad.MODEL_PATH.parent / "test.wav"), "rb") as w:
        return np.frombuffer(w.readframes(w.getnframes()),
                             dtype="<i2").astype(np.float32) / 32768.0


def test_speech_detected():
    assert vad.has_speech(_speech()) is True


def test_silence_and_noise_rejected():
    assert vad.has_speech(np.zeros(vad.SR, dtype=np.float32)) is False
    noise = np.random.default_rng(0).normal(
        0, 0.05, vad.SR * 2).astype(np.float32)
    assert vad.has_speech(noise) is False


def test_tail_silence():
    a = np.concatenate([_speech()[: vad.SR * 3],
                        np.zeros(vad.SR, dtype=np.float32)])
    assert vad.tail_is_silent(a, 0.9) is True
    assert vad.tail_is_silent(_speech(), 0.9) is False


def test_unavailable_returns_none():
    old = vad._failed
    vad._failed = True
    try:
        assert vad.has_speech(np.zeros(vad.SR, dtype=np.float32)) is None
        assert vad.tail_is_silent(np.zeros(vad.SR * 2, dtype=np.float32),
                                  0.9) is None
    finally:
        vad._failed = old


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов VAD прошли")
