"""Тесты библиотеки слов. Запуск: python tests/test_userdict.py"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import userdict


def _tmp():
    userdict.PATH = Path(tempfile.mkdtemp()) / "userdict.json"


def test_empty_when_missing():
    _tmp()
    assert userdict.terms() == []
    assert userdict.suggest([]) == []


def test_add_and_terms():
    _tmp()
    userdict.add("CEX")
    userdict.add("стейкинг")
    assert "CEX" in userdict.terms()
    assert "стейкинг" in userdict.terms()


def test_add_preserves_case_and_dedups():
    _tmp()
    userdict.add("DeFi")
    userdict.add("defi")  # тот же термин в другом регистре — не дубль
    assert userdict.terms() == ["DeFi"]


def test_remove():
    _tmp()
    userdict.add("токен")
    userdict.remove("Токен")  # без учёта регистра
    assert userdict.terms() == []


def test_add_clears_dismissed():
    _tmp()
    userdict.dismiss("ликвидность")
    assert userdict.load()["dismissed"] == ["ликвидность"]
    userdict.add("ликвидность")
    assert userdict.load()["dismissed"] == []
    assert "ликвидность" in userdict.terms()


def test_suggest_frequency_threshold():
    _tmp()
    entries = [{"text": "стейкинг это стейкинг и опять стейкинг"}]  # 3 раза
    assert userdict.suggest(entries, min_count=4) == []
    assert userdict.suggest(entries, min_count=3) == [("стейкинг", 3)]


def test_suggest_skips_short_and_known():
    _tmp()
    userdict.add("токен")
    entries = [{"text": "токен токен токен токен и сразу сразу сразу сразу"}]
    # позитивный контроль: без extra_known «сразу» предлагается
    assert dict(userdict.suggest(entries, min_count=3)).get("сразу") == 4
    # «токен» уже в библиотеке; «сразу» исключается через extra_known
    res = userdict.suggest(entries, min_count=3, extra_known=["сразу"])
    assert res == []


def test_add_many_import():
    _tmp()
    n = userdict.add_many("стейкинг, аирдроп\nликвидность; DeFi\nстейкинг")
    assert n == 4  # дубль «стейкинг» не считается
    assert set(userdict.terms()) == {"стейкинг", "аирдроп",
                                     "ликвидность", "DeFi"}
    # повторный импорт того же списка ничего не добавляет
    assert userdict.add_many("стейкинг, аирдроп") == 0


def test_add_many_phrases_and_junk():
    _tmp()
    n = userdict.add_many("- смарт-контракт\n• пул ликвидности\n\n,,;;\n")
    assert n == 2
    assert "смарт-контракт" in userdict.terms()
    assert "пул ликвидности" in userdict.terms()  # фраза сохраняется целиком


def test_load_survives_malformed_types():
    _tmp()
    # строка вместо списка не должна рассыпаться на буквы
    userdict.PATH.write_text('{"terms": "CEX", "dismissed": 42}',
                             encoding="utf-8")
    assert userdict.load() == {"terms": [], "dismissed": []}
    userdict.PATH.write_text("не json вовсе", encoding="utf-8")
    assert userdict.terms() == []


def test_suggest_picks_common_form():
    _tmp()
    entries = [{"text": "DeFi defi DeFi децентрализация"}]
    # слово учитывается без регистра (3 раза), показывается частой формой
    res = dict(userdict.suggest(entries, min_count=3))
    assert res.get("DeFi") == 3


def test_suggest_ignores_short_acronyms_by_default():
    _tmp()
    # 3-буквенные акронимы (CEX/DEX) в авто-предложения не попадают —
    # слишком шумно; их добавляют вручную. Порог длины по умолчанию 4.
    entries = [{"text": "CEX CEX CEX CEX DEX DEX DEX DEX"}]
    assert userdict.suggest(entries, min_count=3) == []
    # при явном снижении порога длины — попадают
    got = dict(userdict.suggest(entries, min_count=3, min_len=3))
    assert got.get("CEX") == 4 and got.get("DEX") == 4


def test_suggest_dismissed_excluded():
    _tmp()
    userdict.dismiss("арбитраж")
    entries = [{"text": "арбитраж арбитраж арбитраж арбитраж"}]
    assert userdict.suggest(entries, min_count=3) == []


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов библиотеки слов прошли")
