"""Тесты чанкования длинных записей — синтетическое аудио, без модели.

Запуск: python tests/test_chunking.py
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chunking import find_cut_points, split_on_silence

SR = 16000


def synth_speech_with_pauses(n_bursts=13, burst_sec=7.5, pause_sec=0.8, seed=1):
    """«Речь»: шумовые всплески, разделённые тихими паузами."""
    rng = np.random.default_rng(seed)
    parts = []
    for _ in range(n_bursts):
        parts.append(rng.normal(0, 0.25, int(burst_sec * SR)).astype(np.float32))
        parts.append(rng.normal(0, 0.001, int(pause_sec * SR)).astype(np.float32))
    return np.concatenate(parts)


def test_short_audio_untouched():
    audio = np.random.default_rng(0).normal(0, 0.2, 45 * SR).astype(np.float32)
    assert find_cut_points(audio, SR) == []
    parts = split_on_silence(audio, SR)
    assert len(parts) == 1 and parts[0] is audio


def test_cuts_land_in_pauses():
    audio = synth_speech_with_pauses()  # ~108 c
    cuts = find_cut_points(audio, SR)
    assert cuts, "длинная запись должна порезаться"
    for cut in cuts:
        window = audio[max(0, cut - 800):cut + 800]  # +-50 мс вокруг среза
        assert float(np.abs(window).max()) < 0.05, f"срез {cut} попал в речь"


def test_chunk_sizes_and_lossless():
    audio = synth_speech_with_pauses()
    parts = split_on_silence(audio, SR)
    assert len(parts) >= 2
    for p in parts[:-1]:
        assert 30 * SR - SR <= len(p) <= 60 * SR, f"фрагмент {len(p)/SR:.1f} c вне [30..60]"
    assert len(parts[-1]) <= 60 * SR
    # без потерь и дублей: конкатенация фрагментов == исходник
    glued = np.concatenate(parts)
    assert glued.shape == audio.shape
    assert np.array_equal(glued, audio)


def test_no_silence_hard_split():
    rng = np.random.default_rng(2)
    audio = rng.normal(0, 0.3, 130 * SR).astype(np.float32)  # сплошная «речь»
    parts = split_on_silence(audio, SR)
    assert all(len(p) <= 60 * SR for p in parts)
    assert np.array_equal(np.concatenate(parts), audio)
    # жёсткие срезы ровно по 60 с
    assert len(parts[0]) == 60 * SR


def test_ten_minute_recording():
    audio = synth_speech_with_pauses(n_bursts=70, burst_sec=7.5, pause_sec=1.0)  # ~10 мин
    parts = split_on_silence(audio, SR)
    assert all(len(p) <= 60 * SR for p in parts)
    assert np.array_equal(np.concatenate(parts), audio)


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов чанкования прошли")
