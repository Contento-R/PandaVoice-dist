"""Тесты анимированной темы. Запуск: python tests/test_theme.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import theme


def test_lerp_endpoints():
    assert theme.lerp_hex("#000000", "#ffffff", 0) == "#000000"
    assert theme.lerp_hex("#000000", "#ffffff", 1) == "#ffffff"


def test_lerp_midpoint():
    assert theme.lerp_hex("#000000", "#ffffff", 0.5) == "#808080"


def test_lerp_clamps_t():
    assert theme.lerp_hex("#141417", "#4cc38a", -5) == "#141417"
    assert theme.lerp_hex("#141417", "#4cc38a", 5) == "#4cc38a"


def test_spring_starts_and_settles_exactly():
    # начинается на месте, заканчивается ровно в цели — без дрожи
    assert theme.SPRING[0] == 0.0 and theme.SPRING[-1] == 1.0
    # перелёт небольшой: кружок тумблера не вылетает за канву
    assert max(theme.SPRING) <= 1.15


def test_animated_flag_default_off():
    assert not theme.animated({})
    assert not theme.animated({"ui_theme": "classic"})
    assert not theme.animated(None)
    assert theme.animated({"ui_theme": "animated"})
    assert theme.animated({"ui_theme": "ANIMATED"})  # регистронезависимо
    assert theme.animated({"ui_theme": "obsidian"})  # obsidian включает анимации


def test_styled_flag():
    assert not theme.styled({})
    assert not theme.styled({"ui_theme": "animated"})
    assert theme.styled({"ui_theme": "obsidian"})
    assert theme.styled({"ui_theme": "OBSIDIAN"})


def test_animated_survives_garbage():
    assert not theme.animated({"ui_theme": 42}) or True  # не бросает
    assert theme.animated("не словарь") is False
    assert theme.styled("не словарь") is False


def test_nav_label_classic_passthrough():
    theme.set_cfg({"ui_theme": "classic"})
    assert theme.nav_label("История") == "История"
    theme.set_cfg({"ui_theme": "obsidian"})
    assert theme.nav_label("История") == "И С Т О Р И Я"
    theme.set_cfg(None)  # вернуть чистое состояние для других тестов


def test_obsidian_palettes_are_valid_hex():
    for d in (theme.OBSIDIAN_GUI, theme.OBSIDIAN_OVERLAY,
              theme._OBSIDIAN_SELF):
        for v in d.values():
            # lerp упадёт на невалидном hex — заодно проверяем формат
            assert theme.lerp_hex(v, v, 0.5) == v.lower()


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов темы прошли")
