"""Тесты словаря исправлений. Запуск: python tests/test_corrections.py"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import corrections


def _tmp():
    corrections.PATH = Path(tempfile.mkdtemp()) / "corrections.json"


def test_apply_basic():
    _tmp()
    corrections.save({"войс": "Voice", "цекс": "CEX"})
    assert corrections.apply("это панда войс") == "это панда Voice"
    # регистр первой буквы источника переносится
    assert corrections.apply("Войс работает") == "Voice работает"
    assert corrections.apply("на бирже Цекс") == "на бирже CEX"


def test_apply_no_table():
    _tmp()
    assert corrections.apply("любой текст") == "любой текст"


def test_learn_word_replacements():
    _tmp()
    pairs = corrections.learn(
        "у нас есть пулы по блокчейну робин хун",
        "у нас есть пулы по блокчейну робин гуд")
    assert pairs == {"хун": "гуд"}
    # выученное сразу применяется
    assert corrections.apply("робин хун") == "робин гуд"


def test_learn_multiple():
    _tmp()
    pairs = corrections.learn("это цекс и декс терминал",
                              "это CEX и DEX терминал")
    assert pairs == {"цекс": "CEX", "декс": "DEX"}


def test_learn_ignores_length_mismatch():
    _tmp()
    # вставка/удаление слов не порождает ложных пар
    pairs = corrections.learn("привет мир", "привет прекрасный мир")
    assert pairs == {}


def test_apply_preserves_untouched():
    _tmp()
    corrections.save({"хун": "гуд"})
    assert corrections.apply("робин хундай хун") == "робин хундай гуд"  # целое слово


def test_preposition_learned_as_context_pair():
    _tmp()
    # правка предлога учится ТОЛЬКО в паре со следующим словом
    pairs = corrections.learn("я положил книгу в стол",
                              "я положил книгу на стол")
    assert pairs == {"в стол": "на стол"}
    # применяется в этом сочетании...
    assert corrections.apply("положил в стол") == "положил на стол"
    # ...но НЕ трогает другие «в» — глобальной замены нет
    assert corrections.apply("живу в москве в центре") == "живу в москве в центре"


def test_preposition_bigram_word_boundary():
    _tmp()
    corrections.save({"в стол": "на стол"})
    # «в столе» (другое слово) не задевается
    assert corrections.apply("книга в столе") == "книга в столе"
    # регистр первой буквы сохраняется
    assert corrections.apply("В стол posit, положил") == "На стол posit, положил"


def test_lone_preposition_not_learned():
    _tmp()
    # без надёжного контекста (следующее слово тоже изменилось) — не учим
    pairs = corrections.learn("он был в кафе", "он был на пляже")
    assert "в" not in pairs and all(" " in k or k != "в" for k in pairs)


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов исправлений прошли")
