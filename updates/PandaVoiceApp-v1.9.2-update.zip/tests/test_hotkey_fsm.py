"""Юнит-тесты машины состояний хоткея — на фейковых событиях, без Windows.

Запуск: python tests/test_hotkey_fsm.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from hotkey_fsm import IDLE, NEUTRALIZE, PAUSED, PROCESSING, RECORDING, START, STOP, HotkeyFSM


def tap(fsm, t, dur=0.05):
    """Полный тап: down+up. Возвращает (action_down, action_up)."""
    return fsm.on_key_down(t), fsm.on_key_up(t + dur)


def new_fsm():
    return HotkeyFSM(double_press_sec=0.4, debounce_sec=0.5, max_tap_sec=0.5)


def test_double_tap_starts():
    f = new_fsm()
    assert tap(f, 0.0) == (None, None)
    d, u = tap(f, 0.2)
    assert (d, u) == (None, START)
    assert f.state == RECORDING


def test_slow_taps_do_not_start():
    f = new_fsm()
    tap(f, 0.0)
    d, u = tap(f, 1.0)  # позже интервала 0.4
    assert u is None and f.state == IDLE
    # но этот тап становится первым для следующей пары
    _, u = tap(f, 1.2)
    assert u == START


def test_single_tap_noop():
    f = new_fsm()
    assert tap(f, 0.0) == (None, None)
    assert f.state == IDLE


def test_stop_after_debounce_and_neutralize():
    f = new_fsm()
    tap(f, 0.0)
    tap(f, 0.2)  # START, запись с t=0.25
    d = f.on_key_down(2.0)
    assert d == NEUTRALIZE  # глушим Alt-меню
    u = f.on_key_up(2.05)
    assert u == STOP
    assert f.state == PROCESSING


def test_triple_tap_debounce():
    f = new_fsm()
    tap(f, 0.0)
    tap(f, 0.2)  # START (запись с 0.25)
    d, u = tap(f, 0.4)  # третий тап сразу — дребезг
    assert d == NEUTRALIZE and u is None
    assert f.state == RECORDING  # запись не сломана
    _, u = tap(f, 2.0)  # а позже — нормальный стоп
    assert u == STOP


def test_alt_combo_does_not_stop():
    f = new_fsm()
    tap(f, 0.0)
    tap(f, 0.2)  # START
    f.on_key_down(2.0)
    f.on_other_key(2.1)  # Alt+Tab
    u = f.on_key_up(2.2)
    assert u is None
    assert f.state == RECORDING


def test_long_hold_is_not_tap():
    f = new_fsm()
    f.on_key_down(0.0)
    assert f.on_key_up(0.8) is None  # дольше max_tap_sec
    assert f.state == IDLE
    # удержание не считается первым тапом двойного нажатия
    _, u = tap(f, 0.9)
    assert u is None


def test_key_repeat_ignored():
    f = new_fsm()
    f.on_key_down(0.0)
    assert f.on_key_down(0.1) is None  # авто-повтор при удержании
    assert f.on_key_down(0.2) is None
    f.on_key_up(0.3)
    _, u = tap(f, 0.5)
    assert u == START  # удержание+тап в пределах интервала = двойное нажатие


def test_other_key_breaks_double():
    f = new_fsm()
    tap(f, 0.0)
    f.on_other_key(0.1)  # напечатал букву между тапами
    _, u = tap(f, 0.2)
    assert u is None  # двойное нажатие разорвано
    assert f.state == IDLE


def test_pause_ignores_everything():
    f = new_fsm()
    f.pause()
    assert tap(f, 0.0) == (None, None)
    assert tap(f, 0.2) == (None, None)
    assert f.state == PAUSED
    f.resume()
    assert f.state == IDLE
    tap(f, 1.0)
    _, u = tap(f, 1.2)
    assert u == START


def test_processing_ignores_taps():
    f = new_fsm()
    tap(f, 0.0)
    tap(f, 0.2)
    tap(f, 2.0)  # STOP -> PROCESSING
    assert f.state == PROCESSING
    assert tap(f, 3.0) == (None, None)
    assert tap(f, 3.2) == (None, None)
    f.reset_idle()
    assert f.state == IDLE
    tap(f, 4.0)
    _, u = tap(f, 4.2)
    assert u == START


def test_force_stop():
    f = new_fsm()
    assert f.force_stop() is False  # вне записи — нет
    tap(f, 0.0)
    tap(f, 0.2)
    assert f.force_stop() is True
    assert f.state == PROCESSING


def test_reset_idle_keeps_pause():
    f = new_fsm()
    f.pause()
    f.reset_idle()
    assert f.state == PAUSED


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов FSM прошли")
