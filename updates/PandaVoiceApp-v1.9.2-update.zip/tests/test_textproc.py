"""Тесты склейки фрагментов с пунктуацией. Запуск: python tests/test_textproc.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from textproc import _strip_seam_period, join_texts


def test_empty_and_single():
    assert join_texts([]) == ""
    assert join_texts(["", "  ", None]) == ""
    assert join_texts(["привет мир"]) == "Привет мир."
    assert join_texts(["Привет, мир!"]) == "Привет, мир!"


def test_no_dot_added_between_pieces():
    # пауза для обдумывания не завершает предложение — точки на стыке нет
    got = join_texts(["я хочу увидеть как ты распознаешь",
                      "и как долго я могу говорить"])
    assert got == "Я хочу увидеть как ты распознаешь и как долго я могу говорить."


def test_seam_period_stripped():
    # точка в конце промежуточного фрагмента — «привычка» модели, убираем
    got = join_texts(["Смотри, сейчас я попробую наговорить текст.",
                      "что из этого выйдет?"])
    assert got == "Смотри, сейчас я попробую наговорить текст что из этого выйдет?"


def test_question_kept_at_seam():
    # «?» — настоящая интонация: сохраняется, следующий кусок с заглавной
    got = join_texts(["Ты меня слышишь?", "отлично, продолжаем"])
    assert got == "Ты меня слышишь? Отлично, продолжаем."


def test_inner_periods_preserved():
    # точки ВНУТРИ фрагмента модель ставит с контекстом — не трогаем
    got = join_texts(["Первое предложение. Второе началось", "и продолжилось"])
    assert got == "Первое предложение. Второе началось и продолжилось."


def test_ellipsis_kept_at_seam():
    got = join_texts(["Ну не знаю...", "может быть"])
    assert got == "Ну не знаю... Может быть."


def test_comma_ending_continues_phrase():
    got = join_texts(["Соответственно, я хочу,", "Чтобы ты внимательно слушал"])
    assert got == "Соответственно, я хочу, чтобы ты внимательно слушал."


def test_continuation_lowercased():
    got = join_texts(["  первый   кусок ", "Второй кусок"])
    assert got == "Первый кусок второй кусок."


def test_seam_periods_stripped_in_chain():
    got = join_texts(["Первое предложение.", "второе продолжается",
                      "и ещё кусок"])
    assert got == "Первое предложение второе продолжается и ещё кусок."


def test_strip_seam_period_helper():
    assert _strip_seam_period("слово.") == "слово"
    assert _strip_seam_period("слово. ") == "слово"
    assert _strip_seam_period("вопрос?") == "вопрос?"
    assert _strip_seam_period("стой!") == "стой!"
    assert _strip_seam_period("хм…") == "хм…"
    assert _strip_seam_period("хм...") == "хм..."
    assert _strip_seam_period("слово") == "слово"


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов склейки прошли")
