"""Тесты хоткей-комбинаций (парсинг + машина на фейковых событиях, без Windows).

win_hotkeys импортирует keyboard/ctypes — тестируем только чистую логику,
подсунув заглушки. Запуск: python tests/test_hotkeys.py
"""
import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# заглушки для модулей, которых нет/не нужны в песочнице
sys.modules.setdefault("keyboard", types.SimpleNamespace(
    hook=lambda *a, **k: None, unhook=lambda *a, **k: None))

import win_hotkeys as wh


class Ev:
    def __init__(self, name, down, scan=None):
        self.name = name
        self.event_type = "down" if down else "up"
        self.scan_code = scan


def test_parse_combo():
    assert wh._parse_combo("left alt+`") == ({"left alt"}, "`")
    assert wh._parse_combo("right alt+`") == ({"right alt"}, "`")
    assert wh._parse_combo("ctrl+shift+r") == ({"left ctrl", "left shift"}, "r")
    assert wh._parse_combo("alt") is None  # одиночная клавиша
    assert wh._parse_combo("f9") is None


def _listener(rec=None):
    rec = rec if rec is not None else [False]
    calls = []
    fsm = types.SimpleNamespace(state="idle", force_stop=lambda: calls.append("force_stop"))
    lis = wh.HotkeyListener(
        fsm, {"hotkey": "left alt+`", "repaste_key": "right alt+`", "mode": "toggle",
              "correct_key": "f7", "open_window_key": "left alt+p"},
        on_start=lambda: calls.append("start"),
        on_stop=lambda: calls.append("stop"),
        on_repaste=lambda: calls.append("repaste"),
        is_recording=lambda: rec[0],
        on_correct=lambda: calls.append("correct"),
        on_open=lambda: calls.append("open"))
    lis._dispatch = lambda fn: fn()  # синхронно, без потоков
    return lis, calls


def test_left_alt_grave_toggles_record():
    rec = [False]
    lis, calls = _listener(rec)
    lis._handler(Ev("alt", True))                      # зажали левый Alt
    lis._handler(Ev("`", True, scan=wh.GRAVE_SCAN))    # + `
    assert calls == ["start"]
    rec[0] = True
    lis._fire_t.clear()                                # снять анти-повтор
    lis._handler(Ev("`", True, scan=wh.GRAVE_SCAN))    # ещё раз — стоп
    assert calls == ["start", "force_stop", "stop"]


def test_right_alt_grave_repastes():
    lis, calls = _listener()
    lis._handler(Ev("right alt", True))
    lis._handler(Ev("`", True, scan=wh.GRAVE_SCAN))
    assert calls == ["repaste"]


def test_grave_alone_does_nothing():
    lis, calls = _listener()
    lis._handler(Ev("`", True, scan=wh.GRAVE_SCAN))    # без Alt
    assert calls == []


def test_left_alt_alone_does_nothing():
    lis, calls = _listener()
    lis._handler(Ev("alt", True))
    lis._handler(Ev("alt", False))
    assert calls == []


def test_grave_layout_independent_by_scancode():
    # на русской раскладке name='ё', но scan-код тот же — должно сработать
    lis, calls = _listener()
    lis._handler(Ev("alt", True))
    lis._handler(Ev("ё", True, scan=wh.GRAVE_SCAN))
    assert calls == ["start"]


def test_correct_key_single_tap():
    lis, calls = _listener()
    lis._handler(Ev("f7", True))
    assert calls == ["correct"]
    lis._handler(Ev("f7", True))  # анти-повтор
    assert calls == ["correct"]


def test_open_window_combo():
    lis, calls = _listener()
    lis._handler(Ev("alt", True))
    lis._handler(Ev("p", True))
    assert calls == ["open"]


def test_open_combo_on_russian_layout_by_scancode():
    # на русской раскладке P приходит как «з», но scan-код 25 — тот же
    lis, calls = _listener()
    lis._handler(Ev("alt", True))
    lis._handler(Ev("з", True, scan=25))
    assert calls == ["open"]


def test_media_key_as_correct():
    fsm = types.SimpleNamespace(state="idle", force_stop=lambda: None)
    calls = []
    lis = wh.HotkeyListener(
        fsm, {"hotkey": "left alt+`", "repaste_key": "", "mode": "toggle",
              "correct_key": "play/pause media"},  # медиа-клавиша (Fn-слой)
        on_start=lambda: None, on_stop=lambda: None,
        on_correct=lambda: calls.append("correct"))
    lis._dispatch = lambda fn: fn()
    lis._handler(Ev("play/pause media", True))
    assert calls == ["correct"]


def test_f13_macro_key_as_correct():
    fsm = types.SimpleNamespace(state="idle", force_stop=lambda: None)
    calls = []
    lis = wh.HotkeyListener(
        fsm, {"hotkey": "left alt+`", "repaste_key": "", "mode": "toggle",
              "correct_key": "f13"},  # доп. клавиша макро-клавиатуры
        on_start=lambda: None, on_stop=lambda: None,
        on_correct=lambda: calls.append("correct"))
    lis._dispatch = lambda fn: fn()
    lis._handler(Ev("f13", True))
    assert calls == ["correct"]


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов хоткеев прошли")
