"""Звуковые сигналы: winsound на Windows, синтез тона через sounddevice
на остальных платформах. Любой сбой — тишина, не падение."""
import logging
import threading

log = logging.getLogger("sounds")

try:
    import winsound
except ImportError:
    winsound = None

enabled = True  # выставляется из config.json при старте
style = "classic"  # classic | soft | crystal | bubble (config.json)

# Стили-наборы: короткие тихие тоны с плавными краями вместо резкого
# системного Beep. Частота 0 = пауза. classic — winsound, как раньше.
PACKS = {
    "soft": {  # «тик-так» поворотника
        "start": [(600, 45)], "stop": [(430, 55)],
        "ready": [(520, 60), (0, 30), (660, 70)],
        "limit": [(330, 180)],
        "error": [(260, 70), (0, 40), (260, 70)], "amp": 0.12},
    "crystal": {  # чистые высокие «колокольчики»
        "start": [(880, 42)], "stop": [(587, 55)],
        "ready": [(659, 50), (0, 25), (988, 75)],
        "limit": [(392, 170)],
        "error": [(311, 60), (0, 35), (311, 60)], "amp": 0.10},
    "bubble": {  # «пузырьки»: короткие глиссандо вверх/вниз
        "start": [(320, 40), (540, 48)], "stop": [(540, 40), (320, 52)],
        "ready": [(420, 45), (560, 45), (760, 65)],
        "limit": [(260, 180)],
        "error": [(240, 70), (0, 40), (200, 80)], "amp": 0.14},
}


def _tones_pcm(seq, amp, sr):
    """Синтез последовательности тонов → float32-массив."""
    import numpy as np
    parts = []
    for freq, ms in seq:
        n = int(sr * ms / 1000)
        t = np.arange(n) / sr
        wave_ = amp * np.sin(2 * np.pi * freq * t)
        fade = min(200, n // 4)
        if fade:
            env = np.ones(n)
            env[:fade] = np.linspace(0, 1, fade)
            env[-fade:] = np.linspace(1, 0, fade)
            wave_ *= env
        parts.append(wave_)
    return np.concatenate(parts).astype("float32")


def _play_tones(seq, amp=0.25):
    sr = 44100
    if winsound:
        # Windows: через системный канал (winmm) — тот же путь, что звуки
        # ОС. sounddevice-вывод на части аудиокарт (внешние интерфейсы)
        # падает или молчит — из-за этого «играл не тот звук»/тишина.
        import io
        import wave as wavemod
        import numpy as np
        data = _tones_pcm(seq, amp, sr)
        pcm = (np.clip(data, -1, 1) * 32767).astype("<i2")
        buf = io.BytesIO()
        with wavemod.open(buf, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(sr)
            w.writeframes(pcm.tobytes())
        winsound.PlaySound(buf.getvalue(), winsound.SND_MEMORY)
        return
    import sounddevice as sd
    sd.play(_tones_pcm(seq, amp, sr), sr, blocking=True)


def _beep(seq, force_tones=False, amp=0.25):
    if not enabled:
        return

    def run():
        try:
            if winsound and not force_tones:
                for freq, ms in seq:
                    winsound.Beep(freq, ms)
            else:
                _play_tones(seq, amp)
        except Exception:
            log.exception("Не удалось воспроизвести сигнал")
            try:  # фолбэк: пусть хоть системный писк, чем тишина
                if winsound:
                    for freq, ms in seq:
                        if freq:
                            winsound.Beep(max(37, int(freq)), ms)
            except Exception:
                pass

    # сигналы блокируют поток — играем в фоне
    threading.Thread(target=run, daemon=True).start()


def _sig(name, classic_seq):
    """Выбор набора по стилю: паки — синтез мягких тонов и на Windows."""
    log.info("Сигнал %s (стиль %s)", name, style)
    p = PACKS.get(str(style).lower())
    if p:
        _beep(p[name], force_tones=True, amp=p.get("amp", 0.12))
    else:
        _beep(classic_seq)


def preview(style_name):
    """Прослушать стиль (старт + «готово») — для кнопки ▶ в настройках."""
    p = PACKS.get(str(style_name).lower())
    if p:
        _beep(p["start"] + [(0, 140)] + p["ready"],
              force_tones=True, amp=p.get("amp", 0.12))
    else:
        _beep([(880, 150), (0, 140), (660, 120), (880, 120)])


def start_recording():
    _sig("start", [(880, 150)])


def stop_recording():
    _sig("stop", [(440, 150)])


def ready():
    _sig("ready", [(660, 120), (880, 120)])


def limit_reached():
    _sig("limit", [(300, 400)])


def error():
    _sig("error", [(220, 300)])
