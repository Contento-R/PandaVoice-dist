"""Резка длинной записи на фрагменты по паузам в речи.

Простой RMS-порог по окнам, без внешних VAD-моделей. np.split по найденным
точкам гарантирует: конкатенация фрагментов == исходное аудио (без потерь).
"""
import numpy as np


def _window_rms(audio, win):
    n = len(audio) // win
    if n == 0:
        return np.zeros(0, dtype=np.float32)
    frames = audio[: n * win].reshape(n, win)
    return np.sqrt((frames.astype(np.float64) ** 2).mean(axis=1))


def find_cut_points(audio, sr, min_chunk_sec=30.0, max_chunk_sec=60.0, win_ms=50):
    """Индексы (в сэмплах), по которым режем. Пустой список — резать не надо.

    Для каждого фрагмента ищем самый длинный тихий участок в окне
    [start+min_chunk, start+max_chunk]; нет тишины — жёсткий срез по max_chunk.
    """
    if len(audio) <= max_chunk_sec * sr:
        return []
    win = max(1, int(sr * win_ms / 1000))
    rms = _window_rms(audio, win)
    # порог тишины — доля от типичного уровня речи в этой записи
    thr = max(1e-4, 0.08 * float(np.percentile(rms, 95)))
    silent = rms < thr

    cuts = []
    start = 0  # в сэмплах
    while len(audio) - start > max_chunk_sec * sr:
        lo = int((start + min_chunk_sec * sr) // win)
        hi = min(int((start + max_chunk_sec * sr) // win), len(silent))
        best_len, best_mid, run = 0, None, 0
        for i in range(lo, hi):
            if silent[i]:
                run += 1
                if run > best_len:
                    best_len, best_mid = run, i - run // 2
            else:
                run = 0
        cut = (best_mid + 1) * win if best_mid is not None else int(start + max_chunk_sec * sr)
        cuts.append(cut)
        start = cut
    return cuts


def split_on_silence(audio, sr, min_chunk_sec=30.0, max_chunk_sec=60.0, win_ms=50):
    cuts = find_cut_points(audio, sr, min_chunk_sec, max_chunk_sec, win_ms)
    if not cuts:
        return [audio]
    return np.split(audio, cuts)
