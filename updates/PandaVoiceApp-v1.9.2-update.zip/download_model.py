"""Предзагрузка весов модели (install.bat / автодокачка при смене модели).

Должен уметь работать БЕЗ консоли: его запускает и pythonw-приложение,
у которого sys.stdout/stderr = None — голый print тогда роняет процесс.
"""
import json
import os
import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
os.environ.setdefault("HF_HOME", str(APP_DIR / "hf-cache"))
if sys.stdout is None or sys.stderr is None:  # запуск из pythonw
    devnull = open(os.devnull, "w", encoding="utf-8")
    sys.stdout = sys.stdout or devnull
    sys.stderr = sys.stderr or devnull
    os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")

from huggingface_hub import snapshot_download  # noqa: E402 (после HF_HOME)

with open(APP_DIR / "config.json", encoding="utf-8") as f:
    model_id = json.load(f)["model_id"]

print(f"Скачиваю модель {model_id} (один раз)...")
try:
    path = snapshot_download(model_id)
except Exception as e:
    print(f"ОШИБКА скачивания: {e}")
    sys.exit(1)
print(f"Готово: {path}")
