"""Вставка текста: буфер обмена + Ctrl+V, с восстановлением прежнего буфера.

Windows: ЧИСТЫЙ WinAPI SendInput — перед вставкой принудительно отпускаем
Alt/Shift/Win (иначе при малейшем рассинхроне модификаторов вместо Ctrl+V
в окно прилетает Ctrl+Alt+V и «вставка не работает»), затем Ctrl+V.
Библиотека keyboard для вставки НЕ используется: её send «восстанавливает»
состояние модификаторов и после наших Alt-хоткеев может слать мусор.
Linux — pynput.
"""
import logging
import sys
import time

log = logging.getLogger("paste")

if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

    ULONG_PTR = ctypes.c_size_t
    KEYEVENTF_KEYUP = 0x0002
    VK = {"shift": 0x10, "ctrl": 0x11, "alt": 0x12,
          "lwin": 0x5B, "rwin": 0x5C, "v": 0x56}

    class _KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                    ("dwExtraInfo", ULONG_PTR)]

    class _MOUSEINPUT(ctypes.Structure):
        _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                    ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

    class _INPUTUNION(ctypes.Union):
        _fields_ = [("ki", _KEYBDINPUT), ("mi", _MOUSEINPUT)]

    class _INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]

    def _key_events(*pairs):
        """pairs: (vk, is_up) → массив INPUT для SendInput."""
        arr = (_INPUT * len(pairs))()
        for i, (vk, up) in enumerate(pairs):
            arr[i].type = 1  # INPUT_KEYBOARD
            arr[i].u.ki = _KEYBDINPUT(vk, 0, KEYEVENTF_KEYUP if up else 0, 0, 0)
        sent = ctypes.windll.user32.SendInput(
            len(pairs), arr, ctypes.sizeof(_INPUT))
        return sent == len(pairs)

    def _send_ctrl_v():
        # 1) отпустить возможные «залипшие» модификаторы (кроме Ctrl)
        _key_events((VK["alt"], True), (VK["shift"], True),
                    (VK["lwin"], True), (VK["rwin"], True))
        time.sleep(0.03)
        # 2) чистый Ctrl+V
        ok = _key_events((VK["ctrl"], False), (VK["v"], False),
                         (VK["v"], True), (VK["ctrl"], True))
        log.info("Ctrl+V отправлен через SendInput (ok=%s)", ok)
        if not ok:
            raise OSError("SendInput не принял события")

    def _send_backspaces(n):
        BK = 0x08
        _key_events((VK["alt"], True), (VK["shift"], True),
                    (VK["lwin"], True), (VK["rwin"], True))
        for i in range(0, n, 50):  # пачками, чтобы не переполнять очередь
            k = min(50, n - i)
            _key_events(*[(BK, up) for _ in range(k) for up in (False, True)])
            time.sleep(0.01)
else:
    def _send_backspaces(n):
        from pynput.keyboard import Controller, Key
        kb = Controller()
        for _ in range(n):
            kb.tap(Key.backspace)

    def _send_ctrl_v():
        from pynput.keyboard import Controller, Key
        kb = Controller()
        with kb.pressed(Key.ctrl):
            kb.press("v")
            kb.release("v")
        log.info("Ctrl+V отправлен через pynput")


def get_foreground_hwnd():
    """HWND активного окна — запомнить при старте записи, восстановить перед
    вставкой (одиночный Alt мог увести фокус в меню Chrome и т.п.)."""
    if sys.platform != "win32":
        return None
    try:
        return ctypes.windll.user32.GetForegroundWindow()
    except Exception:
        return None


def _restore_focus(hwnd):
    """Вернуть фокус целевому окну и закрыть возможное Alt-меню."""
    if sys.platform != "win32" or not hwnd:
        return
    try:
        u = ctypes.windll.user32
        cur = u.GetForegroundWindow()
        if cur == hwnd:
            return
        # снять foreground-lock: привязать наш поток ко входу целевого окна
        cur_tid = u.GetWindowThreadProcessId(cur, None)
        tgt_tid = u.GetWindowThreadProcessId(hwnd, None)
        u.AllowSetForegroundWindow(-1)  # ASFW_ANY
        if cur_tid != tgt_tid:
            u.AttachThreadInput(cur_tid, tgt_tid, True)
        u.SetForegroundWindow(hwnd)
        if cur_tid != tgt_tid:
            u.AttachThreadInput(cur_tid, tgt_tid, False)
        ok = u.GetForegroundWindow() == hwnd
        log.info("Восстановление фокуса целевого окна: ok=%s", ok)
        time.sleep(0.05)
    except Exception:
        log.exception("Не удалось восстановить фокус целевого окна")


def _wait_foreground(hwnd, timeout=0.7):
    """Дождаться, пока целевое окно РЕАЛЬНО станет активным, прежде чем слать
    клавиши. Иначе Backspace'ы уходят в пустоту (фокус ещё переключается) —
    старый текст не стирается, а вставка на 0.15 c позже уже попадает в поле,
    и получается «дописал вместо замены». Возвращает True, если окно активно."""
    if sys.platform != "win32" or not hwnd:
        return True
    u = ctypes.windll.user32
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if u.GetForegroundWindow() == hwnd:
            return True
        _restore_focus(hwnd)
        time.sleep(0.04)
    ok = u.GetForegroundWindow() == hwnd
    if not ok:
        log.warning("Целевое окно так и не стало активным — замена ненадёжна")
    return ok


def _foreground_title():
    """Заголовок активного окна — в лог: видно, КУДА реально ушёл Ctrl+V."""
    if sys.platform != "win32":
        return "?"
    try:
        import ctypes
        u = ctypes.windll.user32
        buf = ctypes.create_unicode_buffer(128)
        u.GetWindowTextW(u.GetForegroundWindow(), buf, 128)
        return buf.value or "(без заголовка)"
    except Exception:
        return "?"


def paste_text(text, restore=True, restore_delay=1.0, target_hwnd=None):
    import pyperclip

    old = None
    try:
        old = pyperclip.paste()  # только текст; картинки восстановить не сможем
    except Exception:
        log.warning("Не удалось прочитать буфер обмена", exc_info=True)
    try:
        pyperclip.copy(text)
    except Exception:
        log.exception("Не удалось положить текст в буфер обмена!")
        return
    _restore_focus(target_hwnd)  # вернуть фокус в поле, куда диктовали
    log.info("Вставка: %d символов в буфере, активное окно: %r — отправляю Ctrl+V",
             len(text), _foreground_title())
    time.sleep(0.15)  # даём буферу обновиться
    try:
        _send_ctrl_v()
    except Exception:
        log.exception("Не удалось эмулировать Ctrl+V — пробую запасной способ")
        try:
            import keyboard
            keyboard.send("ctrl+v")
            log.info("Ctrl+V отправлен запасным способом (keyboard)")
        except Exception:
            log.exception("Ctrl+V не отправлен — текст остался в буфере обмена")
            return
    if restore and old:
        time.sleep(restore_delay)  # ждём, пока целевое окно заберёт вставку
        try:
            pyperclip.copy(old)
            log.info("Прежний буфер обмена восстановлен")
        except Exception:
            log.exception("Не удалось восстановить буфер обмена")


def replace_text(old_len, text, restore=True, restore_delay=1.0,
                 target_hwnd=None):
    """Заменить ТОЛЬКО ЧТО вставленный текст в целевом поле: стереть old_len
    символов Backspace'ами (каретка стоит сразу за вставкой) и вставить новый.
    Работает, пока пользователь не печатал и не двигал каретку после вставки."""
    _restore_focus(target_hwnd)
    time.sleep(0.1)
    if old_len > 0:
        log.info("Замена: стираю %d символов в окне %r", old_len,
                 _foreground_title())
        try:
            _send_backspaces(old_len)
        except Exception:
            log.exception("Не удалось стереть старый текст — вставляю следом")
        time.sleep(0.1)
    paste_text(text, restore=restore, restore_delay=restore_delay,
               target_hwnd=target_hwnd)


def replace_text_now(old_len, text, target_hwnd=None):
    """Синхронная замена: фокус целевому окну уже передан вызывающим (пока
    диалог владел foreground). Стираем old_len символов и вставляем text.
    Возвращаем прежний буфер обмена — вызывающий восстановит его позже
    (в отдельном потоке, после паузы), чтобы не блокировать GUI надолго."""
    import pyperclip
    old_clip = None
    try:
        old_clip = pyperclip.paste()
    except Exception:
        log.warning("Не удалось прочитать буфер обмена", exc_info=True)
    # ДОЖДАТЬСЯ активации целевого окна, иначе Backspace'ы теряются и текст
    # дописывается вместо замены
    _wait_foreground(target_hwnd)
    if old_len > 0:
        log.info("Замена: стираю %d символов в окне %r", old_len,
                 _foreground_title())
        try:
            _send_backspaces(old_len)
        except Exception:
            log.exception("Не удалось стереть старый текст")
        time.sleep(0.05)
    try:
        pyperclip.copy(text)
    except Exception:
        log.exception("Не удалось положить текст в буфер обмена")
        return old_clip
    time.sleep(0.1)
    log.info("Вставка (замена): %d символов, окно %r", len(text),
             _foreground_title())
    try:
        _send_ctrl_v()
    except Exception:
        log.exception("Ctrl+V (замена) не отправлен")
    return old_clip
