"""Графический установщик Panda Voice (только stdlib — работает ДО venv).

Запускается из install.bat системным Python: окно с шагами установки,
прогрессом и журналом вместо «пугающего» терминала. В конце открывает
графическую настройку микрофона (setup_gui.py в свежем venv).
"""
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

APP_DIR = Path(__file__).resolve().parent
VPY = APP_DIR / ("venv/Scripts/python.exe" if sys.platform == "win32"
                 else "venv/bin/python")
PYW = APP_DIR / ("venv/Scripts/pythonw.exe" if sys.platform == "win32"
                 else "venv/bin/python")
TRANSFORMERS_URL = ("https://github.com/huggingface/transformers/archive/"
                    "7ea2320c76117e6742364808a666ef6f2fb40a67.zip")
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _steps():
    steps = []
    if sys.platform == "win32":
        steps.append(("Снятие блокировок Windows с файлов",
                      ["powershell", "-NoProfile", "-Command",
                       "Get-ChildItem -Recurse -File | Unblock-File"]))
    if not VPY.exists():
        steps.append(("Создание окружения Python",
                      [sys.executable, "-m", "venv", "venv"]))
    steps += [
        ("Обновление менеджера пакетов",
         [str(VPY), "-m", "pip", "install", "--upgrade", "pip"]),
        ("PyTorch — CPU-сборка, без CUDA (крупная, наберитесь терпения)",
         [str(VPY), "-m", "pip", "install", "torch",
          "--index-url", "https://download.pytorch.org/whl/cpu"]),
        ("Библиотеки приложения",
         [str(VPY), "-m", "pip", "install", "-r", "requirements.txt"]),
        ("Движок распознавания (transformers)",
         [str(VPY), "-m", "pip", "install", TRANSFORMERS_URL]),
        ("Модель распознавания (~1.5 ГБ, один раз)",
         [str(VPY), "download_model.py"]),
        ("Ярлык на рабочем столе",
         [str(VPY), "-c", "import setup_wizard; setup_wizard.make_desktop_shortcut()"]),
    ]
    return steps


class Installer:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Установка Panda Voice")
        self.root.geometry("640x430")
        self.root.minsize(560, 380)
        self._q = queue.Queue()
        self._proc = None
        self._cancelled = False

        ttk.Label(self.root, text="Установка Panda Voice",
                  font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=14, pady=(12, 0))
        ttk.Label(self.root, foreground="#666", text=(
            "Приложение ставится в эту папку, скачивает модель распознавания "
            "и создаёт ярлык. Обычно 10–30 минут.")).pack(anchor="w", padx=14)
        self.step_var = tk.StringVar(value="Подготовка...")
        ttk.Label(self.root, textvariable=self.step_var).pack(anchor="w",
                                                              padx=14, pady=(10, 2))
        self.steps = _steps()
        self.bar = ttk.Progressbar(self.root, maximum=len(self.steps))
        self.bar.pack(fill="x", padx=14)
        self.log = tk.Text(self.root, height=12, state="disabled",
                           font=("Consolas", 9))
        self.log.pack(fill="both", expand=True, padx=14, pady=(8, 0))
        bottom = ttk.Frame(self.root)
        bottom.pack(fill="x", padx=14, pady=10)
        self.btn = ttk.Button(bottom, text="Отмена", command=self._cancel)
        self.btn.pack(side="right")
        self.root.protocol("WM_DELETE_WINDOW", self._cancel)

        # свежая установка из «Загрузок»/с рабочего стола — предложить
        # аккуратную стандартную папку программ вместо кучи файлов в
        # «Загрузках» (частая жалоба). Копируем файлы и перезапускаем
        # установщик уже оттуда.
        if sys.platform == "win32" and not VPY.exists():
            low = str(APP_DIR).lower()
            bad = any(m in low for m in
                      ("download", "загруз", "desktop", "рабочий стол",
                       "\\temp", "/tmp"))
            target = Path.home() / "AppData/Local/Programs/Panda Voice"
            if bad and target.resolve() != APP_DIR.resolve():
                if messagebox.askyesno(
                        "Установка Panda Voice",
                        "Установить приложение в стандартную папку программ "
                        "(рекомендуется)?\n\n" + str(target) + "\n\n"
                        "«Да» — файлы будут лежать аккуратно, а эту папку "
                        "из «Загрузок» можно будет удалить.\n"
                        "«Нет» — установить прямо здесь."):
                    try:
                        import shutil
                        target.mkdir(parents=True, exist_ok=True)
                        shutil.copytree(
                            APP_DIR, target, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns(
                                "venv", "hf-cache", "__pycache__"))
                        subprocess.Popen(
                            [sys.executable, str(target / "install_gui.py")],
                            cwd=target, creationflags=NO_WINDOW)
                        self.root.destroy()
                        raise SystemExit
                    except SystemExit:
                        raise
                    except Exception:
                        messagebox.showwarning(
                            "Установка Panda Voice",
                            "Не удалось перенести в папку программ — "
                            "устанавливаю здесь.")

        try:  # нехватка места — частая причина сбоев: предупредить ДО начала
            import shutil
            free_gb = shutil.disk_usage(APP_DIR).free / 1e9
            if free_gb < 6:
                self._append(
                    "ВНИМАНИЕ: на этом диске свободно всего %.1f ГБ, а "
                    "установке нужно ~5-6 ГБ (зависимости + модель).\n"
                    "Освободите место или перенесите папку приложения на "
                    "другой диск и запустите install.bat оттуда — иначе "
                    "установка прервётся.\n" % free_gb)
        except Exception:
            pass

        threading.Thread(target=self._work, daemon=True).start()
        self._poll()

    # --- поток установки ---

    @staticmethod
    def _hint(tail):
        """Понятная причина сбоя по хвосту вывода (вместо «проверьте
        интернет» на любую ошибку)."""
        t = tail.lower()
        if "no space left" in t or "errno 28" in t or "not enough space" in t:
            return ("НА ДИСКЕ ЗАКОНЧИЛОСЬ МЕСТО. Освободите минимум 5 ГБ "
                    "(Корзина, временные файлы) или перенесите папку "
                    "приложения на другой диск, затем запустите install.bat "
                    "снова — установка продолжится с этого места.")
        if ("connection" in t or "timed out" in t or "temporary failure" in t
                or "getaddrinfo" in t or "ssl" in t):
            return ("Похоже, проблема с интернетом. Проверьте сеть и "
                    "запустите установку ещё раз — она продолжится "
                    "с этого места.")
        return ("Проверьте интернет и свободное место на диске, затем "
                "запустите установку ещё раз — она продолжится "
                "с этого места.")

    def _work(self):
        tail = []
        for i, (title, cmd) in enumerate(self.steps):
            if self._cancelled:
                return
            self._q.put(("step", i, title))
            try:
                self._proc = subprocess.Popen(
                    cmd, cwd=APP_DIR, stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT, text=True,
                    encoding="utf-8", errors="replace",
                    creationflags=NO_WINDOW)
                for line in self._proc.stdout:
                    self._q.put(("log", line.rstrip()))
                    tail.append(line)
                    del tail[:-40]
                rc = self._proc.wait()
            except Exception as e:
                self._q.put(("fail", title, str(e),
                             self._hint("\n".join(tail))))
                return
            if self._cancelled:
                return
            if rc != 0 and "Unblock" not in str(cmd) and "shortcut" not in title:
                if title.startswith("Ярлык"):
                    self._q.put(("log", "(ярлык не создан — можно через start.bat)"))
                else:
                    self._q.put(("fail", title, f"код ошибки {rc}",
                                 self._hint("\n".join(tail))))
                    return
        self._q.put(("done",))

    # --- интерфейс ---

    def _poll(self):
        try:
            while True:
                msg = self._q.get_nowait()
                kind = msg[0]
                if kind == "step":
                    _, i, title = msg
                    self.bar["value"] = i
                    self.step_var.set(f"Шаг {i + 1} из {len(self.steps)}: {title}")
                    self._append(f"\n=== {title} ===")
                elif kind == "log":
                    self._append(msg[1])
                elif kind == "fail":
                    self.bar["value"] = 0
                    self.step_var.set(f"Ошибка: {msg[1]}")
                    hint = msg[3] if len(msg) > 3 else (
                        "Запустите установку ещё раз — она продолжится "
                        "с этого места.")
                    self._append(f"\nОШИБКА ({msg[2]}). {hint}")
                    self.btn.configure(text="Закрыть",
                                       command=self.root.destroy)
                    return
                elif kind == "done":
                    self.bar["value"] = len(self.steps)
                    self.step_var.set("Установка завершена!")
                    self._append("\nГотово! Сейчас откроется настройка микрофона.")
                    self.btn.configure(text="Настроить микрофон",
                                       command=self._finish)
                    self.root.after(1500, self._finish)
                    return
        except queue.Empty:
            pass
        self.root.after(100, self._poll)

    def _append(self, line):
        self.log.configure(state="normal")
        self.log.insert("end", line + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _cancel(self):
        if self.btn["text"] != "Отмена":
            self.root.destroy()
            return
        if not messagebox.askyesno("Установка Panda Voice",
                                   "Прервать установку? Её можно будет "
                                   "продолжить, запустив install.bat снова."):
            return
        self._cancelled = True
        try:
            if self._proc:
                self._proc.kill()
        except Exception:
            pass
        self.root.destroy()

    _finished = False

    def _finish(self):
        if self._finished:
            return
        self._finished = True
        try:
            subprocess.Popen([str(PYW), "setup_gui.py", "--first-run"],
                             cwd=APP_DIR, creationflags=NO_WINDOW)
        except Exception:
            messagebox.showwarning(
                "Panda Voice", "Не удалось открыть настройку микрофона — "
                "запустите приложение ярлыком, настройка откроется сама.")
        self.root.destroy()

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    Installer().run()
