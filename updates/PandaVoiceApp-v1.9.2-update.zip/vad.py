"""Silero VAD: нейросетевой детектор речи (~2 МБ, встроен в assets/).

Отличает речь от шума/тишины там, где энергетический RMS-порог ошибается
(вентилятор, клавиатура, дыхание). Используется в двух местах:
- пропуск фрагментов без речи перед распознаванием (быстрее, без галлюцинаций);
- «жадный дренаж» потоковых фрагментов по паузе речи, а не по тишине.
При любой ошибке загрузки функции возвращают None — вызывающий код
откатывается на старый RMS-порог.
"""
import logging
import threading
from pathlib import Path

import numpy as np

log = logging.getLogger("vad")
MODEL_PATH = Path(__file__).resolve().parent / "assets" / "silero_vad.jit"
SR = 16000
WIN = 512  # окно модели: 512 сэмплов = 32 мс при 16 кГц

_model = None
_failed = False
_lock = threading.Lock()  # у jit-модели внутреннее состояние — не реентерабельна


def _get():
    global _model, _failed
    if _failed:
        return None
    if _model is None:
        try:
            import torch
            m = torch.jit.load(str(MODEL_PATH))
            m.eval()
            _model = m
            log.info("Silero VAD загружен")
        except Exception:
            _failed = True
            log.exception("Silero VAD недоступен — работаю по RMS-порогу")
            return None
    return _model


def speech_probs(audio):
    """Вероятность речи по окнам 32 мс; None, если VAD недоступен."""
    m = _get()
    if m is None or len(audio) < WIN:
        return None
    import torch
    with _lock:
        m.reset_states()
        out = []
        with torch.no_grad():
            for i in range(0, len(audio) - WIN + 1, WIN):
                t = torch.from_numpy(np.ascontiguousarray(audio[i:i + WIN]))
                out.append(float(m(t.unsqueeze(0), SR)))
    return np.array(out)


def has_speech(audio, thr=0.5, min_frames=3):
    """Есть ли в аудио речь (>= min_frames окон по 32 мс). None = VAD нет."""
    p = speech_probs(audio)
    if p is None:
        return None
    return int((p > thr).sum()) >= min_frames


def tail_is_silent(audio, sec, thr=0.5):
    """Нет ли речи в последних sec секундах (пауза для дренажа). None = VAD нет."""
    n = int(sec * SR)
    if len(audio) < n:
        return None
    p = speech_probs(audio[-n:])
    if p is None:
        return None
    return bool((p <= thr).all())


if __name__ == "__main__":  # самопроверка: python vad.py
    import wave
    with wave.open(str(MODEL_PATH.parent / "test.wav"), "rb") as w:
        a = np.frombuffer(w.readframes(w.getnframes()),
                          dtype="<i2").astype(np.float32) / 32768.0
    assert has_speech(a) is True
    assert has_speech(np.zeros(SR, dtype=np.float32)) is False
    assert tail_is_silent(np.zeros(SR * 2, dtype=np.float32), 0.9) is True
    print("OK: vad")
