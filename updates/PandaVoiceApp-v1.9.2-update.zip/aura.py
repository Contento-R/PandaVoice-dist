"""«Аура» — опциональный современный интерфейс (ui_mode="aura").

По умолчанию ("classic") модуль не используется вовсе. При включении окно
приложения рисует встроенный веб-движок (pywebview; на Windows 11 —
предустановленный WebView2), а ВСЯ логика остаётся прежней: мост Api
дёргает те же методы App, что и классический интерфейс. Классический
tkinter продолжает работать в фоновом потоке — он рисует оверлей записи,
живой транскрипт и окно исправления F8, его главное окно просто не
показывается. Если pywebview недоступен или окно не создалось — запуск
автоматически откатывается на классический интерфейс.
"""
import logging
import sys
import threading
import time
from pathlib import Path

import appconfig
import history

log = logging.getLogger("aura")
HTML = Path(__file__).resolve().parent / "aura.html"
OVERLAY_HTML = Path(__file__).resolve().parent / "aura_overlay.html"
_OV_TITLE = "PandaVoiceAuraOverlay"
_WIN_TITLE = "Panda Voice — Аура"
_OV_W, _OV_BASE_H, _OV_MAX_H = 300, 38, 220

# настройки, которые Аура может менять напрямую (белый список)
_SETTABLE = {
    "live_transcript", "live_fast", "dict_suggestions", "beeps",
    "beep_style", "offline_mode", "history_enabled", "multilingual_mode",
    "language", "update_check", "max_recording_sec", "input_device",
    "asr_context", "num_beams", "final_repass",
}


class Api:
    """Мост для JS: window.pywebview.api.<метод>(...). Все методы должны
    возвращать JSON-сериализуемое и не бросать наружу."""

    def __init__(self, app):
        self.app = app

    # --- состояние/запись ---

    def state(self):
        a = self.app
        live, sec = "", 0
        try:
            live = " ".join(t for t in a._partials if t)
        except Exception:
            pass
        try:
            if a.recorder and a.recorder.recording:
                sec = int(a.recorder.total_duration())
        except Exception:
            pass
        levels = []
        try:  # уровни микрофона — для волны в веб-оверлее
            levels = a.recorder.norm_levels(17)
        except Exception:
            pass
        return {"state": a.current_state(), "live": live[-400:], "sec": sec,
                "levels": levels, "version": appconfig.version()}

    def toggle(self):
        a = self.app
        try:
            if a.recorder and a.recorder.recording:
                threading.Thread(target=a.request_stop, daemon=True).start()
            elif a.transcriber is not None:
                if a.fsm:
                    a.fsm.state = "recording"  # согласуем FSM с кнопкой
                threading.Thread(target=a.start_recording,
                                 daemon=True).start()
        except Exception:
            log.exception("Аура: toggle не удался")
        return True

    def cancel(self):
        threading.Thread(target=self.app.cancel_recording,
                         daemon=True).start()
        return True

    # --- данные ---

    def stats(self):
        try:
            entries = history.read_last(100000)
            return {
                "words": sum(len((e.get("text") or "").split())
                             for e in entries),
                "entries": len(entries),
                "minutes": int(sum(float(e.get("audio_sec") or 0)
                                   for e in entries) // 60)}
        except Exception:
            log.exception("Аура: статистика не удалась")
            return {"words": 0, "entries": 0, "minutes": 0}

    def hist(self, n=60):
        try:
            out = history.read_last(int(n))
            out.reverse()  # новые сверху
            return out
        except Exception:
            log.exception("Аура: история не прочиталась")
            return []

    def dict_all(self):
        try:
            import corrections
            import userdict
            mc = int(self.app.cfg.get("dict_suggest_min_count", 4))
            sug = []
            if self.app.cfg.get("dict_suggestions"):
                sug = [{"w": w, "n": n} for w, n in userdict.suggest(
                    history.read_last(1000), min_count=mc,
                    extra_known=corrections.vocab())]
            return {"terms": sorted(userdict.terms(), key=str.lower),
                    "sug": sug}
        except Exception:
            log.exception("Аура: словарь не прочитался")
            return {"terms": [], "sug": []}

    def dict_add(self, w):
        try:
            import userdict
            userdict.add_many(w) if ("," in str(w)) else userdict.add(w)
        except Exception:
            log.exception("Аура: добавление слова не удалось")
        return self.dict_all()

    def dict_import(self, text):
        n = 0
        try:
            import userdict
            n = userdict.add_many(text)
        except Exception:
            log.exception("Аура: импорт не удался")
        d = self.dict_all()
        d["added"] = n
        return d

    def dict_remove(self, w):
        try:
            import userdict
            userdict.remove(w)
        except Exception:
            log.exception("Аура: удаление слова не удалось")
        return self.dict_all()

    def dict_dismiss(self, w):
        try:
            import userdict
            userdict.dismiss(w)
        except Exception:
            log.exception("Аура: скрытие предложения не удалось")
        return self.dict_all()

    # --- настройки ---

    def get_settings(self):
        c = self.app.cfg
        out = {k: c.get(k) for k in sorted(_SETTABLE)}
        out["model_id"] = c.get("model_id")
        return out

    def devices(self):
        """Список микрофонов для выпадающего списка."""
        out = []
        try:
            import sounddevice as sd
            for i, d in enumerate(sd.query_devices()):
                if d.get("max_input_channels", 0) > 0:
                    out.append({"i": i, "name": "%d: %s" % (i, d["name"])})
        except Exception:
            log.exception("Аура: список микрофонов не получен")
        return {"devices": out, "current": self.app.cfg.get("input_device")}

    def set_model(self, model_id):
        """Сменить модель распознавания (докачается сама) и перезапуститься."""
        try:
            self.app.apply_config({"model_id": str(model_id)})
            threading.Thread(target=self.app.restart, daemon=True).start()
            return True
        except Exception:
            log.exception("Аура: смена модели не удалась")
            return False

    def preview_sound(self, style_name):
        try:
            import sounds
            threading.Thread(target=sounds.preview, args=(str(style_name),),
                             daemon=True).start()
        except Exception:
            log.exception("Аура: прослушивание звука не удалось")
        return True

    def set_setting(self, key, value):
        if key not in _SETTABLE:
            return {"ok": False}
        try:
            self.app.apply_config({key: value})
            return {"ok": True}
        except Exception:
            log.exception("Аура: настройка %s не применилась", key)
            return {"ok": False}

    def report_panel_h(self, h):
        """Оверлей сообщает высоту содержимого — окно растёт вверх,
        нижний край остаётся на месте."""
        try:
            w = getattr(self.app, "_aura_overlay", None)
            g = getattr(self.app, "_aura_geom", None)
            if w is None or g is None:
                return False
            if not getattr(self.app, "_aura_ov_visible", False):
                return False  # скрытое окно не трогаем
            sw, sh, bottom = g
            hh = max(_OV_BASE_H, min(_OV_MAX_H, int(h)))
            w.resize(_OV_W, hh)
            w.move((sw - _OV_W) // 2, bottom - hh)
            return True
        except Exception:
            log.exception("Аура: оверлей не изменил размер")
            return False

    def run_update(self):
        """Установить обновление из «Загрузок» — как кнопка в классике.
        Долгий вызов (докачка зависимостей) — JS ждёт промис."""
        try:
            import importlib
            import updater
            importlib.reload(updater)  # вдруг updater сам был обновлён
            status, msg = updater.run()
            if status == "updated":
                threading.Thread(target=self.app.restart,
                                 daemon=True).start()
            return {"status": status, "msg": msg}
        except Exception as e:
            log.exception("Аура: обновление не удалось")
            return {"status": "error", "msg": str(e)}

    def switch_classic(self):
        """Вернуться на классический интерфейс (с перезапуском)."""
        try:
            self.app.apply_config({"ui_mode": "classic"})
            threading.Thread(target=self.app.restart, daemon=True).start()
        except Exception:
            log.exception("Аура: возврат на классику не удался")
        return True


def _ensure_webview(app):
    """Импортировать pywebview; если не установлен (обновление могло не
    доустановить зависимости) — поставить его прямо сейчас и попробовать
    снова. None = недоступен."""
    try:
        import webview
        return webview
    except Exception:
        pass
    log.info("pywebview не установлен — доустанавливаю…")
    try:
        app.tray.notify("Аура: доустанавливаю компонент интерфейса — "
                        "около минуты…")
    except Exception:
        pass
    try:
        import subprocess
        import sys
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-q", "pywebview"],
            timeout=600, capture_output=True, text=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if r.returncode != 0:
            log.error("pip install pywebview: код %d\n%s", r.returncode,
                      (r.stderr or "")[-800:])
            return None
        import webview
        return webview
    except Exception:
        log.exception("Установка pywebview не удалась")
        return None


def _fix_main_icon(win):
    """Панда в заголовке и на панели задач: pywebview на Windows наследует
    иконку pythonw.exe. Ставим свою через WM_SETICON, когда окно впервые
    ПОКАЗАНО (у скрытого окна нет хэндла — потому не работало раньше).
    Только ctypes: никаких обращений к .NET из фоновых потоков — попытка
    v1.8.3 могла зависать вместе с инициализацией WebView."""
    state = {"done": False}

    def work():
        try:
            from setup_wizard import _ensure_icon
            ico = _ensure_icon()
            if not ico:
                log.warning("panda.ico не создалась — иконка окна прежняя")
                return
            import ctypes
            from ctypes import wintypes
            u = ctypes.windll.user32
            u.LoadImageW.restype = wintypes.HANDLE
            u.SendMessageW.argtypes = (wintypes.HWND, wintypes.UINT,
                                       wintypes.WPARAM, wintypes.LPARAM)
            IMAGE_ICON, LR_LOADFROMFILE, WM_SETICON = 1, 0x10, 0x80
            for _ in range(20):
                h = u.FindWindowW(None, _WIN_TITLE)
                if h:
                    for wp, px in ((1, 32), (0, 16)):  # ICON_BIG/ICON_SMALL
                        hicon = u.LoadImageW(None, str(ico), IMAGE_ICON,
                                             px, px, LR_LOADFROMFILE)
                        if hicon:
                            u.SendMessageW(h, WM_SETICON, wp, hicon)
                    log.info("Иконка окна ауры установлена")
                    return
                time.sleep(0.25)
            log.info("Иконка окна ауры: окно не найдено")
        except Exception:
            log.exception("Не удалось поставить иконку окну ауры")

    def on_shown():
        if state["done"]:
            return
        state["done"] = True
        threading.Thread(target=work, daemon=True).start()

    try:
        win.events.shown += on_shown
    except Exception:
        log.exception("Событие показа окна ауры недоступно — иконка прежняя")


def fix_overlay_once(app):
    """При первом показе веб-оверлея: сделать его окно неактивируемым
    (WS_EX_NOACTIVATE), чтобы клики по кнопкам не крали фокус у поля, куда
    вставится текст. Не вышло — откат на классическую tkinter-пилюлю."""
    if getattr(app, "_aura_ov_fixed", False):
        return
    app._aura_ov_fixed = True

    def work():
        try:
            import time
            import ctypes
            u = ctypes.windll.user32
            for _ in range(30):
                h = u.FindWindowW(None, _OV_TITLE)
                if h:
                    GWL_EXSTYLE = -20
                    st = u.GetWindowLongPtrW(h, GWL_EXSTYLE)
                    # NOACTIVATE | TOOLWINDOW: клики не крадут фокус
                    u.SetWindowLongPtrW(h, GWL_EXSTYLE,
                                        st | 0x08000000 | 0x00000080)
                    try:  # Windows 11: нативные скруглённые углы
                        pref = ctypes.c_int(2)  # DWMWCP_ROUND
                        ctypes.windll.dwmapi.DwmSetWindowAttribute(
                            h, 33, ctypes.byref(pref), 4)
                    except Exception:
                        pass
                    return
                time.sleep(0.1)
            raise RuntimeError("окно оверлея не найдено")
        except Exception:
            log.exception("Веб-оверлей не удалось сделать неактивируемым — "
                          "откат на классическую пилюлю")
            w = getattr(app, "_aura_overlay", None)
            app._aura_overlay = None
            try:
                if w is not None:
                    w.hide()
            except Exception:
                pass

    threading.Thread(target=work, daemon=True).start()


def run(app):
    """Запуск режима «Аура». True — режим отработал до выхода;
    False — pywebview недоступен, вызывающий откатывается на классику."""
    webview = _ensure_webview(app)
    if webview is None or not HTML.exists():
        log.error("Аура недоступна (pywebview/aura.html) — откат на классику")
        try:
            app.tray.notify("Аура не запустилась — открываю классический "
                            "интерфейс. Подробности во вкладке «Журнал».")
        except Exception:
            pass
        return False

    # своя группа на панели задач (AppUserModelID) уже выставлена в main()

    # окно создаём ДО запуска tk-потока: если здесь сбой — чистый откат
    # на классику без последствий
    try:
        win = webview.create_window(
            _WIN_TITLE, str(HTML), js_api=Api(app),
            width=1000, height=740, min_size=(720, 560),
            background_color="#0a0d12", hidden=True)
    except Exception:
        log.exception("Окно ауры не создалось — откат на классику")
        try:
            app.tray.notify("Аура не запустилась — открываю классический "
                            "интерфейс. Подробности во вкладке «Журнал».")
        except Exception:
            pass
        return False
    app._aura_win = win

    def on_closing():
        try:  # закрытие окна = спрятать в трей, как в классике
            win.hide()
        except Exception:
            pass
        return False

    try:
        win.events.closing += on_closing
    except Exception:
        log.exception("Не удалось перехватить закрытие окна ауры")

    # дальше коммитимся: классический Gui — в фоновом потоке (он рисует
    # оверлей записи, живой транскрипт и окно F8; его главное окно скрыто)
    ready = threading.Event()

    def tk_thread():
        try:
            from gui import Gui
            app.gui = Gui(app)
            ready.set()
            app.gui.mainloop()
        except Exception:
            log.exception("Тк-поток ауры не поднялся (оверлей недоступен)")
            app.gui = None
            ready.set()

    tkt = threading.Thread(target=tk_thread, daemon=True)
    tkt.start()
    ready.wait(timeout=30)

    # премиум-оверлей: ОДНО окно-карточка (транскрипт сверху + строка
    # управления снизу) ровно по размеру содержимого — фону негде быть,
    # растёт вверх от фиксированного нижнего края, углы скругляет DWM.
    # Сбой = откат на классическую tkinter-пилюлю.
    app._aura_overlay = None
    app._aura_panel = None  # больше не используется (единое окно)
    app._aura_ov_fixed = False
    if OVERLAY_HTML.exists():
        try:
            import ctypes
            sw = ctypes.windll.user32.GetSystemMetrics(0)
            sh = ctypes.windll.user32.GetSystemMetrics(1)
            bottom = sh - 70  # фиксированный нижний край карточки
            app._aura_geom = (sw, sh, bottom)
            app._aura_overlay = webview.create_window(
                _OV_TITLE, str(OVERLAY_HTML), js_api=Api(app),
                width=_OV_W, height=_OV_BASE_H,
                x=(sw - _OV_W) // 2, y=bottom - _OV_BASE_H,
                frameless=True, on_top=True, hidden=True, focus=False,
                background_color="#0d0f13")
        except Exception:
            log.exception("Веб-оверлей не создался — классическая пилюля")
            app._aura_overlay = None

    def setup(icon):
        icon.visible = True
        threading.Thread(target=app._init, daemon=True).start()

    def ov_watchdog():
        """Страховка: hidden=True при старте соблюдается не всеми сборками
        pywebview — у пользователя оверлей висел пустым прямоугольником.
        Пока записи нет — принудительно прячем окно."""
        while True:
            try:
                time.sleep(1.5)
                w = getattr(app, "_aura_overlay", None)
                if w is None:
                    return
                if (not getattr(app, "_aura_ov_visible", False)
                        and app.current_state() in ("idle", "paused",
                                                    "loading")):
                    w.hide()
            except Exception:
                pass

    threading.Thread(target=ov_watchdog, daemon=True).start()

    app.tray.run_detached(setup=setup)
    if sys.platform == "win32":
        _fix_main_icon(win)
    log.info("Аура запущена (WebView)")
    try:
        webview.start()  # блокирует главный поток до destroy
    except Exception:
        # WebView2 не поднялся уже после коммита: работаем классикой —
        # tk-поток жив, show_window сам откатится на классическое окно
        log.exception("WebView не стартовал — продолжаю с классическим окном")
        app._aura_win = None
        try:
            app.tray.notify("Аура не запустилась — окно будет классическим. "
                            "Подробности во вкладке «Журнал».")
        except Exception:
            pass
        tkt.join()  # приложение живёт, пока жив tk-поток
    return True
