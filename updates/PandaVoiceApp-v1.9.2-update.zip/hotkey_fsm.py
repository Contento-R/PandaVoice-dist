"""Машина состояний хоткея: двойной Alt = старт записи, одиночный Alt при записи = стоп.

Чистая логика без Windows API — тестируется на фейковых событиях.
Время (секунды, монотонное) передаётся снаружи.
"""

IDLE = "idle"
RECORDING = "recording"
PROCESSING = "processing"
PAUSED = "paused"

START = "start"
STOP = "stop"
NEUTRALIZE = "neutralize"  # заглушить системное Alt-меню фиктивной клавишей


class HotkeyFSM:
    def __init__(self, double_press_sec=0.4, debounce_sec=0.5, max_tap_sec=0.5):
        self.double_press_sec = double_press_sec
        self.debounce_sec = debounce_sec  # защита от дребезга (тройное нажатие)
        self.max_tap_sec = max_tap_sec    # дольше — это удержание, не тап
        self.state = IDLE
        self._down_t = None
        self._combo = False       # пока клавиша зажата, нажата другая (Alt+Tab)
        self._last_tap_t = None   # время завершения первого тапа
        self._record_started_t = None

    # --- события клавиатуры ---

    def on_key_down(self, t):
        if self.state == PAUSED or self._down_t is not None:  # повтор при удержании
            return None
        self._down_t = t
        self._combo = False
        # одиночный тап при записи остановит её — глушим Alt-меню заранее
        return NEUTRALIZE if self.state == RECORDING else None

    def on_key_up(self, t):
        if self.state == PAUSED or self._down_t is None:
            return None
        is_tap = not self._combo and (t - self._down_t) <= self.max_tap_sec
        self._down_t = None
        if not is_tap:
            self._last_tap_t = None
            return None
        if self.state == IDLE:
            if self._last_tap_t is not None and (t - self._last_tap_t) <= self.double_press_sec:
                self._last_tap_t = None
                self.state = RECORDING
                self._record_started_t = t
                return START
            self._last_tap_t = t
            return None
        if self.state == RECORDING:
            if (t - self._record_started_t) < self.debounce_sec:
                return None  # дребезг: третий тап сразу после старта не роняет запись
            self.state = PROCESSING
            return STOP
        return None  # PROCESSING: игнорируем

    def on_other_key(self, t):
        if self._down_t is not None:
            self._combo = True  # это комбинация (Alt+Tab), не тап
        self._last_tap_t = None  # чужая клавиша разрывает двойное нажатие

    # --- переходы от приложения ---

    def reset_idle(self):
        """Распознавание завершено / старт не удался — вернуться в ожидание."""
        if self.state != PAUSED:
            self.state = IDLE
            self._last_tap_t = None

    def force_stop(self):
        """Автостоп по лимиту записи. True, если реально были в записи."""
        if self.state == RECORDING:
            self.state = PROCESSING
            return True
        return False

    def pause(self):
        self.state = PAUSED
        self._down_t = None
        self._last_tap_t = None

    def resume(self):
        if self.state == PAUSED:
            self.state = IDLE
