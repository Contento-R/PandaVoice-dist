"""Qwen3-ASR: загрузка модели (один раз, живёт в памяти) и распознавание.

Ускорение на CPU: int8-квантизация (quantize_int8), батч-инференс фрагментов
(batch_size), число потоков torch = физические ядра (torch_threads=0 → авто).
Все вызовы модели сериализованы внутренним локом — можно безопасно звать из
потокового воркера и из основного пайплайна.
"""
import logging
import os
import re
import subprocess
import sys
import threading
from pathlib import Path

import numpy as np

from chunking import split_on_silence
from textproc import join_texts

log = logging.getLogger("asr")
SR = 16000


def apply_hf_env(cfg):
    """Оффлайн-режим — вызывать ДО импорта transformers."""
    if cfg.get("offline_mode"):
        os.environ.setdefault("HF_HUB_OFFLINE", "1")
        os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")


def _whisper_prompt(cfg, context):
    """initial_prompt для Whisper: подсказка тематики + словарь + контекст."""
    parts = []
    hint = str(cfg.get("asr_context") or "").strip()
    if hint:
        parts.append(hint[:300])
    try:
        import corrections
        words = list(corrections.vocab())
        try:
            import userdict
            for w in userdict.terms():
                if w and w not in words:
                    words.append(w)
        except Exception:
            pass
        if words:
            parts.append("Словарь: " + ", ".join(words[:60]))
    except Exception:
        pass
    if context:
        parts.append(context)
    out = " ".join(parts).strip()
    return out[-600:] or None


# Типовые галлюцинации Whisper на тишине/шуме (артефакты обучения на
# субтитрах YouTube). Отбрасываем сегмент, только если он целиком состоит
# из таких фраз — внутри обычной речи ничего не трогаем.
_W_JUNK = (
    "продолжение следует", "спасибо за просмотр", "спасибо за внимание",
    "подписывайтесь на канал", "ставьте лайк", "до новых встреч",
    "всем пока", "thanks for watching", "thank you for watching",
)


def _w_key(text):
    """Нормализация для сравнения: только буквы/цифры, нижний регистр."""
    return " ".join(re.findall(r"[0-9a-zа-яё]+", (text or "").lower()))


def _join_clean(segs, prompt):
    """Склейка сегментов Whisper с отсевом галлюцинаций.

    Убирает: сегменты из одних фраз-паразитов («продолжение следует…»,
    в т.ч. повторённых через союзы), «субтитры …», эхо нашей же подсказки
    (initial_prompt) и зацикленные дословные повторы целых сегментов."""
    pkey = _w_key(prompt)
    out, prev = [], None
    for s in segs:
        t = s.text.strip()
        k = _w_key(t)
        if not k:
            continue
        if k.startswith(("субтитры", "редактор субтитров", "корректор")):
            log.info("Отброшена галлюцинация Whisper: %r", t)
            continue
        core = k
        for j in _W_JUNK:
            core = core.replace(j, " ")
        if not re.sub(r"\b(и|а|но|ну)\b", " ", core).strip():
            log.info("Отброшена галлюцинация Whisper: %r", t)
            continue
        if len(k) > 10 and pkey and k in pkey:
            log.info("Отброшено эхо подсказки Whisper: %r", t)
            continue
        if k == prev:
            log.info("Отброшен дословный повтор сегмента Whisper: %r", t)
            continue
        prev = k
        out.append(t)
    return " ".join(out).strip()


class WhisperTranscriber:
    """Второй локальный движок: Whisper (faster-whisper/CTranslate2, int8
    на CPU). Той же формы, что Transcriber — main.py разницы не видит."""

    def __init__(self, cfg):
        from faster_whisper import WhisperModel
        self.cfg = cfg
        self._lock = threading.Lock()
        lang = str(cfg.get("language") or "auto").strip().lower()
        self.language = None if lang in ("", "auto") else lang
        threads = _pick_threads(cfg)
        self.device = "cpu"
        name = (str(cfg.get("model_id", "")).replace("whisper-", "", 1)
                or "large-v3-turbo")
        log.info("Загружаю Whisper %s (int8, threads=%d)...", name, threads)
        self.model = WhisperModel(name, device="cpu",
                                  compute_type="int8", cpu_threads=threads)
        self.quantized = True
        log.info("Whisper загружен")

    def warmup(self):
        try:
            self.transcribe_parts([np.zeros(SR // 2, dtype=np.float32)])
        except Exception:
            log.exception("Прогрев Whisper не удался (не критично)")

    def transcribe(self, audio, context=""):
        # длинное аудио Whisper режет сам (окна 30 с) — свой чанкинг не нужен
        return self.transcribe_parts([audio], context=context)[0]

    def transcribe_parts(self, parts, context=""):
        import vad
        texts = []
        ctx = context or ""
        for i, p in enumerate(parts):
            if vad.has_speech(p) is False:
                texts.append("")
                continue
            beams = max(1, int(self.cfg.get("num_beams", 1) or 1))
            prompt = _whisper_prompt(
                self.cfg, ctx[-int(self.cfg.get("context_chars", 300)):])
            kw = dict(
                language=self.language,
                beam_size=beams if beams > 1 else 5,
                initial_prompt=prompt,
                # обе классические причины галлюцинаций Whisper: тишина в
                # окне (лечит встроенный Silero VAD) и самоподкрепление на
                # собственном прошлом тексте (condition_on_previous_text)
                condition_on_previous_text=False,
                vad_filter=True,
                vad_parameters={"min_silence_duration_ms": 300,
                                "speech_pad_ms": 200})
            with self._lock:
                try:
                    segs = list(self.model.transcribe(p, **kw)[0])
                except Exception:
                    log.exception("VAD-фильтр Whisper недоступен — "
                                  "распознаю без него")
                    kw.pop("vad_parameters", None)
                    kw["vad_filter"] = False
                    segs = list(self.model.transcribe(p, **kw)[0])
            t = _join_clean(segs, prompt)
            texts.append(t)
            ctx = (ctx + " " + t).strip()
            if len(parts) > 1:
                log.info("Фрагмент %d/%d распознан (Whisper)",
                         i + 1, len(parts))
        return texts


def load_transcriber(cfg, notify=None):
    """Загрузка с фолбэком: модели нет в кэше — докачиваем и пробуем снова.

    ВАЖНО: скачивание идёт ОТДЕЛЬНЫМ процессом с чистым окружением —
    huggingface_hub читает HF_HUB_OFFLINE один раз при импорте, и менять
    переменную в текущем процессе бесполезно (проверено на пользователе:
    докачка новой модели молча не выходила в сеть)."""
    apply_hf_env(cfg)
    if str(cfg.get("model_id") or "").startswith("whisper"):
        try:
            return WhisperTranscriber(cfg)
        except Exception:
            log.exception("Whisper не загрузился — доустанавливаю "
                          "движок/модель (~1.6 ГБ, один раз)")
            if notify:
                try:
                    notify("Скачиваю движок Whisper и модель (~1.6 ГБ) — "
                           "прогресс во вкладке «Журнал»...")
                except Exception:
                    pass
            env = dict(os.environ)
            env["HF_HUB_OFFLINE"] = "0"
            env["TRANSFORMERS_OFFLINE"] = "0"
            app_dir = Path(__file__).resolve().parent
            py = sys.executable
            if sys.platform == "win32":
                py = str(Path(py).with_name("python.exe"))
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            r = subprocess.run(
                [py, "-m", "pip", "install", "-q", "faster-whisper"],
                env=env, cwd=app_dir, timeout=1800, capture_output=True,
                text=True, creationflags=flags)
            log.info("pip faster-whisper: код %d %s", r.returncode,
                     (r.stderr or "")[-300:])
            name = (str(cfg.get("model_id")).replace("whisper-", "", 1)
                    or "large-v3-turbo")
            code = ("from faster_whisper import WhisperModel; "
                    "WhisperModel(%r, device='cpu', compute_type='int8')"
                    % name)
            r = subprocess.run([py, "-c", code], env=env, cwd=app_dir,
                               timeout=7200, capture_output=True, text=True,
                               creationflags=flags)
            log.info("Загрузка модели Whisper: код %d\n%s", r.returncode,
                     ((r.stdout or "") + (r.stderr or ""))[-800:])
            if r.returncode != 0:
                raise RuntimeError("Не удалось скачать Whisper — см. журнал")
            return WhisperTranscriber(cfg)
    try:
        return Transcriber(cfg)
    except Exception:
        log.exception("Модель не загрузилась из кэша — скачиваю %s",
                      cfg.get("model_id"))
        if notify:
            try:
                notify("Скачиваю модель распознавания — это может занять "
                       "несколько минут, прогресс во вкладке «Журнал»...")
            except Exception:
                pass
        env = dict(os.environ)
        env["HF_HUB_OFFLINE"] = "0"
        env["TRANSFORMERS_OFFLINE"] = "0"
        app_dir = Path(__file__).resolve().parent
        py = sys.executable
        if sys.platform == "win32":  # не pythonw: у него нет stdout
            py = str(Path(py).with_name("python.exe"))
        proc = subprocess.run(
            [py, str(app_dir / "download_model.py")],
            env=env, cwd=app_dir, timeout=7200,
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        tail = ((proc.stdout or "") + "\n" + (proc.stderr or "")).strip()
        log.info("Скачивание модели завершилось с кодом %d:\n%s",
                 proc.returncode, tail[-2000:])
        if proc.returncode != 0:
            raise RuntimeError(
                f"Не удалось скачать модель {cfg.get('model_id')}: "
                f"{tail[-500:]}")
        return Transcriber(cfg)


def chunk_bounds(cfg):
    """Границы фрагментов. В мультиязычном режиме с автоопределением языка
    режем по фразам (3-12 c): каждая фраза распознаётся на СВОЁМ языке —
    русский и английский спокойно живут в одной диктовке."""
    lang = str(cfg.get("language") or "auto").strip().lower()
    if lang in ("", "auto") and cfg.get("multilingual_mode", True):
        return 3.0, 12.0
    return float(cfg.get("chunk_min_sec", 15)), float(cfg.get("chunk_max_sec", 30))


def _pick_dtype(cfg, torch):
    """bf16 на CPU с AVX512/AMX: качество идентично fp32 (проверено: 0.961 =
    0.961 на русском эталоне), а на процессорах с аппаратным bf16 (Zen4/5,
    новые Intel) заметно быстрее. Иначе — fp32."""
    pref = str(cfg.get("cpu_dtype") or "auto").lower()
    if pref in ("fp32", "float32"):
        return torch.float32
    if pref in ("bf16", "bfloat16"):
        return torch.bfloat16
    try:
        cap = str(torch.backends.cpu.get_cpu_capability())
    except Exception:
        cap = ""
    return torch.bfloat16 if cap in ("AVX512", "AMX") else torch.float32


def _pick_threads(cfg):
    n = int(cfg.get("torch_threads") or 0)
    if n > 0:
        return n
    try:  # SMT-потоки на CPU-инференсе только мешают — берём физические ядра
        import psutil
        return max(1, psutil.cpu_count(logical=False) or 1)
    except Exception:
        return max(1, (os.cpu_count() or 8) // 2)


class Transcriber:
    def __init__(self, cfg):
        import torch
        self.torch = torch
        threads = _pick_threads(cfg)
        torch.set_num_threads(threads)
        self.cfg = cfg
        self._lock = threading.Lock()  # generate не реентерабелен
        lang = str(cfg.get("language") or "auto").strip().lower()
        self.language = None if lang in ("", "auto") else lang

        device = "cpu"
        if cfg.get("device", "auto") in ("auto", "xpu"):
            try:  # Intel Arc через XPU, если сборка torch его умеет
                if hasattr(torch, "xpu") and torch.xpu.is_available():
                    device = "xpu"
            except Exception:
                pass

        from transformers import AutoModelForMultimodalLM, AutoProcessor
        model_id = cfg["model_id"]
        log.info("Загружаю модель %s (device=%s, threads=%d)...",
                 model_id, device, threads)
        self.processor = AutoProcessor.from_pretrained(model_id)
        dtype = _pick_dtype(cfg, torch) if device == "cpu" else "auto"
        self.model = AutoModelForMultimodalLM.from_pretrained(model_id, dtype=dtype)
        try:
            self.model.to(device)
        except Exception:
            log.exception("Не удалось перейти на %s — откатываюсь на CPU", device)
            device = "cpu"
            self.model = self.model.to("cpu").float()
        self.model.eval()
        self.device = device

        # ВНИМАНИЕ: int8 заметно портит русский (проверено: 0.96 -> 0.86
        # похожести с эталоном), поэтому по умолчанию ВЫКЛЮЧЕНА — качество
        # важнее; скорость даёт потоковое распознавание во время записи.
        self.quantized = False
        if device == "cpu" and cfg.get("quantize_int8", False):
            try:  # динамическая int8-квантизация: ~1.5-2x быстрее на CPU
                self.model = torch.ao.quantization.quantize_dynamic(
                    self.model, {torch.nn.Linear}, dtype=torch.qint8)
                self.quantized = True
            except Exception:
                log.exception("int8-квантизация не удалась — остаюсь на float32")
        log.info("Модель загружена (device=%s, dtype=%s, int8=%s)",
                 device, self.model.dtype, self.quantized)

    def warmup(self):
        """Короткий прогон, чтобы первая реальная диктовка не платила за прогрев."""
        try:
            self._generate([np.zeros(SR // 2, dtype=np.float32)], 8)
        except Exception:
            log.exception("Прогрев не удался (не критично)")

    # --- публичные входы ---

    def transcribe(self, audio: np.ndarray, context="") -> str:
        """audio: float32 mono 16 kHz. Длинное аудио режется по паузам."""
        cmin, cmax = chunk_bounds(self.cfg)
        parts = split_on_silence(audio, SR, min_chunk_sec=cmin, max_chunk_sec=cmax)
        # склейка с восстановлением точек/заглавных на стыках фрагментов
        return join_texts(self.transcribe_parts(parts, context=context))

    def transcribe_parts(self, parts, context=""):
        """Список фрагментов → список текстов, строго по одному.

        context — уже распознанный текст диктовки: уходит в системный промт,
        модель видит продолжение фразы, и мелкие куски распознаются так же
        точно, как крупные (проверено на эталоне; тишина с контекстом эха
        не порождает). Батч-инференс проверен и ОТКЛОНЁН: паддинг фрагментов
        разной длины портит распознавание (артефакты, потери фраз)."""
        import vad
        texts = []
        ctx = context or ""
        for i, p in enumerate(parts):
            if vad.has_speech(p) is False:  # шум/тишина: не распознаём
                log.info("Фрагмент %d/%d без речи — пропускаю", i + 1, len(parts))
                texts.append("")
                continue
            dur = len(p) / SR
            max_new = min(4096, max(64, int(
                dur * self.cfg.get("tokens_per_sec", 16)) + 32))
            t = self._generate(
                [p], max_new,
                context=ctx[-int(self.cfg.get("context_chars", 300)):])[0]
            texts.append(t)
            ctx = (ctx + " " + t).strip()
            if len(parts) > 1:
                log.info("Фрагмент %d/%d распознан", i + 1, len(parts))
        return texts

    # --- низкий уровень ---

    def _system_prompt(self, context):
        """Системный промт Qwen3-ASR: язык (как в apply_transcription_request),
        словарь пользователя (hotwords из исправлений) и контекст диктовки —
        свободный текст, на который модель опирается."""
        parts = []
        if self.language:
            try:
                from transformers.models.qwen3_asr.processing_qwen3_asr import (
                    resolve_language)
                parts.append(resolve_language(self.language))
            except Exception:
                pass
        hint = str(self.cfg.get("asr_context") or "").strip()
        if hint:  # пользовательская подсказка: тематика, имена, термины
            parts.append(hint[:300])
        try:
            import corrections
            words = list(corrections.vocab())
            try:  # плюс пользовательская библиотека слов (опц., пусто = no-op)
                import userdict
                for w in userdict.terms():
                    if w and w not in words:
                        words.append(w)
            except Exception:
                pass
            if words:
                parts.append("Словарь: " + ", ".join(words[:80]))
        except Exception:
            pass
        if context:
            parts.append(context)
        return "\n".join(parts)

    def _generate(self, audios, max_new, context=""):
        torch = self.torch
        if self.cfg.get("normalize_audio") and len(audios) == 1:
            try:  # выровнять тихий микрофон (пик к 0.7, усиление ≤ 10x)
                a = audios[0]
                pk = float(np.abs(a).max())
                if pk > 0.001:
                    audios = [a * min(10.0, 0.7 / pk)]
            except Exception:
                pass
        sys_text = self._system_prompt(context) if len(audios) == 1 else ""
        with self._lock:
            if sys_text:
                msgs = [{"role": "system",
                         "content": [{"type": "text", "text": sys_text}]},
                        {"role": "user",
                         "content": [{"type": "audio", "audio": audios[0]}]}]
                inputs = self.processor.apply_chat_template(
                    [msgs], tokenize=True, add_generation_prompt=True,
                    return_dict=True)
            else:
                inputs = self.processor.apply_transcription_request(
                    audio=audios if len(audios) > 1 else audios[0],
                    language=self.language)  # None = автоопределение
            if self.quantized:
                inputs = inputs.to("cpu", torch.float32)
            else:
                inputs = inputs.to(self.model.device, self.model.dtype)
            gen_kw = {"max_new_tokens": max_new}
            beams = max(1, int(self.cfg.get("num_beams", 1) or 1))
            if beams > 1:  # точное декодирование: лучше текст, ~в beams раз
                gen_kw["num_beams"] = beams  # медленнее (опц.)
            with torch.inference_mode():
                output_ids = self.model.generate(**inputs, **gen_kw)
            decoded = self.processor.decode(
                output_ids[:, inputs["input_ids"].shape[1]:],
                return_format="parsed")
        out = []
        for d in decoded or []:
            out.append((d.get("transcription") or "") if isinstance(d, dict) else "")
        while len(out) < len(audios):
            out.append("")
        return out
