@echo off
rem Start the app without a console; errors go to app.log
cd /d "%~dp0"
start "" "venv\Scripts\pythonw.exe" main.py
