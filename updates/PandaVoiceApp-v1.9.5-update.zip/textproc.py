"""Склейка распознанных фрагментов с нормальной пунктуацией.

Фрагменты распознаются независимо (потоково и/или по фразам), поэтому на
стыках модель не ставит точки и заглавные. Правила консервативные: слова не
трогаем, только границы предложений и пробелы.
"""
import re

_TERMINAL = ".!?…"


def _cap(s):
    for i, ch in enumerate(s):
        if ch.isalpha():
            return s[:i] + ch.upper() + s[i + 1:]
    return s


def _keeps_case(word):
    """Слово, которому НЕЛЬЗЯ понижать регистр при склейке продолжения.

    Фрагменты распознаются отдельно, поэтому каждый начинается с заглавной;
    при склейке продолжение переводится в строчные — и «поехал в | Москву»
    превращалось в «поехал в москву». Аббревиатуры (CEX), составной регистр
    (PandaX, iPhone) и слова из пользовательского словаря сохраняем."""
    w = word.strip(" \t\n.,!?;:—-«»\"'()")
    if not w:
        return False
    if w.isupper() and len(w) > 1:          # CEX, DEX, API
        return True
    if any(c.isupper() for c in w[1:]):     # PandaX, ArbiScan, iPhone
        return True
    try:                                    # известные термины пользователя
        import userdict
        if any(t.lower() == w.lower() for t in userdict.terms()):
            return True
    except Exception:
        pass
    return False


def _strip_seam_period(t):
    """Убрать точку в конце ПРОМЕЖУТОЧНОГО фрагмента: модель завершает
    точкой почти каждый изолированный кусок («привычка»), информации в ней
    нет. «?», «!», «…» — настоящая интонация, их сохраняем."""
    t = t.rstrip()
    while t and t[-1] == ".":
        if len(t) >= 2 and t[-2] in ".!?…":  # многоточие/?. — не трогаем
            break
        t = t[:-1].rstrip()
    return t


def join_texts(pieces, at_pause=None):
    """Склеить фрагменты в цельный текст.

    at_pause — список флагов «этот фрагмент отрезан по настоящей паузе речи»
    (конец фразы). Замер на эталонной диктовке: сохранять точку на таких швах
    заметно лучше, чем снимать её везде (F1 пунктуации 0.95 против 0.89).

    - разрез ПОСРЕДИ фразы (вынужденный, по длине): точка в конце фрагмента —
      привычка модели завершать изолированный кусок, её убираем, фраза
      продолжается со строчной;
    - разрез по паузе: точку сохраняем — это конец предложения;
    - точки ВНУТРИ фрагмента модель ставит осмысленно, с контекстом — они
      сохраняются; «?», «!», «…» на стыке тоже сохраняются;
    - в конце всего текста — завершающая точка, если её нет.
    """
    flags = list(at_pause or [])
    pairs = [(re.sub(r"\s+", " ", p).strip(),
              flags[i] if i < len(flags) else False)
             for i, p in enumerate(pieces) if p and p.strip()]
    if not pairs:
        return ""
    parts = [p for p, _ in pairs]
    out = []
    for i, (p, cut_at_pause) in enumerate(pairs):
        if i < len(parts) - 1 and not cut_at_pause:
            p = _strip_seam_period(p) or p
        if out and out[-1][-1] in _TERMINAL:
            p = _cap(p)
        elif out:  # предложение продолжается после паузы — строчная буква
            if p[:1].isalpha() and not _keeps_case(p.split(maxsplit=1)[0]):
                p = p[0].lower() + p[1:]
        else:
            p = _cap(p)
        out.append(p)
    text = " ".join(out).strip()
    if text and text[-1] not in _TERMINAL:
        text += "."
    return text
