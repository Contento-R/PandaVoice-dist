"""Окно приложения (tkinter): статус, история вводов, все настройки.

Живёт в главном потоке. Команды из других потоков (трей, хоткеи) приходят
через thread-safe очередь и выполняются в цикле _poll. Закрытие или
сворачивание окна прячет его в трей (withdraw) — на панели задач приложение
не висит, пока окно скрыто.
"""
import logging
import os
import queue
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

import appconfig
import history
import theme

log = logging.getLogger("gui")

# тёмная палитра приложения
BG = "#1b1b1f"        # фон окна
SIDEBAR = "#141417"   # боковая панель навигации (темнее фона)
SURFACE = "#26262c"   # приподнятые поверхности: кнопки, карточки, шапки
FIELD = "#2c2c33"     # поля ввода и списки
BORDER = "#3d3d46"
TEXT = "#e8e8ec"
MUTED = "#9a9aa3"
ACCENT = "#4cc38a"    # фирменный зелёный
SELECT = "#31543f"    # фон выделения
DANGER = "#e5484d"
NAV_BG = "#1f1f24"    # фон активного пункта меню
CHIP = "#33333c"      # «клавиша»-бейдж
ZEBRA = "#31313a"     # чередование строк списков

STATE_RU = {
    "loading": "загрузка модели...",
    "idle": "готово (Left Alt+` — начать запись)",
    "recording": "идёт ЗАПИСЬ (Left Alt+` — стоп)",
    "processing": "распознавание...",
    "paused": "пауза",
}
STATE_DOT = {"loading": MUTED, "idle": ACCENT, "recording": DANGER,
             "processing": "#f5a524", "paused": MUTED}


def dark_titlebar(win):
    """Тёмный заголовок окна (Windows 10/11); на Win11 красим в цвет фона."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        win.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(win.winfo_id())
        dwm = ctypes.windll.dwmapi
        one = ctypes.c_int(1)
        if dwm.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(one), 4) != 0:
            dwm.DwmSetWindowAttribute(hwnd, 19, ctypes.byref(one), 4)
        cap = ctypes.c_int(int(BG[5:7] + BG[3:5] + BG[1:3], 16))  # COLORREF BGR
        dwm.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(cap), 4)
    except Exception:
        pass


_MOD_MAP = {  # Tk keysym -> имя клавиши библиотеки keyboard (Windows)
    "Control_L": "ctrl", "Control_R": "right ctrl",
    "Alt_L": "alt", "Alt_R": "right alt",
    "Shift_L": "shift", "Shift_R": "right shift",
    "Super_L": "windows", "Super_R": "right windows",
}
_KEYSYM_MAP = {"Return": "enter", "Escape": "esc", "space": "space",
               "Tab": "tab", "Insert": "insert", "Home": "home",
               "End": "end", "Prior": "page up", "Next": "page down",
               "Up": "up", "Down": "down", "Left": "left", "Right": "right"}


class HotkeyEntry(ttk.Entry):
    """Поле, которое само считывает нажатую клавишу или комбинацию.

    Кликните в поле и нажмите клавиши: модификаторы (в т.ч. левые/правые
    Ctrl, Alt, Shift по отдельности) + обычная клавиша = комбинация;
    отпустили одни модификаторы — записывается сам модификатор
    (например «right alt»). Backspace/Delete — очистить поле.
    """

    def __init__(self, master, textvariable):
        super().__init__(master, textvariable=textvariable)
        self.var = textvariable
        self._held = []      # активные модификаторы в порядке нажатия
        self._committed = False
        self.bind("<KeyPress>", self._press)
        self.bind("<KeyRelease>", self._release)
        self.bind("<FocusIn>", self._focus)

    def _focus(self, _e):
        self._held = []
        self._committed = False

    def _normal_name(self, e):
        ks = e.keysym
        if ks in _KEYSYM_MAP:
            return _KEYSYM_MAP[ks]
        if ks.startswith("F") and ks[1:].isdigit():
            return ks.lower()  # F1..F24
        if ks.isascii() and len(ks) == 1 and (ks.isalnum() or ks in "-=[];',./`\\"):
            return ks.lower()
        # раскладка-независимо: буквы/цифры по виртуальному коду (Windows VK
        # совпадает с ASCII для A-Z и 0-9) — работает и на кириллице
        kc = getattr(e, "keycode", 0)
        if 0x41 <= kc <= 0x5A:            # A-Z
            return chr(kc).lower()
        if 0x30 <= kc <= 0x39:            # 0-9
            return chr(kc)
        if 0x60 <= kc <= 0x69:            # numpad 0-9
            return str(kc - 0x60)
        oem = {0xC0: "`", 0xBD: "-", 0xBB: "=", 0xDB: "[", 0xDD: "]",
               0xDC: "\\", 0xBA: ";", 0xDE: "'", 0xBC: ",", 0xBE: ".",
               0xBF: "/"}.get(kc)  # OEM-клавиши по VK — раскладко-независимо
        if oem:
            return oem
        # медиа/доп. клавиши (Fn-слой: ▶⏸ ⏹ ⏮ ⏭, громкость, почта, кальк.) —
        # имена ровно как в библиотеке keyboard, чтобы хоткей совпадал
        media = {0xA6: "browser back", 0xA7: "browser forward",
                 0xAC: "browser start and home", 0xAD: "volume mute",
                 0xAE: "volume down", 0xAF: "volume up", 0xB0: "next track",
                 0xB1: "previous track", 0xB2: "stop media",
                 0xB3: "play/pause media", 0xB4: "start mail",
                 0xB5: "select media", 0xB6: "start application 1",
                 0xB7: "start application 2"}.get(kc)
        if media:
            return media
        return None  # незнакомая клавиша — игнорируем

    def _press(self, e):
        ks = e.keysym
        if ks in ("BackSpace", "Delete"):
            self.var.set("")
            self._focus(None)
            return "break"
        mod = _MOD_MAP.get(ks)
        if mod:
            if mod not in self._held:
                self._held.append(mod)
                self._committed = False
                self.var.set("+".join(self._held))
        else:
            key = self._normal_name(e)
            if key:
                self.var.set("+".join(self._held + [key]))
                self._committed = True
        return "break"

    def _release(self, e):
        mod = _MOD_MAP.get(e.keysym)
        if mod:
            if not self._committed and self._held:
                # отпустили модификатор(ы) без обычной клавиши —
                # хоткеем становится сам модификатор
                self.var.set("+".join(self._held))
                self._committed = True
            if mod in self._held:
                self._held.remove(mod)
        return "break"


class Toggle(tk.Canvas):
    """Переключатель-«тумблер» (как в современных приложениях) вместо
    чекбокса: пилюля с бегающим кружком, зелёная во включённом состоянии."""

    def __init__(self, master, variable, k=1.0, bg=None):
        self.w, self.h = int(38 * k), int(20 * k)
        # bg по умолчанию берём в рантайме: тема может подменить SURFACE
        super().__init__(master, width=self.w, height=self.h,
                         bg=SURFACE if bg is None else bg,
                         highlightthickness=0, cursor="hand2")
        self.var = variable
        self._pos = 1.0 if variable.get() else 0.0  # позиция кружка 0..1
        self._anim = 0  # токен: новый клик обрывает предыдущую пружинку
        self.bind("<Button-1>", lambda e: self.var.set(not self.var.get()))
        variable.trace_add("write", lambda *a: self._on_change())
        self._draw()

    def _on_change(self):
        target = 1.0 if self.var.get() else 0.0
        if not theme.animated():  # classic: мгновенно, как всегда было
            self._pos = target
            self._draw()
            return
        self._anim += 1
        my, start = self._anim, self._pos

        def step(i):
            if my != self._anim:
                return
            try:
                if not self.winfo_exists():
                    return
                self._pos = start + (target - start) * theme.SPRING[i]
                self._draw()
                if i + 1 < len(theme.SPRING):
                    self.after(theme.STEP_MS, step, i + 1)
            except tk.TclError:
                pass

        step(0)

    def _draw_img(self):
        """Сглаженный тумблер через Pillow: рисуем в 4x и сжимаем LANCZOS —
        без «лесенок» канвы. False — Pillow нет, рисуем как раньше."""
        try:
            from PIL import Image, ImageDraw, ImageTk
        except Exception:
            return False
        try:
            pos = max(0.0, min(1.12, self._pos))
            key = round(pos, 2)
            cache = getattr(self, "_imgs", None)
            if cache is None:
                cache = self._imgs = {}
            img = cache.get(key)
            if img is None:
                S = 4
                w, h = self.w * S, self.h * S
                fill = theme.lerp_hex(theme.TRACK_OFF, ACCENT,
                                      min(1.0, pos))
                im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
                d = ImageDraw.Draw(im)
                d.rounded_rectangle((0, 0, w - 1, h - 1), radius=h // 2,
                                    fill=fill)
                pad = max(2, int(self.h * 0.12))
                x = int((pad + (self.w - self.h) * pos) * S)
                k = (self.h - 2 * pad) * S
                d.ellipse((x, pad * S, x + k, pad * S + k), fill="#ffffff")
                im = im.resize((self.w, self.h), Image.LANCZOS)
                img = ImageTk.PhotoImage(im)
                cache[key] = img
            self.delete("all")
            self.create_image(0, 0, anchor="nw", image=img)
            return True
        except Exception:
            return False

    def _draw(self):
        if self._draw_img():
            return
        self.delete("all")
        on = bool(self.var.get())
        w, h = self.w, self.h
        r = h // 2
        pos = self._pos
        try:  # цвет дорожки перетекает вместе с кружком (в classic pos = 0|1)
            fill = theme.lerp_hex(theme.TRACK_OFF, ACCENT, pos)
        except Exception:
            fill = ACCENT if on else "#3d3d46"
        self.create_oval(0, 0, h, h, fill=fill, outline=fill)
        self.create_oval(w - h, 0, w - 1, h, fill=fill, outline=fill)
        self.create_rectangle(r, 0, w - r, h, fill=fill, outline=fill)
        pad = max(2, int(h * 0.12))
        x = pad + (w - h) * pos
        self.create_oval(x, pad, x + h - 2 * pad, h - pad,
                         fill="#ffffff", outline="")


class Gui:
    def __init__(self, app):
        self.app = app
        self._q = queue.Queue()
        self._entries = []
        self.root = tk.Tk()
        self.root.title(f"Panda Voice {appconfig.version()}")
        try:
            self.k = max(1.0, self.root.winfo_fpixels("1i") / 96.0)
        except Exception:
            self.k = 1.0
        try:  # опциональная тема (classic = ничего не меняет); стиль
            theme.set_cfg(self.app.cfg)  # Obsidian подменяет константы цветов,
            theme.apply_style(sys.modules[__name__])  # поэтому — ДО _theme()
        except Exception:
            log.exception("Тема недоступна")
        self._theme()
        try:
            theme.retheme_ttk(ttk.Style(self.root))
            theme.install_buttons(self.root)
        except Exception:
            log.exception("Анимации кнопок недоступны")
        try:  # иконка окна — панда
            from PIL import ImageTk
            from branding import panda_icon
            self._icon_img = ImageTk.PhotoImage(panda_icon(size=64))
            self.root.iconphoto(True, self._icon_img)
        except Exception:
            log.exception("Не удалось поставить иконку окна")
        self.root.protocol("WM_DELETE_WINDOW", self.hide)
        self.root.bind("<Unmap>", self._on_unmap)
        try:
            from overlay import Overlay
            self.overlay = Overlay(self.root, app)
        except Exception:
            log.exception("Оверлей записи недоступен")
            self.overlay = None
        self._build()
        self._load_settings()
        self._install_autosave()
        dark_titlebar(self.root)
        # размер окна — по фактическому содержимому и DPI, чтобы кнопки
        # («Сохранить и применить» и др.) всегда были видны
        k = self.k
        self.root.update_idletasks()
        # по самой большой странице (настройки при старте не показаны)
        pw = max(f.winfo_reqwidth() for f in self.pages.values())
        ph = max(f.winfo_reqheight() for f in self.pages.values())
        w = min(max(int(760 * k), pw + int(200 * k)), int(980 * k))
        h = max(int(560 * k), ph + int(70 * k))
        try:  # не вылезать за экран
            w = min(w, self.root.winfo_screenwidth() - 60)
            h = min(h, self.root.winfo_screenheight() - 80)
        except Exception:
            pass
        self.root.geometry(f"{w}x{h}")
        self.root.minsize(int(640 * k), int(480 * k))
        self.root.withdraw()  # старт скрыто: только иконка в трее
        self._poll()

    def _theme(self):
        """Тёмная тема поверх ttk 'clam' — единственной темы, где можно
        перекрасить всё (vista/xpnative игнорируют цвета)."""
        self.root.configure(bg=BG)
        st = ttk.Style(self.root)
        try:
            st.theme_use("clam")
        except Exception:
            pass
        st.configure(".", background=BG, foreground=TEXT, bordercolor=BORDER,
                     lightcolor=BG, darkcolor=BG, troughcolor=FIELD,
                     focuscolor=BG, selectbackground=SELECT,
                     selectforeground=TEXT, fieldbackground=FIELD)
        st.configure("Muted.TLabel", foreground=MUTED)
        st.configure("Section.TLabel", foreground=MUTED,
                     font=("Segoe UI", 8, "bold"))
        st.configure("TButton", background=SURFACE, foreground=TEXT,
                     borderwidth=0, padding=(12, 6))
        st.map("TButton", background=[("pressed", "#1f1f24"),
                                      ("active", "#34343c")])
        st.configure("Accent.TButton", background=ACCENT, foreground="#10241a")
        st.map("Accent.TButton", background=[("pressed", "#3da878"),
                                             ("active", "#5fd39c")])
        st.configure("TNotebook", background=BG, borderwidth=0,
                     tabmargins=(8, 8, 8, 0))
        st.configure("TNotebook.Tab", background=BG, foreground=MUTED,
                     padding=(18, 8), borderwidth=0, focuscolor=SURFACE,
                     lightcolor=SURFACE, bordercolor=BG)
        st.map("TNotebook.Tab", background=[("selected", SURFACE)],
               foreground=[("selected", TEXT)])
        st.configure("Treeview", background=FIELD, fieldbackground=FIELD,
                     foreground=TEXT, borderwidth=0,
                     rowheight=int(24 * self.k))
        st.configure("Treeview.Heading", background=SURFACE, foreground=MUTED,
                     borderwidth=0, padding=(6, 6))
        st.map("Treeview.Heading", background=[("active", SURFACE)])
        st.map("Treeview", background=[("selected", SELECT)],
               foreground=[("selected", "#ffffff")])
        for w in ("TEntry", "TCombobox", "TSpinbox"):
            st.configure(w, fieldbackground=FIELD, foreground=TEXT,
                         insertcolor=TEXT, bordercolor=BORDER,
                         lightcolor=BORDER, darkcolor=BORDER,
                         arrowcolor=TEXT, background=SURFACE, padding=5)
            st.map(w, fieldbackground=[("readonly", FIELD),
                                       ("disabled", SURFACE)],
                   foreground=[("disabled", MUTED)])
        for w in ("TCheckbutton", "TRadiobutton"):
            st.configure(w, background=BG, foreground=TEXT, focuscolor=BG,
                         indicatorbackground=FIELD, indicatorforeground="#10241a")
            st.map(w, background=[("active", BG)],
                   indicatorbackground=[("selected", ACCENT),
                                        ("active", "#34343c")])
        for opt, val in (("background", FIELD), ("foreground", TEXT),
                         ("selectBackground", SELECT),
                         ("selectForeground", TEXT)):
            self.root.option_add(f"*TCombobox*Listbox.{opt}", val)

    def _dark_text(self, t):
        """Классические tk-виджеты (Text) ttk-стиль не красит — вручную."""
        t.configure(bg=FIELD, fg=TEXT, insertbackground=TEXT,
                    selectbackground=SELECT, selectforeground=TEXT,
                    relief="flat", highlightthickness=1, borderwidth=0,
                    highlightbackground=BORDER, highlightcolor=BORDER,
                    padx=6, pady=4)

    # --- потокобезопасный вход из других потоков ---

    def call(self, fn, *args):
        self._q.put((fn, args))

    def _poll(self):
        try:
            while True:
                fn, args = self._q.get_nowait()
                try:
                    fn(*args)
                except Exception:
                    log.exception("Ошибка GUI-команды")
        except queue.Empty:
            pass
        try:
            if not self.root.winfo_exists():
                return  # окно уничтожено (выход) — цикл больше не нужен
            self._refresh_status()
            self._log_tick += 1
            if self._log_tick % 13 == 0 and \
                    self.root.state() in ("normal", "zoomed"):
                self._refresh_log()  # ~раз в 2 секунды при открытом окне
        except tk.TclError:
            return
        except Exception:
            log.exception("Ошибка обновления статуса")
        try:
            self.root.after(150, self._poll)
        except Exception:
            pass  # окно уничтожено между проверкой и перепланированием

    def mainloop(self):
        self.root.mainloop()

    # --- показать/спрятать/закрыть ---

    def show(self):
        self.root.deiconify()
        self.root.lift()
        theme.fade_in(self.root, 160)  # no-op при classic
        try:
            self.root.focus_force()
        except Exception:
            pass
        self.show_page("history")

    def hide(self):
        self.root.withdraw()

    def _on_unmap(self, event):
        # сворачивание окна = спрятать в трей
        if event.widget is self.root and self.root.state() == "iconic":
            self.root.withdraw()

    def quit(self):
        try:
            self.root.destroy()
        except Exception:
            pass

    # --- оверлей записи (вызывается App через call) ---

    def overlay_show(self, state):
        w = getattr(self.app, "_aura_overlay", None)
        if w is not None:  # аура: премиум-оверлей (веб); сбой = классика
            try:
                self.app._aura_ov_visible = True
                w.show()
                import aura
                aura.fix_overlay_once(self.app)
                return
            except Exception:
                log.exception("Веб-оверлей не показался — классическая пилюля")
                self.app._aura_overlay = None
                self.app._aura_panel = None
        if self.overlay:
            self.overlay.show(state)

    def overlay_hide(self):
        w = getattr(self.app, "_aura_overlay", None)
        if w is not None:
            self.app._aura_ov_visible = False
            try:
                w.hide()
                return
            except Exception:
                self.app._aura_overlay = None
        if self.overlay:
            self.overlay.hide()

    def on_history_changed(self):
        """Новая запись в истории — обновить список без кнопки «Обновить»."""
        try:
            if self.root.state() in ("normal", "zoomed"):
                self._reload_history()
        except Exception:
            log.exception("Не удалось обновить историю")

    # --- построение окна ---

    def _build(self):
        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True)
        self._nav_items = {}
        self._build_sidebar(main)

        self.content = tk.Frame(main, bg=BG)
        self.content.pack(side="left", fill="both", expand=True)

        top = ttk.Frame(self.content, padding=(14, 10))
        top.pack(fill="x")
        self.status_dot = ttk.Label(top, text="●", foreground=MUTED,
                                    font=("Segoe UI", 11))
        self.status_dot.pack(side="left", padx=(0, 6))
        self.status_var = tk.StringVar(value="запуск...")
        _stl = ttk.Label(top, textvariable=self.status_var)
        if theme.styled():  # obsidian: статус — моноширинным
            _stl.configure(font=(theme.MONO, 9))
        _stl.pack(side="left")
        self.pause_btn_var = tk.StringVar(value="Пауза")
        ttk.Button(top, textvariable=self.pause_btn_var,
                   command=self._toggle_pause).pack(side="right", padx=4)
        ttk.Button(top, text="Проверка микрофона",
                   command=self._mic_test).pack(side="right", padx=4)
        ttk.Button(top, text="Обновление",
                   command=self._run_update).pack(side="right", padx=4)

        box = tk.Frame(self.content, bg=BG)
        box.pack(fill="both", expand=True)
        self.pages = {}
        for key, builder in (("history", self._build_history_tab),
                             ("dictionary", self._build_dictionary_tab),
                             ("settings", self._build_settings_tab),
                             ("log", self._build_log_tab)):
            f = ttk.Frame(box, padding=(14, 4))
            self.pages[key] = f
            # длинные страницы — с прокруткой колесиком: в маленьком окне
            # не нужно разворачивать его на весь экран
            builder(self._scrollable(f) if key in ("settings", "dictionary")
                    else f)
        self.show_page("history")

    def _scrollable(self, outer):
        """Вертикальная прокрутка содержимого страницы (колесико работает
        при наведении; если всё влезает — прокрутки нет)."""
        cv = tk.Canvas(outer, bg=BG, highlightthickness=0,
                       height=int(430 * self.k), width=int(600 * self.k))
        sb = ttk.Scrollbar(outer, orient="vertical", command=cv.yview)
        cv.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        cv.pack(side="left", fill="both", expand=True)
        inner = ttk.Frame(cv)
        wid = cv.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>",
                   lambda e: cv.configure(scrollregion=cv.bbox("all")))
        cv.bind("<Configure>", lambda e: cv.itemconfigure(wid, width=e.width))

        def wheel(e):
            box2 = cv.bbox("all")
            if box2 and box2[3] > cv.winfo_height():
                cv.yview_scroll(-int(e.delta / 120) * 3, "units")

        cv.bind("<Enter>", lambda e: cv.bind_all("<MouseWheel>", wheel))
        cv.bind("<Leave>", lambda e: cv.unbind_all("<MouseWheel>"))
        return inner

    def _build_sidebar(self, main):
        sb = tk.Frame(main, bg=SIDEBAR, width=int(176 * self.k))
        sb.pack(side="left", fill="y")
        sb.pack_propagate(False)
        head = tk.Frame(sb, bg=SIDEBAR)
        head.pack(fill="x", pady=(14, 16), padx=12)
        try:
            from PIL import ImageTk
            from branding import app_icon
            n = int(26 * self.k)
            self._side_icon = ImageTk.PhotoImage(app_icon(64).resize((n, n)))
            tk.Label(head, image=self._side_icon, bg=SIDEBAR).pack(side="left")
        except Exception:
            tk.Label(head, text="🐼", bg=SIDEBAR, fg=TEXT).pack(side="left")
        t = tk.Frame(head, bg=SIDEBAR)
        t.pack(side="left", padx=8)
        tk.Label(t, text="Panda Voice", bg=SIDEBAR, fg=TEXT, anchor="w",
                 font=("Segoe UI", 11, "bold")).pack(fill="x")
        tk.Label(t, text=appconfig.version(), bg=SIDEBAR, fg=MUTED,
                 anchor="w", font=("Segoe UI", 8)).pack(fill="x")
        for text, key in (("История", "history"), ("Словарь", "dictionary"),
                          ("Настройки", "settings"), ("Журнал", "log")):
            self._nav(sb, text, key)

    def _nav(self, sb, text, key):
        item = tk.Frame(sb, bg=SIDEBAR)
        item.pack(fill="x")
        bar = tk.Frame(item, bg=SIDEBAR, width=max(2, int(3 * self.k)))
        bar.pack(side="left", fill="y")
        lbl = tk.Label(item, text=theme.nav_label(text), bg=SIDEBAR, fg=MUTED,
                       anchor="w", padx=12, pady=7, cursor="hand2",
                       font=(("Segoe UI", 8, "bold") if theme.styled()
                             else ("Segoe UI", 10)))
        lbl.pack(side="left", fill="x", expand=True)
        for w in (item, bar, lbl):
            w.bind("<Button-1>", lambda e, k=key: self.show_page(k))
        self._nav_items[key] = (item, bar, lbl)

    def show_page(self, key):
        for k, f in self.pages.items():
            f.pack_forget()
        self.pages[key].pack(fill="both", expand=True)
        for k, (item, bar, lbl) in self._nav_items.items():
            on = k == key
            if on and theme.nav_pulse(item, bar, lbl):
                continue  # анимированная подсветка запущена (тема «animated»)
            item.configure(bg=NAV_BG if on else SIDEBAR)
            bar.configure(bg=ACCENT if on else SIDEBAR)
            lbl.configure(bg=NAV_BG if on else SIDEBAR,
                          fg=TEXT if on else MUTED)
        try:
            if key == "history":
                self._reload_history()
                self._update_greeting()
            elif key == "dictionary":
                self._reload_dict()
            elif key == "log":
                self._log_mtime = 0.0
                self._refresh_log()
        except Exception:
            log.exception("Не удалось обновить страницу %s", key)

    def _update_greeting(self):
        import time as _t
        h = _t.localtime().tm_hour
        g = ("Доброй ночи" if h < 5 else "Доброе утро" if h < 12
             else "Добрый день" if h < 17 else "Добрый вечер")
        self.greet_var.set(g + "!")
        try:
            entries = history.read_last(100000)
            words = sum(len((e.get("text") or "").split()) for e in entries)
            sec = sum(float(e.get("audio_sec") or 0) for e in entries)
            self.stats_var.set(
                f"{words:,} слов надиктовано · {len(entries)} записей · "
                f"{int(sec // 60)} мин речи".replace(",", " "))
        except Exception:
            self.stats_var.set("")

    def _chip(self, parent, text, bg=SURFACE):
        """«Клавиша»-бейдж для подсказок хоткеев."""
        return tk.Label(parent, text=text, bg=CHIP, fg=TEXT,
                        padx=8, pady=2, font=("Segoe UI", 9, "bold"),
                        highlightthickness=1, highlightbackground=BORDER)

    def _build_history_tab(self, tab):
        card = tk.Frame(tab, bg=SURFACE)
        card.pack(fill="x", pady=(6, 10))
        inner = tk.Frame(card, bg=SURFACE)
        inner.pack(fill="x", padx=14, pady=10)
        self.greet_var = tk.StringVar(value="Здравствуйте!")
        self.stats_var = tk.StringVar(value="")
        tk.Label(inner, textvariable=self.greet_var, bg=SURFACE, fg=TEXT,
                 anchor="w", font=("Segoe UI", 14, "bold")).pack(fill="x")
        tk.Label(inner, textvariable=self.stats_var, bg=SURFACE, fg=ACCENT,
                 anchor="w",
                 font=((theme.MONO, 9) if theme.styled()
                       else ("Segoe UI", 9))).pack(fill="x", pady=(2, 6))
        hint = tk.Frame(inner, bg=SURFACE)
        hint.pack(fill="x")
        tk.Label(hint, text="Нажмите", bg=SURFACE, fg=MUTED,
                 font=("Segoe UI", 9)).pack(side="left")
        parts = str(self.app.cfg.get("hotkey") or "left alt+`").split("+")
        for i, p in enumerate(parts):
            if i:
                tk.Label(hint, text="+", bg=SURFACE, fg=MUTED).pack(side="left")
            self._chip(hint, p.strip().title()).pack(side="left", padx=4)
        tk.Label(hint, text="— и диктуйте в любое поле; текст вставится сам.",
                 bg=SURFACE, fg=MUTED, font=("Segoe UI", 9)).pack(side="left")

        cols = ("ts", "dur", "text")
        self.tree = ttk.Treeview(tab, columns=cols, show="headings", height=9)
        self.tree.heading("ts", text="Время")
        self.tree.heading("dur", text="Сек")
        self.tree.heading("text", text="Текст")
        self.tree.column("ts", width=140, stretch=False)
        self.tree.column("dur", width=50, stretch=False, anchor="e")
        self.tree.column("text", width=380)
        self.tree.tag_configure("odd", background=ZEBRA)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_select_entry)
        self.tree.bind("<Double-1>", lambda e: self._edit_entry())

        ttk.Label(tab, style="Muted.TLabel", text=(
            "Двойной клик по записи — исправить текст; приложение запомнит "
            "замены слов и будет применять их к новым распознаваниям.")).pack(
            anchor="w", pady=(6, 0))
        self.full_text = tk.Text(tab, height=4, wrap="word", state="disabled")
        self._dark_text(self.full_text)
        self.full_text.pack(fill="x", pady=(4, 0))

        btns = ttk.Frame(tab)
        btns.pack(fill="x", pady=(6, 0))
        ttk.Button(btns, text="Обновить",
                   command=self._reload_history).pack(side="left")
        ttk.Button(btns, text="Копировать выбранное",
                   command=self._copy_selected).pack(side="left", padx=6)
        ttk.Button(btns, text="Исправить…",
                   command=self._edit_entry).pack(side="left", padx=6)
        ttk.Button(btns, text="Очистить историю",
                   command=self._clear_history).pack(side="right")
        ttk.Button(btns, text="Сбросить словарь замен",
                   command=self._clear_corrections).pack(side="right", padx=6)

    # --- словарь (библиотека специфических слов) ---

    def _build_dictionary_tab(self, tab):
        self._dict_words = {}
        self._sug_words = {}
        ttk.Label(tab, style="Muted.TLabel", wraplength=int(560 * self.k),
                  text=("Библиотека ваших специфических слов (крипто-термины "
                        "и т.п.). Эти слова подсказываются модели — она "
                        "узнаёт их сразу, даже без предыдущей ошибки. "
                        "Добавляйте вручную или из предложений ниже.")).pack(
            anchor="w", pady=(6, 8))

        addbar = tk.Frame(tab, bg=BG)
        addbar.pack(fill="x", pady=(0, 4))
        self.v_dictadd = tk.StringVar()
        e = ttk.Entry(addbar, textvariable=self.v_dictadd, width=30)
        e.pack(side="left")
        e.bind("<Return>", lambda _e: self._dict_add())
        ttk.Button(addbar, text="Добавить слово",
                   command=self._dict_add).pack(side="left", padx=6)
        ttk.Button(addbar, text="Импортировать список…",
                   command=self._dict_import).pack(side="left")

        ttk.Label(tab, style="Section.TLabel",
                  text="СЛОВА В БИБЛИОТЕКЕ").pack(anchor="w", pady=(10, 3))
        self.dict_tree = ttk.Treeview(tab, columns=("term",),
                                      show="headings", height=8)
        self.dict_tree.heading("term", text="Слово")
        self.dict_tree.column("term", width=340)
        self.dict_tree.tag_configure("odd", background=ZEBRA)
        self.dict_tree.pack(fill="both", expand=True)
        db = ttk.Frame(tab)
        db.pack(fill="x", pady=(6, 0))
        ttk.Button(db, text="Удалить выбранное",
                   command=self._dict_remove).pack(side="left")

        ttk.Label(tab, style="Section.TLabel",
                  text="ПРЕДЛОЖЕНИЯ  ·  часто используемые слова").pack(
            anchor="w", pady=(12, 3))
        self.sug_hint = ttk.Label(tab, style="Muted.TLabel",
                                  wraplength=int(560 * self.k), text="")
        self.sug_hint.pack(anchor="w", pady=(0, 3))
        self.sug_tree = ttk.Treeview(tab, columns=("word", "cnt"),
                                     show="headings", height=5)
        self.sug_tree.heading("word", text="Слово")
        self.sug_tree.heading("cnt", text="Раз")
        self.sug_tree.column("word", width=280)
        self.sug_tree.column("cnt", width=60, stretch=False, anchor="e")
        self.sug_tree.tag_configure("odd", background=ZEBRA)
        self.sug_tree.pack(fill="x")
        sb = ttk.Frame(tab)
        sb.pack(fill="x", pady=(6, 0))
        ttk.Button(sb, text="Добавить в словарь",
                   command=self._sug_add).pack(side="left")
        ttk.Button(sb, text="Скрыть предложение",
                   command=self._sug_dismiss).pack(side="left", padx=6)

    def _reload_dict(self):
        try:
            import userdict
        except Exception:
            log.exception("Модуль словаря недоступен")
            return
        for iid in self.dict_tree.get_children():
            self.dict_tree.delete(iid)
        self._dict_words = {}
        for i, w in enumerate(sorted(userdict.terms(), key=str.lower)):
            iid = f"t{i}"
            self._dict_words[iid] = w
            self.dict_tree.insert("", "end", iid=iid,
                                  tags=("odd",) if i % 2 else (), values=(w,))
        self._reload_suggestions()

    def _reload_suggestions(self):
        for iid in self.sug_tree.get_children():
            self.sug_tree.delete(iid)
        self._sug_words = {}
        if not self.app.cfg.get("dict_suggestions", False):
            self.sug_hint.configure(text=(
                "Автопредложения выключены. Включите их в Настройках → "
                "«Живой транскрипт и словарь», чтобы приложение само "
                "предлагало часто используемые слова."))
            return
        self.sug_hint.configure(text="")
        words = []
        try:
            import corrections
            import userdict
            entries = history.read_last(1000)
            mc = int(self.app.cfg.get("dict_suggest_min_count", 4))
            words = userdict.suggest(entries, min_count=mc,
                                     extra_known=corrections.vocab())
        except Exception:
            log.exception("Не удалось посчитать предложения словаря")
        for i, (w, cnt) in enumerate(words):
            iid = f"s{i}"
            self._sug_words[iid] = w
            self.sug_tree.insert("", "end", iid=iid,
                                 tags=("odd",) if i % 2 else (),
                                 values=(w, cnt))
        if not words:
            self.sug_hint.configure(text=(
                "Пока нечего предложить — надиктуйте больше текста, и часто "
                "повторяющиеся специфические слова появятся здесь."))

    def _dict_add(self):
        w = self.v_dictadd.get().strip()
        if not w:
            return
        try:
            import userdict
            # вставили список через запятую — добавляем всё сразу
            userdict.add_many(w) if ("," in w or ";" in w) else userdict.add(w)
        except Exception:
            log.exception("Не удалось добавить слово в словарь")
        self.v_dictadd.set("")
        self._reload_dict()

    def _dict_import(self):
        """Массовый импорт: вставить список из другого приложения."""
        win = tk.Toplevel(self.root)
        win.title("Импорт слов в библиотеку")
        win.transient(self.root)
        win.configure(bg=BG)
        dark_titlebar(win)
        theme.fade_in(win)
        ttk.Label(win, padding=(10, 8), text=(
            "Вставьте список терминов (Ctrl+V) — по одному на строку,\n"
            "через запятую или точку с запятой. Дубли пропускаются.")).pack(
            anchor="w")
        txt = tk.Text(win, wrap="word", height=12, width=48)
        self._dark_text(txt)
        txt.pack(fill="both", expand=True, padx=10)
        txt.focus_set()

        def do_import():
            try:
                import userdict
                n = userdict.add_many(txt.get("1.0", "end"))
            except Exception:
                log.exception("Импорт слов не удался")
                n = 0
            win.destroy()
            self._reload_dict()
            messagebox.showinfo("Panda Voice",
                                f"Добавлено терминов: {n}. Они уже "
                                "подсказываются модели при распознавании.")

        bar = ttk.Frame(win, padding=10)
        bar.pack(fill="x")
        ttk.Button(bar, text="Добавить всё", style="Accent.TButton",
                   command=do_import).pack(side="right")
        ttk.Button(bar, text="Отмена",
                   command=win.destroy).pack(side="right", padx=6)

    def _dict_remove(self):
        sel = self.dict_tree.selection()
        if not sel:
            messagebox.showinfo("Panda Voice", "Выберите слово в списке.")
            return
        try:
            import userdict
            for iid in sel:
                w = self._dict_words.get(iid)
                if w:
                    userdict.remove(w)
        except Exception:
            log.exception("Не удалось удалить слово из словаря")
        self._reload_dict()

    def _sug_add(self):
        sel = self.sug_tree.selection()
        if not sel:
            messagebox.showinfo("Panda Voice", "Выберите слово в предложениях.")
            return
        try:
            import userdict
            for iid in sel:
                w = self._sug_words.get(iid)
                if w:
                    userdict.add(w)
        except Exception:
            log.exception("Не удалось добавить предложенное слово")
        self._reload_dict()

    def _sug_dismiss(self):
        sel = self.sug_tree.selection()
        if not sel:
            return
        try:
            import userdict
            for iid in sel:
                w = self._sug_words.get(iid)
                if w:
                    userdict.dismiss(w)
        except Exception:
            log.exception("Не удалось скрыть предложение")
        self._reload_dict()

    def _build_settings_tab(self, tab):
        def section(title):
            ttk.Label(tab, text=title, style="Section.TLabel").pack(
                anchor="w", pady=(10, 3))
            card = tk.Frame(tab, bg=SURFACE)
            card.pack(fill="x")
            return card

        def row(card, label):
            r = tk.Frame(card, bg=SURFACE)
            r.pack(fill="x", padx=12, pady=4)
            tk.Label(r, text=label, bg=SURFACE, fg=TEXT,
                     font=("Segoe UI", 9)).pack(side="left")
            return r

        def hotkey_row(card, label, var):
            e = HotkeyEntry(row(card, label), textvariable=var)
            e.configure(width=20, justify="center")
            e.pack(side="right")

        def toggle_row(card, label, name):
            var = tk.BooleanVar()
            setattr(self, name, var)
            Toggle(row(card, label), var, self.k).pack(side="right")

        c = section("ГОРЯЧИЕ КЛАВИШИ  ·  кликните в поле и нажмите клавиши")
        self.v_hotkey = tk.StringVar()
        hotkey_row(c, "Запись (старт/стоп):", self.v_hotkey)
        self.v_repaste = tk.StringVar()
        hotkey_row(c, "Повторная вставка последнего текста:", self.v_repaste)
        self.v_correct = tk.StringVar()
        hotkey_row(c, "Исправить вставленный текст:", self.v_correct)
        self.v_openwin = tk.StringVar()
        hotkey_row(c, "Открыть окно приложения:", self.v_openwin)
        self.v_mode = tk.StringVar()
        rf = row(c, "Режим записи:")
        mf = tk.Frame(rf, bg=SURFACE)
        mf.pack(side="right")
        for text, val in (("toggle (нажал — старт, ещё раз — стоп)", "toggle"),
                          ("push-to-talk (пока зажата клавиша)", "push_to_talk")):
            tk.Radiobutton(mf, text=text, variable=self.v_mode, value=val,
                           bg=SURFACE, fg=TEXT, activebackground=SURFACE,
                           activeforeground=TEXT, selectcolor=FIELD,
                           highlightthickness=0, anchor="w",
                           font=("Segoe UI", 9)).pack(anchor="w")
        self.v_ptt = tk.StringVar()
        hotkey_row(c, "Клавиша push-to-talk:", self.v_ptt)
        self.v_interval = tk.StringVar()
        sp = ttk.Spinbox(row(c, "Интервал двойного нажатия, мс:"),
                         from_=150, to=2000, increment=50, width=8,
                         textvariable=self.v_interval)
        sp.pack(side="right")

        c = section("РАСПОЗНАВАНИЕ")
        self.MODELS = [("Быстрая (0.6B)", "Qwen/Qwen3-ASR-0.6B-hf"),
                       ("Точная (1.7B, медленнее, скачается ~3.5 ГБ)",
                        "Qwen/Qwen3-ASR-1.7B-hf"),
                       ("Whisper Turbo — лучшее качество (докачает ~1.6 ГБ)",
                        "whisper-large-v3-turbo")]
        self.v_model = tk.StringVar()
        ttk.Combobox(row(c, "Модель распознавания:"),
                     textvariable=self.v_model, state="readonly", width=34,
                     values=[n for n, _ in self.MODELS]).pack(side="right")
        self.LANGS = [("Авто (определять язык)", "auto"), ("Русский", "ru"),
                      ("English", "en"), ("中文", "zh"), ("Deutsch", "de"),
                      ("Français", "fr"), ("Español", "es"),
                      ("Українська", "uk")]
        self.v_lang = tk.StringVar()
        ttk.Combobox(row(c, "Язык распознавания:"),
                     textvariable=self.v_lang, state="readonly", width=34,
                     values=[n for n, _ in self.LANGS]).pack(side="right")
        self.v_device = tk.StringVar()
        self.device_box = ttk.Combobox(row(c, "Микрофон:"),
                                       textvariable=self.v_device,
                                       state="readonly", width=34,
                                       values=self._device_choices())
        self.device_box.pack(side="right")
        self.v_maxrec = tk.StringVar()
        ttk.Spinbox(row(c, "Максимум записи, сек:"), from_=30, to=3600,
                    increment=30, width=8,
                    textvariable=self.v_maxrec).pack(side="right")
        toggle_row(c, "Мультиязычный режим (разные языки в одной диктовке)",
                   "v_multi")
        self.v_asrctx = tk.StringVar()
        e_ctx = ttk.Entry(row(c, "Подсказка модели (тематика, имена):"),
                          textvariable=self.v_asrctx, width=36)
        e_ctx.pack(side="right")
        toggle_row(c, "Идеальный финал: перераспознать запись целиком после "
                   "остановки — пунктуация и окончания как надо, ждать "
                   "дольше", "v_repass")
        toggle_row(c, "Beam search (в наших замерах русский НЕ улучшил, "
                   "втрое медленнее — включать не советуем)", "v_beams")

        c = section("ЖИВОЙ ТРАНСКРИПТ И СЛОВАРЬ")
        toggle_row(c, "Показывать распознанный текст во время диктовки",
                   "v_live")
        toggle_row(c, "Быстрый транскрипт (чаще мелкими кусками, чуть ниже "
                   "точность)", "v_livefast")
        toggle_row(c, "Предлагать добавлять частые специфические слова",
                   "v_dictsug")

        c = section("ОБНОВЛЕНИЯ")
        tk.Label(c, bg=SURFACE, fg=MUTED, justify="left",
                 font=("Segoe UI", 9), wraplength=int(560 * self.k),
                 text=("Обновления приходят сами из публичного репозитория "
                       "раздачи — токен для этого НЕ нужен, поле ниже можно "
                       "оставить пустым. Токен (classic, право чтения "
                       "репозитория) нужен, только если вы хотите брать "
                       "версии напрямую со страницы Releases приватного "
                       "репозитория.")).pack(anchor="w", padx=12, pady=(8, 0))
        toggle_row(c, "Проверять обновления при запуске", "v_updcheck")
        toggle_row(c, "Скачивать обновление сразу и предлагать установку",
                   "v_updauto")
        self.v_ghtoken = tk.StringVar()
        ttk.Entry(row(c, "Токен GitHub:"), textvariable=self.v_ghtoken,
                  width=36, show="•").pack(side="right")

        c = section("СИСТЕМА")
        self.THEMES = [("Классическая (как раньше)", "classic"),
                       ("Анимации интерфейса", "animated"),
                       ("Obsidian Pro — чёрный терминал + анимации",
                        "obsidian")]
        self.v_uitheme = tk.StringVar()
        ttk.Combobox(row(c, "Тема интерфейса:"), textvariable=self.v_uitheme,
                     state="readonly", width=34,
                     values=[n for n, _ in self.THEMES]).pack(side="right")
        self.UIMODES = [("Классическое (как раньше)", "classic"),
                        ("Аура — новый интерфейс (экспериментально)", "aura")]
        self.v_uimode = tk.StringVar()
        ttk.Combobox(row(c, "Окно приложения:"), textvariable=self.v_uimode,
                     state="readonly", width=34,
                     values=[n for n, _ in self.UIMODES]).pack(side="right")
        toggle_row(c, "Звуковые сигналы", "v_beeps")
        self.SOUNDS = [("Классические (как раньше)", "classic"),
                       ("Мягкие «тик-так»", "soft"),
                       ("Кристалл", "crystal"),
                       ("Пузырьки", "bubble")]
        self.v_beepstyle = tk.StringVar()
        rs = row(c, "Стиль звуков:")
        ttk.Button(rs, text="▶", width=3,
                   command=self._preview_sound).pack(side="right", padx=(6, 0))
        ttk.Combobox(rs, textvariable=self.v_beepstyle, state="readonly",
                     width=28,
                     values=[n for n, _ in self.SOUNDS]).pack(side="right")
        toggle_row(c, "Восстанавливать буфер обмена после вставки", "v_clip")
        toggle_row(c, "Офлайн-режим (не ходить в интернет за моделью)",
                   "v_offline")
        toggle_row(c, "Вести историю вводов", "v_hist")
        toggle_row(c, "Запускать вместе с Windows (автозагрузка)",
                   "v_autostart")

        if sys.platform == "win32":
            c = section("УСКОРЕНИЕ (INTEL ARC)")
            r = tk.Frame(c, bg=SURFACE)
            r.pack(fill="x", padx=12, pady=8)
            tk.Label(r, bg=SURFACE, fg=MUTED, justify="left",
                     font=("Segoe UI", 9), wraplength=int(560 * self.k),
                     text=("Если в ПК есть видеокарта Intel Arc, модель можно "
                           "перенести на неё — Точная (1.7B) станет в разы "
                           "быстрее. Нужен драйвер Intel 32.0.101.6739+ и "
                           "Resizable BAR в BIOS.")).pack(anchor="w")
            rb = tk.Frame(c, bg=SURFACE)
            rb.pack(fill="x", padx=12, pady=(0, 10))
            ttk.Button(rb, text="Задействовать Intel Arc (XPU)",
                       command=lambda: self._switch_gpu(True)).pack(side="left")
            ttk.Button(rb, text="Вернуть CPU",
                       command=lambda: self._switch_gpu(False)).pack(
                       side="left", padx=6)

        ttk.Label(tab, style="Muted.TLabel", wraplength=560, text=(
            "Всё сохраняется и применяется само, сразу после изменения. "
            "Кнопка ниже нужна только чтобы применить горячие клавиши.")).pack(
            anchor="w", pady=(8, 4))
        btns = ttk.Frame(tab)
        btns.pack(fill="x", pady=(2, 8))
        ttk.Button(btns, text="Сохранить и применить", style="Accent.TButton",
                   command=self._save_settings).pack(side="left")
        ttk.Button(btns, text="Открыть папку приложения",
                   command=self._open_folder).pack(side="right")
        ttk.Button(btns, text="Для антивируса…",
                   command=self._antivirus_info).pack(side="right", padx=6)
        ttk.Button(btns, text="Открыть config.json",
                   command=self._open_config).pack(side="right", padx=6)

    def _build_log_tab(self, tab):
        ttk.Label(tab, style="Muted.TLabel", text=(
            f"Panda Voice {appconfig.version()} — журнал приложения "
            "(app.log), обновляется автоматически")).pack(anchor="w")
        # state="normal" (не disabled!): disabled-виджет НЕ принимает фокус
        # клавиатуры, поэтому Ctrl+C на нём не работал. Делаем «только чтение»:
        # ввод/удаление блокируем, но выделение и копирование остаются.
        self.log_text = tk.Text(tab, wrap="word", height=14,
                                font=("Consolas", 9), exportselection=True)
        self._dark_text(self.log_text)
        self.log_text.pack(fill="both", expand=True, pady=(4, 0))
        self.log_text.bind("<Key>", self._log_key)
        self.log_text.bind("<Control-c>", self._copy_log_sel)
        self.log_text.bind("<Control-C>", self._copy_log_sel)
        self.log_text.bind("<Control-Insert>", self._copy_log_sel)
        self.log_text.bind("<Control-a>", self._log_select_all)
        self.log_text.bind("<Control-A>", self._log_select_all)
        self.log_text.bind("<Button-1>", lambda e: self.log_text.focus_set())
        self._log_menu = tk.Menu(self.log_text, tearoff=0, bg=SURFACE,
                                 fg=TEXT, activebackground=SELECT,
                                 activeforeground=TEXT, borderwidth=0)
        self._log_menu.add_command(label="Копировать выделенное",
                                   command=self._copy_log_sel)
        self._log_menu.add_command(label="Скопировать весь журнал",
                                   command=self._copy_log)
        self.log_text.bind("<Button-3>", self._log_context_menu)
        btns = ttk.Frame(tab)
        btns.pack(fill="x", pady=(6, 0))
        ttk.Button(btns, text="Открыть app.log",
                   command=self._open_log).pack(side="left")
        ttk.Button(btns, text="Скопировать журнал",
                   command=self._copy_log).pack(side="left", padx=6)
        ttk.Button(btns, text="Селфтест",
                   command=self._run_selftest).pack(side="left", padx=6)
        self._log_mtime = 0.0
        self._log_tick = 0

    def _log_key(self, e):
        """Только чтение: разрешаем копирование/выделение/навигацию,
        блокируем ввод и удаление текста."""
        if bool(e.state & 0x4) and e.keysym.lower() in ("c", "a", "insert"):
            return  # Ctrl+C / Ctrl+A / Ctrl+Insert
        if e.keysym in ("Left", "Right", "Up", "Down", "Home", "End", "Prior",
                        "Next", "Shift_L", "Shift_R", "Control_L", "Control_R",
                        "Escape"):
            return
        return "break"

    def _log_select_all(self, _e=None):
        self.log_text.tag_add("sel", "1.0", "end-1c")
        return "break"

    def _copy_log_sel(self, _e=None):
        try:
            sel = self.log_text.get("sel.first", "sel.last")
        except tk.TclError:
            sel = ""
        if sel:
            try:
                import pyperclip
                pyperclip.copy(sel)
            except Exception:
                self.root.clipboard_clear()
                self.root.clipboard_append(sel)
        return "break"

    def _log_context_menu(self, event):
        try:
            self._log_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self._log_menu.grab_release()

    def _refresh_log(self):
        # не затирать текст, пока пользователь выделяет его для копирования
        if self.log_text.tag_ranges("sel"):
            return
        path = appconfig.APP_DIR / "app.log"
        try:
            mtime = path.stat().st_mtime
        except OSError:
            return
        if mtime == self._log_mtime:
            return
        self._log_mtime = mtime
        try:
            with open(path, "rb") as f:
                f.seek(max(0, path.stat().st_size - 20000))
                tail = f.read().decode("utf-8", errors="replace")
            lines = tail.splitlines()[-200:]
            at_bottom = self.log_text.yview()[1] > 0.99  # не дёргать прокрутку
            self.log_text.delete("1.0", "end")
            self.log_text.insert("1.0", "\n".join(lines))
            if at_bottom:
                self.log_text.see("end")
        except Exception:
            log.exception("Не удалось прочитать app.log")

    def _open_log(self):
        try:
            os.startfile(appconfig.APP_DIR / "app.log")  # noqa — Windows-only
        except Exception:
            log.exception("Не удалось открыть app.log")

    def _copy_log(self):
        try:
            import pyperclip
            pyperclip.copy(self.log_text.get("1.0", "end"))
        except Exception:
            log.exception("Не удалось скопировать журнал")

    def _run_selftest(self):
        messagebox.showinfo("Panda Voice", "Селфтест запущен в фоне: он заново "
                            "загружает модель и распознаёт тестовый файл "
                            "(1-3 минуты). Результат появится в отдельном окне.")

        def run():
            import subprocess
            py = sys.executable
            if sys.platform == "win32":
                py = str(Path(py).with_name("python.exe"))
            try:
                out = subprocess.run(
                    [py, str(appconfig.APP_DIR / "main.py"), "--selftest"],
                    capture_output=True, text=True, timeout=600,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                tail = "\n".join((out.stdout or "").splitlines()[-6:])
                ok = out.returncode == 0
                fn = messagebox.showinfo if ok else messagebox.showwarning
                self.call(fn, "Panda Voice — селфтест",
                          tail or "Пустой вывод — смотрите app.log")
            except Exception as e:
                self.call(messagebox.showwarning, "Panda Voice",
                          f"Селфтест не удался: {e}")

        threading.Thread(target=run, daemon=True).start()

    def _run_update(self):
        def run():
            try:
                import importlib
                import updater
                importlib.reload(updater)  # вдруг updater сам был обновлён
                # cfg — чтобы кнопка умела не только ставить архив из
                # «Загрузок», но и СКАЧАТЬ новую версию из репозитория раздачи
                status, msg = updater.run(cfg=self.app.cfg)
            except Exception as e:
                self.call(messagebox.showwarning, "Panda Voice",
                          f"Обновление не удалось: {e}")
                return
            if status == "updated":  # полный цикл: обновились и перезапускаемся
                self.call(self._finish_update, msg)
            else:
                fn = (messagebox.showinfo if status == "none"
                      else messagebox.showwarning)
                self.call(fn, "Panda Voice — обновление", msg)

        threading.Thread(target=run, daemon=True).start()

    def ask_install_update(self, tag, notes=""):
        """Обновление уже скачано в фоне — спрашиваем согласие и ставим.
        Пользователя не трогаем молча: обновление применяется только по «Да»."""
        text = (f"Вышла новая версия {tag}, она уже скачана.\n\n"
                "Установить сейчас? Приложение перезапустится "
                "(ваши настройки, история и словари сохранятся).")
        if notes:
            text += f"\n\nЧто нового:\n{notes[:500]}"
        try:
            self.root.deiconify()
            self.root.lift()
        except Exception:
            pass
        if messagebox.askyesno("Panda Voice — обновление", text):
            self._run_update()
        else:  # отложили — не спрашивать про эту же версию каждые 6 часов
            self.app._declined_update = tag
            log.info("Установка %s отложена пользователем", tag)

    def _finish_update(self, msg):
        messagebox.showinfo("Panda Voice — обновление",
                            msg + "\n\nСейчас приложение перезапустится само.")
        self.app.restart()

    # --- статус и кнопки ---

    def _refresh_status(self):
        if self.root.state() not in ("normal", "zoomed"):  # zoomed = развёрнуто
            return
        st = self.app.current_state()
        self.status_var.set(STATE_RU.get(st, st))
        dot = STATE_DOT.get(st, MUTED)
        if theme.animated() and st in ("recording", "processing"):
            # «дыхание» статусной точки в такт _poll (150 мс)
            ph = abs(self._log_tick % 10 - 5) / 5
            dot = theme.lerp_hex(dot, BG, 0.6 * ph)
        self.status_dot.configure(foreground=dot)
        self.pause_btn_var.set("Возобновить" if st == "paused" else "Пауза")

    def _toggle_pause(self):
        try:
            self.app.toggle_pause()
        except Exception:
            log.exception("Пауза из GUI не удалась")

    def _mic_test(self):
        threading.Thread(target=self.app.mic_test, daemon=True).start()

    def _open_config(self):
        try:
            os.startfile(appconfig.CONFIG_PATH)  # noqa — Windows-only
        except Exception:
            log.exception("Не удалось открыть config.json")

    def _open_folder(self):
        try:
            os.startfile(appconfig.APP_DIR)  # noqa — Windows-only
        except Exception:
            log.exception("Не удалось открыть папку приложения")

    def _antivirus_info(self):
        """Путь исполняемого файла — его и добавляют в доверенные.

        Антивирусы (Kaspersky и др.) запоминают разрешение для конкретного
        exe, а не для папки, поэтому «папка в разрешённых» не помогает."""
        try:
            import setup_wizard
            exe = setup_wizard.ensure_launcher() or Path(sys.executable)
        except Exception:
            exe = Path(sys.executable)
        text = (
            "Антивирус разрешает доступ (микрофон, сеть) КОНКРЕТНОЙ "
            "программе, а не папке — поэтому «папка в разрешённых» не "
            "избавляет от вопросов.\n\n"
            "Добавьте в доверенные именно этот файл:\n\n"
            f"{exe}\n\n"
            "Kaspersky: Настройки → Защита → Управление программами → "
            "найдите Panda Voice (или добавьте файл выше) → Правила → "
            "«Доверенные», и снимите ограничения на доступ к микрофону.\n\n"
            "Путь скопирован в буфер обмена.")
        try:
            import pyperclip
            pyperclip.copy(str(exe))
        except Exception:
            self.root.clipboard_clear()
            self.root.clipboard_append(str(exe))
        messagebox.showinfo("Panda Voice — доступ для антивируса", text)

    def _switch_gpu(self, to_xpu):
        what = "Intel Arc (XPU)" if to_xpu else "CPU"
        if not messagebox.askyesno("Panda Voice", (
                f"Переключить распознавание на {what}?\n\nБудет заменена "
                "сборка torch (загрузка несколько сотен МБ). По завершении "
                "приложение перезапустится. Продолжить?")):
            return
        messagebox.showinfo("Panda Voice", (
            "Переключение запущено в фоне — это займёт несколько минут "
            "(прогресс во вкладке «Журнал»). Дождитесь окна с результатом; "
            "приложением пока можно пользоваться."))

        def run():
            try:
                import gpu_switch
                ok, msg = gpu_switch.switch(to_xpu)
            except Exception as e:
                self.call(messagebox.showwarning, "Panda Voice",
                          f"Переключение не удалось: {e}")
                return
            if ok:
                self.call(self._finish_update, msg)  # покажет и перезапустит
            else:
                self.call(messagebox.showwarning, "Panda Voice — ускорение", msg)

        threading.Thread(target=run, daemon=True).start()

    # --- история ---

    def _reload_history(self):
        for iid in self.tree.get_children():
            self.tree.delete(iid)
        self._entries = history.read_last(300)
        for n, idx in enumerate(range(len(self._entries) - 1, -1, -1)):
            e = self._entries[idx]  # новые сверху
            preview = (e.get("text") or "").replace("\n", " ")
            if len(preview) > 120:
                preview = preview[:120] + "…"
            self.tree.insert("", "end", iid=str(idx),
                             tags=("odd",) if n % 2 else (),
                             values=(e.get("ts", ""), e.get("audio_sec", ""),
                                     preview))

    def _selected_text(self):
        sel = self.tree.selection()
        if not sel:
            return None
        try:
            return self._entries[int(sel[0])].get("text") or ""
        except (ValueError, IndexError):
            return None

    def _on_select_entry(self, _event):
        text = self._selected_text()
        self.full_text.configure(state="normal")
        self.full_text.delete("1.0", "end")
        if text:
            self.full_text.insert("1.0", text)
        self.full_text.configure(state="disabled")

    def _copy_selected(self):
        text = self._selected_text()
        if not text:
            messagebox.showinfo("Panda Voice", "Выберите запись в списке.")
            return
        try:
            import pyperclip  # Tk-буфер очищается при выходе Tk — pyperclip надёжнее
            pyperclip.copy(text)
        except Exception:
            log.exception("Копирование не удалось")
            self.root.clipboard_clear()
            self.root.clipboard_append(text)

    def _clear_history(self):
        if messagebox.askyesno("Panda Voice", "Удалить всю историю вводов?"):
            history.clear()
            self._reload_history()

    def _clear_corrections(self):
        if messagebox.askyesno("Panda Voice",
                               "Сбросить весь словарь выученных замен слов?\n"
                               "Это уберёт накопившиеся ошибочные замены; "
                               "полезные придётся выучить заново."):
            import corrections
            corrections.clear()
            messagebox.showinfo("Panda Voice", "Словарь замен очищен.")

    def _selected_index(self):
        sel = self.tree.selection()
        if not sel:
            return None
        try:
            return int(sel[0])
        except ValueError:
            return None

    def _edit_entry(self):
        idx = self._selected_index()
        if idx is None or idx >= len(self._entries):
            messagebox.showinfo("Panda Voice", "Выберите запись в списке.")
            return
        entry = self._entries[idx]
        old = entry.get("text") or ""

        win = tk.Toplevel(self.root)
        win.title("Исправление текста")
        win.geometry("560x320")
        win.transient(self.root)
        win.configure(bg=BG)
        dark_titlebar(win)
        theme.fade_in(win)
        ttk.Label(win, padding=(10, 8), text=(
            "Исправьте текст так, как вы говорили. Изменённые слова приложение "
            "запомнит и будет подставлять автоматически.")).pack(anchor="w")
        txt = tk.Text(win, wrap="word", height=10)
        self._dark_text(txt)
        txt.pack(fill="both", expand=True, padx=10)
        txt.insert("1.0", old)
        txt.focus_set()

        def save():
            new = txt.get("1.0", "end").strip()
            win.destroy()
            if not new or new == old:
                return
            try:
                import corrections
                pairs = corrections.learn(old, new)
            except Exception:
                log.exception("Не удалось выучить исправления")
                pairs = {}
            entry["text"] = new
            history.save_all(self._entries)
            self._reload_history()
            if pairs:
                lst = ", ".join(f"«{k}»→«{v}»" for k, v in pairs.items())
                messagebox.showinfo("Panda Voice",
                                    f"Запомнено замен: {len(pairs)}\n{lst}")
            else:
                messagebox.showinfo("Panda Voice", "Текст записи обновлён.")

        bar = ttk.Frame(win, padding=10)
        bar.pack(fill="x")
        ttk.Button(bar, text="Сохранить и запомнить", style="Accent.TButton",
                   command=save).pack(side="right")
        ttk.Button(bar, text="Отмена", command=win.destroy).pack(side="right",
                                                                 padx=6)

    def correct_last_dialog(self):
        """F7: исправить только что вставленный текст — выучить замены и
        заменить текст прямо в целевом окне (каретка ещё за вставкой)."""
        old = self.app._last_text
        if not old:
            return
        win = tk.Toplevel(self.root)
        win.title("Исправить вставленный текст")
        win.configure(bg=BG)
        win.attributes("-topmost", True)
        dark_titlebar(win)
        theme.fade_in(win)
        ttk.Label(win, padding=(10, 8), text=(
            "Исправьте текст: приложение запомнит замены слов, а текст "
            "в окне,\nкуда он был вставлен, будет заменён на исправленный.")
            ).pack(anchor="w")
        txt = tk.Text(win, wrap="word", height=8, width=64)
        self._dark_text(txt)
        txt.pack(fill="both", expand=True, padx=10)
        txt.insert("1.0", old)
        txt.focus_set()

        hwnd = (getattr(self.app, "_correct_hwnd", None)
                or getattr(self.app, "_target_hwnd", None))

        def go(_e=None):
            new = txt.get("1.0", "end").strip()
            if not (new and new != old):
                win.destroy()
                return
            # КЛЮЧЕВОЕ: пока диалог в фокусе, НАШ процесс владеет foreground —
            # только сейчас Windows honors SetForegroundWindow к чужому окну
            # (Chrome). Отдаём фокус цели и отправляем замену СИНХРОННО, до
            # destroy — иначе главное окно приложения перехватит фокус и
            # Ctrl+V уйдёт не в поле (в логе было «ok=False», текст не менялся).
            if hwnd and sys.platform == "win32":
                try:
                    import ctypes
                    ctypes.windll.user32.AllowSetForegroundWindow(-1)
                    ctypes.windll.user32.SetForegroundWindow(hwnd)
                except Exception:
                    pass
            try:
                self.app.replace_last_sync(new, hwnd)
            except Exception:
                log.exception("Замена текста не удалась")
            win.destroy()

        bar = ttk.Frame(win, padding=10)
        bar.pack(fill="x")
        ttk.Button(bar, text="Заменить и запомнить", style="Accent.TButton",
                   command=go).pack(side="right")
        ttk.Button(bar, text="Отмена",
                   command=win.destroy).pack(side="right", padx=6)
        win.bind("<Control-Return>", go)
        # позиция: над виджетом записи, на мониторе окна, куда шла диктовка
        # (на мультимониторе окно иначе всплывает не на том экране)
        try:
            from overlay import _active_monitor_rect
            rect = _active_monitor_rect(hwnd)
            win.update_idletasks()
            w, h = win.winfo_reqwidth(), win.winfo_reqheight()
            if rect:
                left, top, right, bottom = rect
                x = left + (right - left - w) // 2
                y = max(top, bottom - h - int(90 * self.k))
                win.geometry(f"+{x}+{y}")
        except Exception:
            log.exception("Не удалось спозиционировать окно исправления")
        win.lift()
        try:
            win.focus_force()
        except Exception:
            pass

    # --- настройки ---

    def _device_choices(self):
        out = ["По умолчанию"]
        try:
            import sounddevice as sd
            for i, d in enumerate(sd.query_devices()):
                if d["max_input_channels"] > 0:
                    out.append(f"{i}: {d['name']}")
        except Exception:
            log.exception("Не удалось получить список микрофонов")
        return out

    def _load_settings(self):
        cfg = self.app.cfg
        self.v_hotkey.set(cfg.get("hotkey", "alt"))
        self.v_repaste.set(cfg.get("repaste_key", "right alt"))
        self.v_correct.set(cfg.get("correct_key", "f7"))
        self.v_openwin.set(cfg.get("open_window_key", "left alt+p"))
        self.v_mode.set(cfg.get("mode", "toggle"))
        self.v_ptt.set(cfg.get("push_to_talk_key", "f8"))
        self.v_interval.set(str(cfg.get("double_press_interval_ms", 400)))
        self.v_maxrec.set(str(cfg.get("max_recording_sec", 600)))
        dev = cfg.get("input_device")
        choice = "По умолчанию"
        if dev is not None:
            for val in self.device_box["values"]:
                if val.split(":")[0].strip() == str(dev):
                    choice = val
                    break
        self.v_device.set(choice)
        mid = cfg.get("model_id", self.MODELS[0][1])
        mname = next((n for n, m in self.MODELS if m == mid), None)
        if mname is None:  # нестандартная модель из config.json — показываем как есть
            mname = mid
        self.v_model.set(mname)
        code = str(cfg.get("language") or "auto").lower()
        name = next((n for n, c in self.LANGS if c == code), self.LANGS[0][0])
        self.v_lang.set(name)
        self.v_multi.set(bool(cfg.get("multilingual_mode", True)))
        self.v_asrctx.set(str(cfg.get("asr_context") or ""))
        self.v_beams.set(int(cfg.get("num_beams", 1) or 1) > 1)
        self.v_repass.set(bool(cfg.get("final_repass", False)))
        self.v_live.set(bool(cfg.get("live_transcript", False)))
        self.v_livefast.set(bool(cfg.get("live_fast", False)))
        self.v_dictsug.set(bool(cfg.get("dict_suggestions", False)))
        self.v_updcheck.set(bool(cfg.get("update_check", True)))
        self.v_updauto.set(bool(cfg.get("auto_download_updates", True)))
        self.v_ghtoken.set(str(cfg.get("github_token") or ""))
        tcode = str(cfg.get("ui_theme", "classic")).lower()
        self.v_uitheme.set(next((n for n, c_ in self.THEMES if c_ == tcode),
                                self.THEMES[0][0]))
        ucode = str(cfg.get("ui_mode", "classic")).lower()
        self.v_uimode.set(next((n for n, c_ in self.UIMODES if c_ == ucode),
                               self.UIMODES[0][0]))
        self.v_beeps.set(bool(cfg.get("beeps", True)))
        bcode = str(cfg.get("beep_style", "classic")).lower()
        self.v_beepstyle.set(next((n for n, c_ in self.SOUNDS if c_ == bcode),
                                  self.SOUNDS[0][0]))
        self.v_clip.set(bool(cfg.get("restore_clipboard", True)))
        self.v_offline.set(bool(cfg.get("offline_mode", True)))
        self.v_hist.set(bool(cfg.get("history_enabled", True)))
        try:
            import setup_wizard
            self.v_autostart.set(setup_wizard.autostart_enabled())
        except Exception:
            self.v_autostart.set(False)

    def _preview_sound(self):
        """▶ рядом со «Стилем звуков»: прослушать выбранный стиль."""
        code = next((c_ for n, c_ in self.SOUNDS
                     if n == self.v_beepstyle.get()), "classic")
        import sounds
        threading.Thread(target=sounds.preview, args=(code,),
                         daemon=True).start()

    # --- автоприменение: изменил — сохранилось само, без кнопки ---

    def _install_autosave(self):
        """Тумблеры/списки/числа применяются сами (дебаунс 0.7 с). Хоткеи —
        по-прежнему кнопкой: их поля меняются при каждом нажатии клавиш,
        применять на лету нельзя."""
        self._autosave_job = None
        auto = (self.v_mode, self.v_interval, self.v_maxrec, self.v_device,
                self.v_model, self.v_lang, self.v_multi, self.v_asrctx,
                self.v_beams, self.v_repass, self.v_live,
                self.v_livefast, self.v_dictsug, self.v_updcheck,
                self.v_updauto, self.v_ghtoken, self.v_uitheme,
                self.v_uimode, self.v_beeps, self.v_beepstyle, self.v_clip,
                self.v_offline, self.v_hist, self.v_autostart)
        for var in auto:
            var.trace_add("write", lambda *a: self._schedule_autosave())

    def _schedule_autosave(self):
        if self._autosave_job:
            try:
                self.root.after_cancel(self._autosave_job)
            except Exception:
                pass
        self._autosave_job = self.root.after(700, self._autosave)

    def _autosave(self):
        self._autosave_job = None
        try:
            self._save_settings(silent=True)
        except Exception:
            log.exception("Автосохранение настроек не удалось")

    def _save_settings(self, silent=False):
        if silent:  # хоткеи не трогаем: их поля могли быть в процессе набора
            c0 = self.app.cfg
            hotkey = str(c0.get("hotkey", "left alt+`"))
            ptt = str(c0.get("push_to_talk_key", "f8"))
            repaste = str(c0.get("repaste_key", ""))
            correct = str(c0.get("correct_key", ""))
            openwin = str(c0.get("open_window_key", ""))
        else:
            hotkey = self.v_hotkey.get().strip().lower()
            ptt = self.v_ptt.get().strip().lower()
            repaste = self.v_repaste.get().strip().lower()
            correct = self.v_correct.get().strip().lower()
            openwin = self.v_openwin.get().strip().lower()
        if not hotkey or not ptt:
            if not silent:
                messagebox.showerror("Panda Voice",
                                     "Клавиши не могут быть пустыми.")
            return
        try:
            interval = max(150, min(2000, int(self.v_interval.get())))
            maxrec = max(10, min(3600, int(self.v_maxrec.get())))
        except ValueError:
            if not silent:  # автоприменение молчит, пока число не донабрано
                messagebox.showerror("Panda Voice",
                                     "Интервалы должны быть числами.")
            return
        dev = self.v_device.get()
        device = None
        if dev and not dev.startswith("По умолчанию"):
            try:
                device = int(dev.split(":")[0])
            except ValueError:
                device = None
        lang = next((c for n, c in self.LANGS if n == self.v_lang.get()), "auto")
        model_id = next((m for n, m in self.MODELS if n == self.v_model.get()),
                        self.v_model.get() or self.app.cfg.get("model_id"))
        model_changed = model_id != self.app.cfg.get("model_id")
        old_theme = str(self.app.cfg.get("ui_theme", "classic")).lower()
        new_theme = next((c_ for n, c_ in self.THEMES
                          if n == self.v_uitheme.get()), "classic")
        old_mode = str(self.app.cfg.get("ui_mode", "classic")).lower()
        new_mode = next((c_ for n, c_ in self.UIMODES
                         if n == self.v_uimode.get()), "classic")
        # стиль Obsidian и режим окна применяются при старте — нужен рестарт
        restyle = (new_theme != old_theme
                   and "obsidian" in (new_theme, old_theme)) \
            or new_mode != old_mode
        new_cfg = {
            "model_id": model_id,
            "hotkey": hotkey,
            "mode": self.v_mode.get() or "toggle",
            "push_to_talk_key": ptt,
            "repaste_key": repaste,
            "correct_key": correct,
            "open_window_key": openwin,
            "double_press_interval_ms": interval,
            "max_recording_sec": maxrec,
            "input_device": device,
            "language": lang,
            "multilingual_mode": self.v_multi.get(),
            "asr_context": self.v_asrctx.get().strip(),
            "num_beams": 3 if self.v_beams.get() else 1,
            "final_repass": self.v_repass.get(),
            "live_transcript": self.v_live.get(),
            "live_fast": self.v_livefast.get(),
            "dict_suggestions": self.v_dictsug.get(),
            "update_check": self.v_updcheck.get(),
            "auto_download_updates": self.v_updauto.get(),
            "github_token": self.v_ghtoken.get().strip(),
            "ui_theme": new_theme,
            "ui_mode": new_mode,
            "beeps": self.v_beeps.get(),
            "beep_style": next((c_ for n, c_ in self.SOUNDS
                                if n == self.v_beepstyle.get()), "classic"),
            "restore_clipboard": self.v_clip.get(),
            "offline_mode": self.v_offline.get(),
            "history_enabled": self.v_hist.get(),
        }
        try:
            self.app.apply_config(new_cfg)
        except Exception:
            log.exception("Не удалось применить настройки")
            if not silent:
                messagebox.showerror(
                    "Panda Voice",
                    "Не удалось применить настройки — см. app.log")
            return
        want_autostart = self.v_autostart.get()

        def apply_autostart():  # powershell стартует секунды — не морозим окно
            try:
                import setup_wizard
                if want_autostart != setup_wizard.autostart_enabled():
                    if want_autostart:
                        setup_wizard.enable_autostart()
                    else:
                        setup_wizard.disable_autostart()
            except Exception:
                log.exception("Не удалось изменить автозагрузку")
                self.call(messagebox.showwarning, "Panda Voice",
                          "Автозагрузку изменить не удалось — см. app.log")

        threading.Thread(target=apply_autostart, daemon=True).start()
        if model_changed:
            messagebox.showinfo(
                "Panda Voice",
                "Модель изменена — сейчас приложение перезапустится с ней. "
                "Если модель ещё не скачана, она докачается автоматически "
                "(прогресс — во вкладке «Журнал»).")
            self.app.restart()
        elif restyle:
            if messagebox.askyesno("Panda Voice", (
                    "Сохранено. Тема оформления применится после "
                    "перезапуска.\n\nПерезапустить сейчас?")):
                self.app.restart()
        elif not silent:
            messagebox.showinfo("Panda Voice", "Сохранено и применено.")
