"""Panda Voice — локальная голосовая диктовка (Windows 11 / Linux, Qwen3-ASR).

Запуск:
    python main.py            — обычный запуск (иконка в трее)
    python main.py --setup    — мастер первого запуска
    python main.py --selftest — проверка: загрузка модели + тестовый wav
"""
import argparse
import logging
import logging.handlers
import os
import socket
import sys
import threading
import time
import wave
from pathlib import Path

import numpy as np

APP_DIR = Path(__file__).resolve().parent
os.chdir(APP_DIR)
# кэш HF живёт рядом с приложением — установка самодостаточна
os.environ.setdefault("HF_HOME", str(APP_DIR / "hf-cache"))

import appconfig
import history
import sounds

log = logging.getLogger("main")
SR = 16000
LAST_WAV = APP_DIR / "last_recording.wav"
__version__ = appconfig.version()


def enable_dpi_awareness():
    """Чёткая отрисовка на HiDPI-экранах (иначе Windows растягивает окно
    в мыло). Звать ДО создания любых окон. Проверяем КОД ВОЗВРАТА:
    неудачный вызов не бросает исключение, а тихо возвращает 0."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ok = False
        try:  # Per-Monitor V2 (Windows 10 1703+)
            ok = bool(ctypes.windll.user32.SetProcessDpiAwarenessContext(
                ctypes.c_void_p(-4)))
        except Exception:
            pass
        if not ok:
            try:
                ok = ctypes.windll.shcore.SetProcessDpiAwareness(2) == 0
            except Exception:
                pass
        if not ok:
            try:
                ok = bool(ctypes.windll.user32.SetProcessDPIAware())
            except Exception:
                pass
        try:
            aw = ctypes.windll.user32.GetAwarenessFromDpiAwarenessContext(
                ctypes.windll.user32.GetThreadDpiAwarenessContext())
            log.info("DPI-awareness: установлен=%s, уровень=%s", ok, aw)
        except Exception:
            log.info("DPI-awareness: установлен=%s", ok)
    except Exception:
        log.warning("Не удалось включить DPI-awareness", exc_info=True)


def raise_priority(cfg):
    """ABOVE_NORMAL-приоритет процесса (Windows): распознавание — интерактивная
    задача и не должно ждать в очереди за браузерами/фоновыми программами.
    На загруженной машине это заметно сокращает время после остановки."""
    if sys.platform != "win32" or not cfg.get("high_priority", True):
        return
    try:
        import ctypes
        from ctypes import wintypes
        k = ctypes.windll.kernel32
        # ВАЖНО: без argtypes/restype 64-битный HANDLE обрезается до int и
        # SetPriorityClass молча возвращает 0 (в логе было ok=False)
        k.GetCurrentProcess.restype = wintypes.HANDLE
        k.SetPriorityClass.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        ok = k.SetPriorityClass(k.GetCurrentProcess(), 0x00008000)
        log.info("Приоритет процесса ABOVE_NORMAL: ok=%s", bool(ok))
    except Exception:
        log.warning("Не удалось поднять приоритет процесса", exc_info=True)


def setup_logging():
    handlers = [logging.handlers.RotatingFileHandler(
        APP_DIR / "app.log", maxBytes=1_000_000, backupCount=2, encoding="utf-8")]
    if sys.stderr is not None:  # под pythonw консоли нет
        handlers.append(logging.StreamHandler())
    logging.basicConfig(level=logging.INFO, handlers=handlers,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    sys.excepthook = lambda *a: log.critical("Необработанная ошибка", exc_info=a)


_GUARD = None  # сокет одиночного запуска; restart() освобождает его


def single_instance_guard():
    global _GUARD
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", 48915))
        _GUARD = s  # держим сокет всю жизнь процесса
        return s
    except OSError:
        log.error("Приложение уже запущено — выходим (эта копия: %s)", APP_DIR)
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                0, "Panda Voice уже запущена (иконка в трее).\n\n"
                   "Если в трее висит СТАРАЯ версия — закройте её через "
                   "«Выход» в меню трея и запустите эту снова.\n\n"
                   f"Папка этой копии:\n{APP_DIR}",
                "Panda Voice", 0x40)
        except Exception:
            pass
        sys.exit(1)


def read_wav(path):
    """wav → float32 mono 16 kHz (для selftest)."""
    with wave.open(str(path), "rb") as w:
        if w.getsampwidth() != 2:
            raise ValueError("нужен 16-bit PCM wav")
        data = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2")
        data = data.astype(np.float32) / 32768.0
        if w.getnchannels() > 1:
            data = data.reshape(-1, w.getnchannels()).mean(axis=1)
        if w.getframerate() != SR:
            n = int(len(data) * SR / w.getframerate())
            data = np.interp(np.linspace(0, len(data) - 1, n),
                             np.arange(len(data)), data).astype(np.float32)
        return data


class App:
    def __init__(self, cfg):
        self.cfg = cfg
        self.transcriber = None
        self.recorder = None
        self.fsm = None
        self.listener = None
        self.tray = None
        self.gui = None
        self._busy = threading.Lock()
        self._processing = False
        self._limit_timer = None
        self._partials = []       # тексты фрагментов, распознанных во время записи
        self._partial_at_pause = []  # каждый фрагмент отрезан по паузе речи?
        self._session_parts = []  # аудио сессии для «идеального финала» (опц.)
        self._stream_thread = None
        self._last_text = ""      # последний распознанный текст (для повтора вставки)
        self._target_hwnd = None  # окно, куда диктуют (для точной вставки)
        self._correct_hwnd = None  # окно, где правим текст (захват в момент F8)
        self._pending_update = None  # (тег, манифест, путь) — скачанное обновление
        self._declined_update = None  # версия, установку которой отложили
        sounds.enabled = bool(cfg.get("beeps", True))
        sounds.style = str(cfg.get("beep_style", "classic"))

    def run(self):
        from trayicon import Tray
        self.tray = Tray(
            on_open=lambda *_: self.show_window(),
            on_toggle_pause=lambda *_: self.toggle_pause(),
            on_mic_test=lambda *_: threading.Thread(
                target=self.mic_test, daemon=True).start(),
            on_update=lambda *_: self.update_from_tray(),
            on_restart=lambda *_: self.restart(),
            on_quit=lambda *_: self.quit(),
            is_paused=lambda: bool(self.fsm and self.fsm.state == "paused"),
        )
        if str(self.cfg.get("ui_mode", "classic")).lower() == "aura":
            try:  # опциональный веб-интерфейс; неудача = обычный запуск
                import aura
                if aura.run(self):  # блокирует главный поток до выхода
                    return
            except Exception:
                log.exception("Аура не запустилась — классический интерфейс")
        self.gui = None
        try:
            from gui import Gui
            self.gui = Gui(self)
        except Exception:  # нет tkinter — работаем только из трея
            log.exception("GUI недоступен — продолжаю без окна")

        def setup(icon):
            # кастомный setup ОБЯЗАН сам показать иконку (контракт pystray)
            icon.visible = True
            threading.Thread(target=self._init, daemon=True).start()

        if self.gui:
            self.tray.run_detached(setup=setup)
            self.gui.mainloop()  # главный поток занят окном
        else:
            self.tray.run(setup=setup)

    def show_window(self):
        w = getattr(self, "_aura_win", None)
        if w is not None:
            try:
                w.show()
                return
            except Exception:
                log.exception("Не удалось показать окно ауры")
        if self.gui:
            self.gui.call(self.gui.show)

    def update_from_tray(self):
        """«Обновление» из меню трея: открыть окно и запустить тот же цикл,
        что кнопка «Обновление» в шапке (установка из «Загрузок» + рестарт)."""
        if self.gui:
            self.gui.call(self.gui.show)
            self.gui.call(self.gui._run_update)
        else:
            threading.Thread(target=self._headless_update, daemon=True).start()

    def _headless_update(self):
        try:
            import updater
            status, msg = updater.run(cfg=self.cfg)
            self.tray.notify(msg)
            if status == "updated":
                self.restart()
        except Exception:
            log.exception("Обновление из трея не удалось")
            self.tray.notify("Обновление не удалось — см. app.log")

    def _update_watch(self):
        """Проверять обновления при запуске и дальше периодически.

        Приложение живёт в трее сутками: проверки только на старте мало —
        вышедшую версию пользователь не увидит, пока не перезапустит."""
        self._check_updates()
        hours = float(self.cfg.get("update_check_hours", 6) or 0)
        while hours > 0:
            time.sleep(hours * 3600)
            if not self.cfg.get("update_check", True):
                continue
            if (self.recorder and self.recorder.recording) or self._processing:
                continue  # не мешаем диктовке — спросим в следующий раз
            self._check_updates()

    def _check_updates(self):
        """Автопроверка обновлений при старте: сперва «Загрузки», потом GitHub."""
        try:
            import updater
            cur = updater.current_version()
            found = updater.find_update()
            if found and cur and found[0] > cur:
                # архив уже лежит в «Загрузках» (скачан ранее или вручную) —
                # сразу предлагаем установку, а не просим искать кнопку
                tag = "v" + ".".join(map(str, found[0]))
                log.info("В «Загрузках» найдено обновление: %s", found[1].name)
                self._gui("ask_install_update", tag, "")
                return
            res = updater.check_remote(self.cfg)
            cur_s = "v" + ".".join(map(str, cur)) if cur else "?"
            if not res:
                # пишем в журнал ВСЕГДА: иначе по логу не понять, прошла ли
                # проверка вообще («не предлагает обновиться» — почему?)
                log.info("Проверка обновлений: установлена %s, новее нет "
                         "(канал %s)", cur_s,
                         self.cfg.get("update_repo", "по умолчанию"))
                return
            tag, info = res
            if tag == self._declined_update:
                log.info("Версия %s доступна, но вы отложили её установку", tag)
                return
            log.info("Доступна новая версия %s (установлена %s)", tag, cur_s)
            if not self.cfg.get("auto_download_updates", True):
                self.tray.notify(
                    f"Вышла новая версия {tag}! Нажмите «Обновление» в окне "
                    "приложения, чтобы скачать и установить её.")
                return
            self.tray.notify(f"Вышла версия {tag} — скачиваю обновление...")
            path = updater.download_update(info)
            self._pending_update = (tag, info, path)
            log.info("Обновление %s скачано — предлагаю установить", tag)
            notes = (info.get("notes") or "").strip()
            self._gui("ask_install_update", tag, notes)
        except Exception as e:
            log.info("Автопроверка обновлений недоступна: %s", e)

    def _gui(self, method, *args):
        """Позвать метод GUI из любого потока (через его очередь)."""
        if self.gui:
            self.gui.call(getattr(self.gui, method), *args)

    def _make_listener(self):
        if sys.platform == "win32":
            from win_hotkeys import HotkeyListener
        else:
            from linux_hotkeys import HotkeyListener
        kw = {}
        if sys.platform == "win32":  # linux-слушатель этих действий не умеет
            kw = {"on_correct": self.correct_last, "on_open": self.show_window}
        return HotkeyListener(
            self.fsm, self.cfg,
            on_start=self.start_recording,
            on_stop=self.stop_and_recognize,
            on_repaste=self.repaste_last,
            is_recording=lambda: bool(self.recorder and self.recorder.recording),
            **kw)

    def repaste_last(self):
        """Правый Alt: вставить последний распознанный текст в активное окно
        ещё раз (пригодится, если в момент диктовки было не то окно)."""
        text = self._last_text
        if not text:
            try:
                entries = history.read_last(1)
                text = entries[-1]["text"] if entries else ""
            except Exception:
                text = ""
        if not text:
            sounds.error()
            return
        from paste import paste_text
        paste_text(text,
                   restore=self.cfg.get("restore_clipboard", True),
                   restore_delay=float(self.cfg.get("restore_clipboard_delay_sec", 1.0)))
        sounds.ready()
        log.info("Повторная вставка последнего текста (%d символов)", len(text))

    def correct_last(self):
        """Хоткей: окно исправления только что вставленного текста.
        Целевое окно захватываем СЕЙЧАС (пользователь смотрит в поле с
        текстом), а не берём устаревшее окно момента записи."""
        if not self._last_text or not self.gui:
            sounds.error()
            return
        try:
            import paste as paste_mod
            self._correct_hwnd = paste_mod.get_foreground_hwnd() or self._target_hwnd
        except Exception:
            self._correct_hwnd = self._target_hwnd
        self.gui.call(self.gui.correct_last_dialog)

    def replace_last_sync(self, new, hwnd):
        """Синхронная замена: вызывать из GUI-потока СРАЗУ после того, как
        диалог отдал фокус целевому окну (SetForegroundWindow). Только тогда
        Ctrl+V надёжно уходит в поле, а не перехватывается окном приложения.
        Быстрая часть (стереть+вставить) — синхронно; медленная (восстановить
        буфер, выучить, обновить историю) — в фоне."""
        old = self._last_text
        self._last_text = new
        from paste import replace_text_now
        old_clip = replace_text_now(
            len(old), new, target_hwnd=hwnd or self._correct_hwnd)

        def tail():
            try:
                if self.cfg.get("restore_clipboard", True) and old_clip:
                    time.sleep(float(
                        self.cfg.get("restore_clipboard_delay_sec", 1.0)))
                    import pyperclip
                    pyperclip.copy(old_clip)
            except Exception:
                log.exception("Не удалось восстановить буфер обмена")
            try:
                import corrections
                corrections.learn(old, new)
            except Exception:
                log.exception("Не удалось выучить исправления")
            try:
                entries = history.read_last(10000)
                if entries and entries[-1].get("text") == old:
                    entries[-1]["text"] = new
                    history.save_all(entries)
                    self._gui("on_history_changed")
            except Exception:
                log.exception("Не удалось обновить историю")
            sounds.ready()

        threading.Thread(target=tail, daemon=True).start()

    def current_state(self):
        """Текущее состояние для GUI (те же имена, что у иконок трея)."""
        if self.transcriber is None:
            return "loading"
        if self.fsm and self.fsm.state == "paused":
            return "paused"
        if self.recorder and self.recorder.recording:
            return "recording"
        if self._processing:
            return "processing"
        return "idle"

    def apply_config(self, new_cfg):
        """Применить настройки из GUI без перезапуска (кроме model_id/device)."""
        with self._busy:
            fresh = appconfig.load()  # не затирать внешние правки config.json
            fresh.update(new_cfg)
            self.cfg.clear()
            self.cfg.update(fresh)
            appconfig.save(self.cfg)
            sounds.enabled = bool(self.cfg.get("beeps", True))
            sounds.style = str(self.cfg.get("beep_style", "classic"))
            if self.recorder:
                self.recorder.device = self.cfg.get("input_device")
            if self.fsm:
                self.fsm.double_press_sec = \
                    self.cfg.get("double_press_interval_ms", 400) / 1000
                self.fsm.debounce_sec = self.cfg.get("debounce_ms", 500) / 1000
            if self.transcriber:  # язык применяется сразу, без перезагрузки модели
                lang = str(self.cfg.get("language") or "auto").strip().lower()
                self.transcriber.language = None if lang in ("", "auto") else lang
        if self.listener:  # перевешиваем хук с новыми клавишами/режимом
            try:
                old = self.listener
                old.stop()
                self.listener = self._make_listener()
                # не терять зажатый push-to-talk при пересоздании хука
                self.listener._ptt_down = getattr(old, "_ptt_down", False)
                self.listener.start()
            except Exception:
                log.exception("Не удалось переустановить хоткеи")
        log.info("Настройки применены")

    def _init(self):
        try:
            from hotkey_fsm import HotkeyFSM
            from recorder import Recorder
            import asr
            self.recorder = Recorder(self.cfg.get("input_device"))
            self.fsm = HotkeyFSM(
                double_press_sec=self.cfg.get("double_press_interval_ms", 400) / 1000,
                debounce_sec=self.cfg.get("debounce_ms", 500) / 1000)
            # хук клавиатуры ставим ДО загрузки модели: она может грузиться
            # (а на новой установке — качаться) минутами, и всё это время
            # хоткеи молча не работали. Теперь нажатие сразу даёт понятный
            # ответ «модель ещё загружается», а не тишину.
            self.listener = self._make_listener()
            self.listener.start()
            self.transcriber = asr.load_transcriber(
                self.cfg, notify=self.tray.notify)
            self.transcriber.warmup()  # первая диктовка не платит за прогрев
            try:  # прогрев VAD: первый jit-вызов долгий, нельзя в аудио-цикле
                import vad
                vad.speech_probs(np.zeros(SR, dtype=np.float32))
            except Exception:
                log.exception("Прогрев VAD не удался (не критично)")
            self.tray.set_state("idle")
            sounds.ready()
            log.info("Готово к работе")
            if _OLD_AUTOSTART:  # автозапуск вёл на старую копию — сообщаем
                self.tray.notify(
                    "Автозапуск указывал на старую версию и был исправлен. "
                    f"Старая копия лежит в {_OLD_AUTOSTART} — её можно удалить.")
            threading.Thread(target=self._update_watch, daemon=True).start()
        except Exception:
            log.exception("Ошибка инициализации")
            sounds.error()
            self.tray.notify("Ошибка запуска — подробности в app.log")

    # --- запись ---

    def start_recording(self):
        with self._busy:
            if self.transcriber is None:
                # хоткей нажат, пока модель ещё грузится — раньше это была
                # полная тишина, и выглядело как «хоткеи не работают»
                log.info("Хоткей нажат, но модель ещё загружается")
                sounds.error()
                self.tray.notify("Модель ещё загружается — секунду, "
                                 "и можно диктовать.")
                self.fsm.reset_idle()
                return
            if self.recorder.recording or self.fsm.state == "paused":
                self.fsm.reset_idle()  # при паузе состояние сохранится
                return
            if self._processing:
                # push_to_talk: предыдущее распознавание ещё идёт
                log.info("Занято распознаванием — запись не начата")
                sounds.error()
                self.fsm.reset_idle()
                return
            try:
                self.recorder.start()
            except Exception:
                log.exception("Не удалось начать запись (микрофон?)")
                sounds.error()
                self.fsm.reset_idle()
                self.tray.notify("Микрофон недоступен — см. app.log")
                return
            try:  # запоминаем окно, куда диктуют — вставим текст именно в него
                import paste as paste_mod
                self._target_hwnd = paste_mod.get_foreground_hwnd()
            except Exception:
                self._target_hwnd = None
            self._limit_timer = threading.Timer(
                float(self.cfg.get("max_recording_sec", 600)), self._limit_hit)
            self._limit_timer.daemon = True
            self._limit_timer.start()
            self._partials = []
            self._partial_at_pause = []
            self._session_parts = []
            if self.cfg.get("streaming_enabled", True):
                # распознаём готовые фрагменты, пока пользователь ещё диктует
                self._stream_thread = threading.Thread(
                    target=self._stream_worker, args=(self._partials,),
                    daemon=True)
                self._stream_thread.start()
            else:
                self._stream_thread = None
            # побочные эффекты под локом: параллельный стоп не обгонит их
            sounds.start_recording()
            self.tray.set_state("recording")
        self._gui("overlay_show", "recording")
        log.info("Запись пошла")

    def _stream_worker(self, partials):
        try:
            # мелкие куски = после остановки ждать почти нечего; точность
            # мелких кусков держит КОНТЕКСТ — уже распознанный текст уходит
            # в системный промт модели, а лишние точки на швах снимает склейка
            cmin = float(self.cfg.get("stream_min_sec", 4))
            cmax = float(self.cfg.get("stream_max_sec", 12))
            pause = float(self.cfg.get("eager_pause_sec", 0.9))
            if self.cfg.get("live_transcript"):
                # живой транскрипт: куски отдаются раньше, текст на экране
                # появляется быстрее; контекст держит точность
                cmin, cmax = min(cmin, 3.0), min(cmax, 7.0)
                pause = min(pause, 0.7)
                if self.cfg.get("live_fast"):
                    # максимально живо: куски от 1.5 с (чуть ниже точность)
                    cmin, cmax, pause = 1.5, 5.0, 0.45
            while self.recorder.recording:
                time.sleep(0.3)
                chunk = self.recorder.take_chunk(cmin, cmax, eager=True,
                                                 eager_pause_sec=pause)
                if chunk is None:
                    continue
                log.info("Потоковый фрагмент %.1f c — распознаю во время записи",
                         len(chunk) / SR)
                if self.cfg.get("final_repass"):
                    self._session_parts.append(chunk)
                # разрез по паузе = конец фразы: точку модели на этом шве
                # склейка сохранит (иначе предложения слипаются)
                self._partial_at_pause.append(bool(self.recorder.cut_at_pause))
                ctx = " ".join(partials)
                partials.append(self.transcriber.transcribe_parts(
                    [chunk], context=ctx)[0])
        except Exception:
            log.exception("Ошибка потокового распознавания")

    def _limit_hit(self):
        if not self.recorder.recording:
            return
        log.warning("Достигнут лимит записи — останавливаю и распознаю")
        sounds.limit_reached()
        self.fsm.force_stop()
        self.stop_and_recognize()

    def stop_and_recognize(self):
        with self._busy:
            t = self._limit_timer
            if t:
                t.cancel()
                self._limit_timer = None
            total_sec = self.recorder.total_duration()
            audio = self.recorder.stop()  # остаток, не забранный потоковым воркером
            worker = self._stream_thread
            self._stream_thread = None
            had_stream = worker is not None or bool(self._partials)
            if audio.size < SR // 4 and not had_stream:
                # <0.25 c — случайный тап/гонка, пропускаем
                log.info("Запись слишком короткая (%d сэмплов) — пропускаю", audio.size)
                if not self._processing:  # не трогаем FSM/иконку чужого распознавания
                    self.fsm.reset_idle()
                    self._set_idle_icon()
                return
            self._processing = True
            partials = self._partials
            at_pause = self._partial_at_pause
            self._partials = []
            self._partial_at_pause = []
        try:
            sounds.stop_recording()
            self.tray.set_state("processing")
            self._gui("overlay_show", "processing")
            peak = getattr(self.recorder, "peak", 0.0)
            log.info("Запись остановлена: всего %.1f c, хвост %.1f c, "
                     "пик сигнала %.4f, распознаю...",
                     total_sec, audio.size / SR, peak)
            if peak < 0.002:
                log.warning("Микрофон дал тишину (пик %.4f) — проверьте "
                            "устройство ввода в Настройках и кнопкой "
                            "«Проверка микрофона»", peak)
            self._save_wav(audio, LAST_WAV)  # страховка на случай сбоя
            t0 = time.monotonic()
            if worker is not None and worker.is_alive():
                worker.join(timeout=600)  # дораспознаётся последний фрагмент
            tail = (self.transcriber.transcribe(audio, context=" ".join(partials))
                    if audio.size >= SR // 4 else "")
            from textproc import join_texts
            if self.cfg.get("final_repass") and self._session_parts:
                # «идеальный финал»: перераспознать запись ЦЕЛИКОМ крупными
                # кусками — вставленный текст без швов мелких фрагментов;
                # потоковые partials при этом служили живому транскрипту
                try:
                    pieces = list(self._session_parts)
                    if audio.size:
                        pieces.append(audio)
                    full = np.concatenate(pieces)
                    log.info("Идеальный финал: перераспознаю %.1f c целиком",
                             len(full) / SR)
                    text = self.transcriber.transcribe(full, whole=True)
                except Exception:
                    log.exception("Перераспознавание не удалось — "
                                  "беру потоковый текст")
                    text = join_texts([*partials, tail], at_pause=[*at_pause, True])
                self._session_parts = []
            else:
                text = join_texts([*partials, tail], at_pause=[*at_pause, True])
            import corrections
            text = corrections.apply(text)  # словарь выученных исправлений
            recog_sec = time.monotonic() - t0
            log.info("Распознано за %.1f c (после остановки): %d символов",
                     recog_sec, len(text))
            if text:
                self._last_text = text  # для повторной вставки правым Alt
                from paste import paste_text
                paste_text(
                    text,
                    restore=self.cfg.get("restore_clipboard", True),
                    restore_delay=float(self.cfg.get("restore_clipboard_delay_sec", 1.0)),
                    target_hwnd=self._target_hwnd)  # окно, куда диктовали
                sounds.ready()
                if self.cfg.get("history_enabled", True):
                    history.append(text, total_sec, recog_sec,
                                   int(self.cfg.get("history_max_entries", 500)))
                    self._gui("on_history_changed")
            else:
                log.warning("Распознан пустой текст")
                sounds.error()
            try:
                LAST_WAV.unlink(missing_ok=True)  # временный файл больше не нужен
            except OSError:
                pass
        except Exception:
            log.exception("Ошибка распознавания")
            sounds.error()
            self.tray.notify(
                "Ошибка распознавания — см. app.log (запись: last_recording.wav)")
        finally:
            self._processing = False
            self.fsm.reset_idle()
            self._set_idle_icon()
            self._gui("overlay_hide")

    def request_stop(self):
        """Стоп из GUI/оверлея — как одиночный Alt."""
        if not (self.recorder and self.recorder.recording):
            return
        self.fsm.force_stop()
        self.stop_and_recognize()

    def cancel_recording(self):
        """Отмена записи (✕ на оверлее): ничего не распознаём и не вставляем."""
        with self._busy:
            if not (self.recorder and self.recorder.recording):
                return
            t = self._limit_timer
            if t:
                t.cancel()
                self._limit_timer = None
            self.recorder.stop()
            self._partials = []  # потоковый воркер дописывает уже в мёртвый список
            self._partial_at_pause = []
            self._session_parts = []
            self._stream_thread = None
            self.fsm.reset_idle()
        sounds.stop_recording()
        self._set_idle_icon()
        self._gui("overlay_hide")
        log.info("Запись отменена пользователем")

    def _set_idle_icon(self):
        self.tray.set_state("paused" if self.fsm.state == "paused" else "idle")

    def _save_wav(self, audio, path):
        try:
            pcm = (np.clip(audio, -1, 1) * 32767).astype("<i2")
            with wave.open(str(path), "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(SR)
                w.writeframes(pcm.tobytes())
        except Exception:
            log.exception("Не удалось сохранить резервный wav")

    # --- меню трея ---

    def toggle_pause(self):
        if not self.fsm:
            return
        if self.fsm.state == "paused":
            self.fsm.resume()
            self.tray.set_state("idle")
            log.info("Возобновлено")
            return
        with self._busy:  # чтобы не разъехаться с параллельным стартом записи
            if self.recorder and self.recorder.recording:
                t = self._limit_timer
                if t:
                    t.cancel()
                    self._limit_timer = None
                self.recorder.stop()  # запись сбрасывается без распознавания
            self.fsm.pause()
        self.tray.set_state("paused")
        log.info("Пауза")

    def mic_test(self):
        with self._busy:
            if self.recorder is None or self.recorder.recording or self._processing:
                self.tray.notify("Сейчас занято — попробуйте позже")
                return
            self._processing = True  # на время теста блокируем хоткей-запись
        try:
            import sounddevice as sd
            log.info("Аудиоустройства, видимые системе:\n%s", sd.query_devices())
            self.tray.notify("Говорите: запись 3 секунды...")
            data = sd.rec(3 * SR, samplerate=SR, channels=1, dtype="float32",
                          device=self.cfg.get("input_device"))
            sd.wait()
            peak = float(np.abs(data).max())
            sd.play(data[:, 0], SR)
            sd.wait()
            if peak > 0.01:
                self.tray.notify("Микрофон работает, пик %.0f%%" % (peak * 100))
            else:
                self.tray.notify("Очень тихо — проверьте микрофон в настройках Windows")
        except Exception:
            log.exception("Проверка микрофона не удалась")
            self.tray.notify("Ошибка записи — см. app.log")
        finally:
            self._processing = False

    def quit(self):
        log.info("Выход")
        try:
            if self.listener:
                self.listener.stop()
        finally:
            if self.gui:
                self.gui.call(self.gui.quit)  # завершит mainloop
            self.tray.stop()
            w = getattr(self, "_aura_win", None)
            if w is not None:
                try:
                    w.destroy()  # разблокирует webview.start()
                except Exception:
                    pass

    def restart(self):
        """Перезапуск: новый процесс стартует, текущий выходит."""
        log.info("Перезапуск приложения")
        try:
            if self.listener:
                self.listener.stop()
        except Exception:
            pass
        try:
            if _GUARD:  # освобождаем порт одиночного запуска для новичка
                _GUARD.close()
        except Exception:
            pass
        try:
            import subprocess
            exe = sys.executable
            try:  # перезапускаемся под своим именем (антивирус)
                import setup_wizard
                exe = str(setup_wizard.ensure_launcher() or sys.executable)
            except Exception:
                pass
            subprocess.Popen([exe, str(APP_DIR / "main.py")],
                             cwd=APP_DIR)
        except Exception:
            log.exception("Не удалось запустить новый процесс")
        if self.gui:
            self.gui.call(self.gui.quit)
        self.tray.stop()
        w = getattr(self, "_aura_win", None)
        if w is not None:
            try:
                w.destroy()
            except Exception:
                pass


def selftest(cfg):
    print("Селфтест: загрузка модели + распознавание тестового wav")
    import asr
    t0 = time.monotonic()
    tr = asr.load_transcriber(cfg)
    print("Модель загружена за %.0f c (device=%s)" % (time.monotonic() - t0, tr.device))
    audio = read_wav(APP_DIR / "assets" / "test.wav")
    t0 = time.monotonic()
    text = tr.transcribe(audio)
    dt = time.monotonic() - t0
    print("Аудио %.1f c распознано за %.1f c:" % (len(audio) / SR, dt))
    print("  %r" % text)
    if not text.strip():
        print("ОШИБКА: пустой результат распознавания")
        return 1
    print("OK")
    return 0


def _heal_launcher():
    """Своё имя процесса вместо безликого pythonw.exe.

    Антивирус запоминает разрешение (микрофон, сеть) для конкретного exe:
    пока приложение стартовало как pythonw.exe, Kaspersky спрашивал снова
    и снова. Создаём PandaVoice.exe в venv и, если он появился впервые,
    перенацеливаем на него ярлыки — иначе они остались бы на pythonw.exe."""
    if sys.platform != "win32":
        return

    def work():
        try:
            import setup_wizard
            existed = (Path(sys.executable).with_name("PandaVoice.exe")).exists()
            lnk = setup_wizard.ensure_launcher()
            if not lnk or existed:
                return
            log.info("Лаунчер создан — обновляю ярлыки на %s", lnk.name)
            try:
                setup_wizard.make_desktop_shortcut()
            except Exception:
                log.exception("Ярлык рабочего стола не обновлён")
            if setup_wizard.autostart_enabled():
                try:
                    setup_wizard.enable_autostart()
                except Exception:
                    log.exception("Ярлык автозапуска не обновлён")
        except Exception:
            log.exception("Не удалось подготовить лаунчер")

    threading.Thread(target=work, daemon=True).start()


def _warn_if_nested_copy():
    """Приложение запущено из временной папки обновления (…\\updates\\1.2.0)?

    Старый механизм обновления распаковывал версии в подпапки; такая копия
    не обновляется, а её путь меняется — из-за этого антивирус каждый раз
    видит «новую» программу и переспрашивает."""
    parts = [p.lower() for p in APP_DIR.parts]
    if "updates" in parts:
        log.warning(
            "ВНИМАНИЕ: приложение запущено из временной папки обновления %s. "
            "Это старая копия: она не обновляется, и антивирус считает её "
            "новой программой при каждой версии. Запустите основную "
            "установку (папку без «updates» в пути) и удалите эту копию.",
            APP_DIR)
        return True
    return False


def _heal_desktop_shortcut():
    """Восстановить ярлык «Panda Voice» на рабочем столе, если его нет
    (пользователь удалил, установщик не создал, потерялся при переносе).
    Фоново и молча: на запуск приложения не влияет ни при какой ошибке."""
    if sys.platform != "win32":
        return

    def work():
        try:
            import subprocess
            import setup_wizard
            out = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; "
                 "[Environment]::GetFolderPath('Desktop')"],
                capture_output=True, timeout=60,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            desktop = Path(out.stdout.decode("utf-8", "replace").strip())
            if not desktop.exists() or (desktop / "Panda Voice.lnk").exists():
                return
            setup_wizard.make_desktop_shortcut()
            log.info("Ярлык на рабочем столе восстановлен")
        except Exception:
            log.exception("Не удалось восстановить ярлык на рабочем столе")

    threading.Thread(target=work, daemon=True).start()


_OLD_AUTOSTART = None  # папка прежней копии, если автозапуск был перенаправлен


def _heal_autostart():
    """Автозапуск должен вести на ТЕКУЩУЮ папку приложения.

    Ярлык хранит абсолютный путь: после переустановки в другую папку при
    входе в Windows стартовала СТАРАЯ копия — она занимала порт одиночного
    запуска, и новая версия молча выходила («запускается старая версия»).

    СИНХРОННО (не в потоке) и ДО single_instance_guard: иначе при выходе
    из-за уже запущенной старой копии починка не успела бы отработать."""
    global _OLD_AUTOSTART
    try:
        import setup_wizard
        if not setup_wizard.autostart_enabled():
            return
        old = setup_wizard.autostart_target_dir()
        if old is None or old.resolve() == APP_DIR.resolve():
            return
        setup_wizard.enable_autostart()  # перезаписывает ярлык на APP_DIR
        _OLD_AUTOSTART = old
        log.warning("Автозапуск вёл на другую папку (%s) — перенаправлен на "
                    "текущую (%s). Старую копию можно удалить.", old, APP_DIR)
    except Exception:
        log.exception("Не удалось проверить путь автозапуска")


def main():
    ap = argparse.ArgumentParser(description="Голосовая диктовка (Qwen3-ASR)")
    ap.add_argument("--setup", action="store_true", help="мастер первого запуска")
    ap.add_argument("--selftest", action="store_true", help="проверка модели")
    args = ap.parse_args()

    setup_logging()
    enable_dpi_awareness()
    if sys.platform == "win32":
        try:  # своя группа на панели задач (иконка панды, а не python)
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "PandaVoice.App")
        except Exception:
            pass
    log.info("Panda Voice %s запускается", __version__)
    cfg = appconfig.load()
    raise_priority(cfg)

    if args.selftest:
        sys.exit(selftest(cfg))

    if args.setup or not cfg.get("setup_done"):
        try:
            import setup_gui  # оконная настройка микрофона
            setup_gui.run(cfg, first_run=not cfg.get("setup_done"))
        except Exception:
            log.exception("GUI-настройка недоступна — пробую консольный мастер")
            if sys.stderr is not None:
                try:
                    import setup_wizard
                    setup_wizard.run(cfg)
                except Exception:
                    log.exception("Консольный мастер тоже не удался")
        cfg = appconfig.load()
        if args.setup or cfg.get("setup_done"):
            return  # завершённый мастер сам запускает приложение
        # мастер закрыт на полпути или упал: раньше приложение при КАЖДОМ
        # запуске молча умирало здесь («ярлык не работает»). Теперь
        # продолжаем запуск со значениями по умолчанию — микрофон можно
        # выбрать позже в Настройках.
        log.warning("Мастер не завершён — запускаюсь с настройками "
                    "по умолчанию")
        cfg["setup_done"] = True
        appconfig.save(cfg)

    _heal_launcher()          # своё имя процесса для антивируса
    _warn_if_nested_copy()
    _heal_desktop_shortcut()
    _heal_autostart()
    guard = single_instance_guard()  # noqa: F841 — держим сокет живым
    App(cfg).run()
    os._exit(0)  # страховка: не ждать незавершённые потоки


if __name__ == "__main__":
    main()
