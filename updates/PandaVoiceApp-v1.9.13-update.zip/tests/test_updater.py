"""Тесты механизма обновления. Запуск: python tests/test_updater.py"""
import json
import sys
import tempfile
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import updater


def test_parse_ver():
    assert updater.parse_ver("PandaVoiceApp-v1.2.3-update.zip") == (1, 2, 3)
    assert updater.parse_ver("v10.0.1") == (10, 0, 1)
    assert updater.parse_ver("мусор.zip") is None
    assert updater.parse_ver("v1.2.10") > updater.parse_ver("v1.2.9")


def test_find_update_picks_newest():
    d = Path(tempfile.mkdtemp())
    for name in ["PandaVoiceApp-v1.0.0-windows.zip",
                 "PandaVoiceApp-v1.2.0-update.zip",
                 "PandaVoiceApp-v1.1.2-update.zip", "другое.zip"]:
        (d / name).write_bytes(b"x")
    ver, path = updater.find_update(d)
    assert ver == (1, 2, 0) and path.name == "PandaVoiceApp-v1.2.0-update.zip"
    assert updater.find_update(Path(tempfile.mkdtemp())) is None


def test_apply_zip_preserves_user_data():
    app = Path(tempfile.mkdtemp())
    updater.APP_DIR = app
    (app / "config.json").write_text('{"мои": "настройки"}', encoding="utf-8")
    (app / "history.jsonl").write_text("старая история\n", encoding="utf-8")
    (app / "main.py").write_text("старый код", encoding="utf-8")
    (app / "venv").mkdir()
    (app / "venv" / "big.bin").write_bytes(b"venv")

    z = Path(tempfile.mkdtemp()) / "PandaVoiceApp-v9.9.9-update.zip"
    with zipfile.ZipFile(z, "w") as f:
        f.writestr("main.py", "новый код")
        f.writestr("config.json", '{"дефолт": true}')       # НЕ должен затереть
        f.writestr("history.jsonl", "")                     # НЕ должен затереть
        f.writestr("venv/pwn.txt", "x")                     # НЕ должен попасть
        f.writestr("tests/test_x.py", "тест")
        f.writestr("VERSION", "v9.9.9")

    n = updater.apply_zip(z)
    assert (app / "main.py").read_text(encoding="utf-8") == "новый код"
    assert "мои" in (app / "config.json").read_text(encoding="utf-8")
    assert (app / "history.jsonl").read_text(encoding="utf-8") == "старая история\n"
    assert not (app / "venv" / "pwn.txt").exists()
    assert (app / "tests" / "test_x.py").exists()
    assert (app / "VERSION").read_text(encoding="utf-8") == "v9.9.9"
    assert n == 3  # main.py, tests/test_x.py, VERSION


def test_check_remote_disabled():
    assert updater.check_remote({"update_check": False}) is None


def test_manifest_url_uses_configured_repo():
    assert updater.manifest_url({}).endswith(
        "Contento-R/PandaVoice-dist/main/latest.json")
    u = updater.manifest_url({"update_repo": "Кто-то/Другой"})
    assert u == "https://raw.githubusercontent.com/Кто-то/Другой/main/latest.json"


def _stub_manifest(data):
    updater.fetch_manifest = lambda cfg, timeout=10: data


def test_check_remote_compares_versions():
    app = Path(tempfile.mkdtemp())
    updater.APP_DIR = app
    (app / "VERSION").write_text("v1.8.7", encoding="utf-8")
    real = updater.fetch_manifest
    real_rel = updater.fetch_release
    updater.fetch_release = lambda cfg, timeout=10: None  # без сети в тестах
    try:
        _stub_manifest({"version": "v1.9.0", "url": "http://x/u.zip"})
        res = updater.check_remote({})
        assert res and res[0] == "v1.9.0" and res[1]["url"] == "http://x/u.zip"
        _stub_manifest({"version": "v1.8.7", "url": "http://x/u.zip"})
        assert updater.check_remote({}) is None       # та же версия
        _stub_manifest({"version": "v1.8.6", "url": "http://x/u.zip"})
        assert updater.check_remote({}) is None       # старее — не предлагаем
    finally:
        updater.fetch_manifest = real
        updater.fetch_release = real_rel


def test_releases_channel_only_with_token():
    """Без токена в Releases приватного репо ходить бессмысленно (404) —
    сразу берём публичный репозиторий раздачи."""
    app = Path(tempfile.mkdtemp())
    updater.APP_DIR = app
    (app / "VERSION").write_text("v1.0.0", encoding="utf-8")
    real_rel, real_man = updater.fetch_release, updater.fetch_manifest
    called = []

    def rel(cfg, timeout=10):
        called.append(1)
        return {"version": "v3.0.0", "url": "http://rel/u.zip"}

    updater.fetch_release = rel
    updater.fetch_manifest = lambda cfg, timeout=10: {
        "version": "v2.0.0", "url": "http://dist/u.zip"}
    try:
        res = updater.check_remote({})                      # токена нет
        assert not called, "без токена ходили в Releases"
        assert res[1]["url"] == "http://dist/u.zip", res
        res = updater.check_remote({"github_token": "t"})   # токен есть
        assert called and res[1]["url"] == "http://rel/u.zip", res
    finally:
        updater.fetch_release, updater.fetch_manifest = real_rel, real_man


def test_fetch_release_builds_manifest():
    """Releases-канал: берём именно *-update.zip, sha256 из digest ассета,
    токен уходит в заголовки скачивания."""
    import io
    rel = {"tag_name": "v2.0.0", "body": "notes", "assets": [
        {"name": "PandaVoiceApp-v2.0.0-windows.zip", "url": "http://a/1"},
        {"name": "PandaVoiceApp-v2.0.0-update.zip", "url": "http://a/2",
         "digest": "sha256:abc"}]}

    class R(io.BytesIO):
        def __enter__(self):
            return self

        def __exit__(self, *a):
            pass

    real = updater._opener.open
    updater._opener.open = lambda req, timeout=10: R(json.dumps(rel).encode())
    try:
        info = updater.fetch_release({"github_token": "t"})
    finally:
        updater._opener.open = real
    assert info["version"] == "v2.0.0" and info["url"] == "http://a/2"
    assert info["sha256"] == "abc"
    assert info["headers"]["Authorization"] == "Bearer t"
    assert info["headers"]["Accept"] == "application/octet-stream"


def _fake_app_dir(version="v1.0.0"):
    app = Path(tempfile.mkdtemp())
    updater.APP_DIR = app
    (app / "VERSION").write_text(version, encoding="utf-8")
    return app


def test_run_downloads_when_no_local_archive():
    """Кнопка «Обновление» без архива в «Загрузках» должна СКАЧАТЬ новую
    версию, а не отвечать «архив не найден» (жалоба: не предлагает обновиться)."""
    _fake_app_dir("v1.0.0")
    empty = Path(tempfile.mkdtemp())
    zpath = Path(tempfile.mkdtemp()) / "PandaVoiceApp-v2.0.0-update.zip"
    with zipfile.ZipFile(zpath, "w") as f:
        f.writestr("VERSION", "v2.0.0")
        f.writestr("main.py", "новый код")
    calls = {}
    real_find, real_check, real_dl, real_pip = (
        updater.find_update, updater.check_remote, updater.download_update,
        updater.subprocess.run)
    updater.find_update = lambda folder=None: None      # в «Загрузках» пусто
    updater.check_remote = lambda cfg, timeout=10: (
        "v2.0.0", {"url": "http://x/PandaVoiceApp-v2.0.0-update.zip"})
    updater.download_update = lambda info, **kw: calls.setdefault("dl", zpath)
    updater.subprocess.run = lambda *a, **k: None       # без реального pip
    try:
        status, msg = updater.run(cfg={"update_check": True})
    finally:
        (updater.find_update, updater.check_remote, updater.download_update,
         updater.subprocess.run) = real_find, real_check, real_dl, real_pip
    assert status == "updated", (status, msg)
    assert "dl" in calls, "обновление не скачивалось из сети"
    assert (updater.APP_DIR / "VERSION").read_text(encoding="utf-8") == "v2.0.0"


def test_run_says_up_to_date_without_network_update():
    _fake_app_dir("v9.9.9")
    real_find, real_check = updater.find_update, updater.check_remote
    updater.find_update = lambda folder=None: None
    updater.check_remote = lambda cfg, timeout=10: None   # новее нет
    try:
        status, msg = updater.run(cfg={})
    finally:
        updater.find_update, updater.check_remote = real_find, real_check
    assert status == "none" and "последняя версия v9.9.9" in msg, msg


def test_run_reports_network_error_clearly():
    _fake_app_dir("v1.0.0")
    real_find, real_check = updater.find_update, updater.check_remote

    def boom(cfg, timeout=10):
        raise OSError("сеть недоступна")

    updater.find_update = lambda folder=None: None
    updater.check_remote = boom
    try:
        status, msg = updater.run(cfg={})
    finally:
        updater.find_update, updater.check_remote = real_find, real_check
    assert status == "error" and "сеть недоступна" in msg, msg


def test_download_verifies_checksum():
    import hashlib
    import urllib.request
    payload = "PK\x03\x04 тестовый архив".encode("utf-8") * 100
    good = hashlib.sha256(payload).hexdigest()

    class _Resp:
        headers = {"Content-Length": str(len(payload))}

        def __init__(self):
            self._buf = payload

        def read(self, n=-1):
            chunk, self._buf = self._buf[:n], self._buf[n:]
            return chunk

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    real = updater._opener.open
    updater._opener.open = lambda *a, **k: _Resp()
    d = Path(tempfile.mkdtemp())
    try:
        info = {"url": "http://x/PandaVoiceApp-v9.9.9-update.zip",
                "sha256": good}
        p = updater.download_update(info, dest_dir=d)
        assert p.read_bytes() == payload
        assert p.name == "PandaVoiceApp-v9.9.9-update.zip"
        # битая сумма — файл не остаётся
        bad = dict(info, sha256="0" * 64,
                   name="PandaVoiceApp-v9.9.8-update.zip")
        try:
            updater.download_update(bad, dest_dir=d)
            raise AssertionError("битая сумма должна отвергаться")
        except ValueError:
            pass
        assert not list(d.glob("*.part"))
        assert not (d / "PandaVoiceApp-v9.9.8-update.zip").exists()
    finally:
        updater._opener.open = real


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов апдейтера прошли")
