"""Приведение типов входов модели. Запуск: python tests/test_asr_inputs.py

Регрессия: у пользователя распознавание падало с
«Input type (float) and bias type (struct c10::BFloat16) should be the same».
Причина — в части версий transformers .to(device, dtype) у результата
apply_chat_template молча игнорирует dtype, и аудио остаётся float32.
"""
import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import torch

import asr


class _FakeBatch(dict):
    """BatchEncoding, чей .to() принимает только устройство (как в проблемной
    версии transformers) — dtype игнорируется."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.to_calls = []

    def to(self, *args, **kwargs):
        self.to_calls.append((args, kwargs))
        return self


def _tr(dtype=torch.bfloat16, quantized=False):
    tr = asr.Transcriber.__new__(asr.Transcriber)   # без загрузки модели
    tr.torch = torch
    tr.quantized = quantized
    tr.model = types.SimpleNamespace(dtype=dtype, device=torch.device("cpu"))
    return tr


def test_float_inputs_cast_to_model_dtype():
    tr = _tr(torch.bfloat16)
    b = _FakeBatch(input_features=torch.zeros(1, 8, 4, dtype=torch.float32),
                   input_ids=torch.ones(1, 3, dtype=torch.long))
    out = tr._cast_inputs(b)
    assert out["input_features"].dtype == torch.bfloat16
    assert out["input_ids"].dtype == torch.long      # целые не трогаем


def test_fp32_model_leaves_audio_fp32():
    tr = _tr(torch.float32)
    b = _FakeBatch(input_features=torch.zeros(1, 4, dtype=torch.float32))
    assert tr._cast_inputs(b)["input_features"].dtype == torch.float32


def test_quantized_forces_float32():
    tr = _tr(torch.bfloat16, quantized=True)
    b = _FakeBatch(input_features=torch.zeros(1, 4, dtype=torch.bfloat16))
    assert tr._cast_inputs(b)["input_features"].dtype == torch.float32


def test_survives_batch_without_to():
    """Голый dict без .to() не должен ронять распознавание."""
    tr = _tr(torch.bfloat16)
    plain = {"input_features": torch.zeros(1, 4, dtype=torch.float32)}
    out = tr._cast_inputs(plain)
    assert out["input_features"].dtype == torch.bfloat16


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов входов модели прошли")
