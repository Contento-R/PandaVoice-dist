"""Тесты собственного лаунчера и обнаружения копии из папки обновлений.

Запуск: python tests/test_launcher.py
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def test_nested_copy_detected():
    import main
    real = main.APP_DIR
    try:
        main.APP_DIR = Path(r"C:/soft/PandaVoiceApp-v1.1.2/updates/1.2.0")
        assert main._warn_if_nested_copy() is True
        main.APP_DIR = Path("C:/soft/PandaVoiceApp")
        assert main._warn_if_nested_copy() is False
        main.APP_DIR = Path("/home/u/PandaVoice/dictation-app")
        assert main._warn_if_nested_copy() is False
    finally:
        main.APP_DIR = real


def test_launcher_noop_off_windows():
    import setup_wizard
    if sys.platform != "win32":
        assert setup_wizard.ensure_launcher() is None


def test_launcher_copies_next_to_pythonw(monkey=None):
    """Лаунчер обязан лежать РЯДОМ с pythonw.exe (внутри venv): иначе не
    найдётся pyvenv.cfg и пропадут установленные пакеты."""
    import setup_wizard
    if sys.platform == "win32":
        return  # на Windows проверяется вживую
    scripts = Path(tempfile.mkdtemp())
    fake_pythonw = scripts / "pythonw.exe"
    fake_pythonw.write_bytes(b"MZ" + b"\0" * 100)
    real_platform, real_exe = sys.platform, sys.executable
    try:  # эмулируем Windows-путь функции
        import shutil
        src = fake_pythonw
        dst = src.with_name("PandaVoice.exe")
        if not dst.exists() or dst.stat().st_size != src.stat().st_size:
            shutil.copy2(src, dst)
        assert dst.exists() and dst.parent == src.parent
        assert dst.stat().st_size == src.stat().st_size
    finally:
        sys.platform, sys.executable = real_platform, real_exe


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok {fn.__name__}")
    print(f"OK: {len(fns)} тестов лаунчера прошли")
