"""Мастер первого запуска: выбор микрофона → тестовая диктовка → автозагрузка."""
import logging
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

import numpy as np

import appconfig

log = logging.getLogger("wizard")
SR = 16000
APP_DIR = appconfig.APP_DIR


def ask(prompt, default_yes=True):
    a = input(prompt + (" [Y/n]: " if default_yes else " [y/N]: ")).strip().lower()
    if not a:
        return default_yes
    return a.startswith(("y", "д"))


def pick_microphone(cfg):
    import sounddevice as sd
    while True:
        devs = sd.query_devices()
        inputs = [(i, d) for i, d in enumerate(devs) if d["max_input_channels"] > 0]
        if not inputs:
            print("Микрофоны не найдены! Подключите микрофон и запустите мастер снова.")
            return False
        try:
            default_in = sd.default.device[0]
        except Exception:
            default_in = None
        print("\nДоступные микрофоны:")
        for i, d in inputs:
            mark = "  <- по умолчанию" if i == default_in else ""
            print(f"  {i}: {d['name']}{mark}")
        raw = input("Номер микрофона [Enter — по умолчанию]: ").strip()
        try:
            device = int(raw) if raw else None
        except ValueError:
            print("Нужен номер из списка.")
            continue
        print("Тестовая запись 3 секунды — скажите что-нибудь...")
        try:
            data = sd.rec(3 * SR, samplerate=SR, channels=1,
                          dtype="float32", device=device)
            sd.wait()
        except Exception as e:
            print(f"Не удалось записать: {e}\nВыберите другое устройство.")
            continue
        peak = float(np.abs(data).max())
        print(f"Пиковый уровень: {peak:.0%}. Воспроизвожу...")
        try:
            sd.play(data[:, 0], SR)
            sd.wait()
        except Exception as e:
            print(f"Не удалось воспроизвести: {e}")
        if ask("Слышно себя?"):
            cfg["input_device"] = device
            return True
        print("Хорошо, попробуем другое устройство.")


def test_dictation(cfg, transcriber):
    from recorder import Recorder
    rec = Recorder(cfg.get("input_device"))
    done = threading.Event()
    result = {}

    def on_start():
        try:
            rec.start()
            print("\n>>> ЗАПИСЬ ПОШЛА — говорите. Одно нажатие "
                  f"{cfg.get('hotkey', 'alt').upper()} — стоп.")
        except Exception as e:
            print(f"Не удалось начать запись: {e}")
            done.set()

    def on_stop():
        audio = rec.stop()
        print(f"Записано {len(audio) / SR:.1f} c, распознаю (это займёт время)...")
        t0 = time.monotonic()
        try:
            result["text"] = transcriber.transcribe(audio)
            result["sec"] = time.monotonic() - t0
        except Exception:
            log.exception("Ошибка распознавания в мастере")
        done.set()

    key = cfg.get("hotkey", "alt").upper()
    print(f"\nТест диктовки: нажмите {key} ДВА раза подряд, скажите фразу,")
    print(f"затем нажмите {key} ОДИН раз. (Жду до 2 минут.)")
    listener = None
    try:
        from hotkey_fsm import HotkeyFSM
        from win_hotkeys import HotkeyListener
        fsm = HotkeyFSM(
            double_press_sec=cfg.get("double_press_interval_ms", 400) / 1000,
            debounce_sec=cfg.get("debounce_ms", 500) / 1000)
        listener = HotkeyListener(fsm, cfg, on_start=on_start, on_stop=on_stop)
        listener.start()
        finished = done.wait(timeout=120)
    except Exception as e:
        log.exception("Хоткеи недоступны")
        print(f"Не удалось поставить хук клавиатуры: {e}")
        print("Запасной вариант без хоткеев:")
        input("Нажмите Enter и начинайте говорить...")
        on_start()
        input("Нажмите Enter, чтобы остановить...")
        on_stop()
        finished = True
    finally:
        if listener:
            listener.stop()
    if finished and result.get("text"):
        print(f"\nРаспознано за {result['sec']:.1f} c: {result['text']}")
        return True
    if not finished:
        print("Не дождался диктовки — пропускаю этот шаг (проверите потом).")
    return False


_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_LINUX_AUTOSTART = Path.home() / ".config/autostart/panda-voice.desktop"


def _ensure_icon():
    """assets/panda.ico для ярлыков Windows; вернуть путь или None."""
    try:
        import branding
        ico = APP_DIR / "assets" / "panda.ico"
        if not ico.exists():
            ico.parent.mkdir(exist_ok=True)
            branding.save_ico(ico)
        return ico
    except Exception:
        log.exception("Не удалось создать panda.ico")
        return None


def ensure_launcher():
    """venv\\Scripts\\PandaVoice.exe — копия pythonw.exe под своим именем.

    Антивирус (Kaspersky и подобные) запоминает разрешение для КОНКРЕТНОГО
    исполняемого файла. Пока приложение стартовало безликим pythonw.exe,
    «запомнить выбор» не срабатывало: у интерпретатора нет своей личности,
    а путь скрипта менялся с каждой версией. Копия лежит РЯДОМ с pythonw.exe
    внутри venv (иначе не найдётся pyvenv.cfg и пропадут пакеты) и переживает
    обновления — updater папку venv не трогает.

    Возвращает путь к лаунчеру, None — если создать не удалось."""
    if sys.platform != "win32":
        return None
    src = Path(sys.executable).with_name("pythonw.exe")
    dst = src.with_name("PandaVoice.exe")
    try:
        if not src.exists():
            return None
        if not dst.exists() or dst.stat().st_size != src.stat().st_size:
            import shutil
            shutil.copy2(src, dst)
            log.info("Создан собственный лаунчер %s", dst)
        return dst
    except Exception:
        log.exception("Не удалось создать PandaVoice.exe — останусь на pythonw")
        return None


def _make_lnk(lnk_path):
    """Ярлык Windows на PandaVoice.exe main.py (без консоли), с иконкой."""
    pythonw = ensure_launcher() or Path(sys.executable).with_name("pythonw.exe")
    ico = _ensure_icon()
    icon_line = f"$s.IconLocation = '{ico}'; " if ico else ""
    ps = (
        "$ws = New-Object -ComObject WScript.Shell; "
        f"$s = $ws.CreateShortcut('{lnk_path}'); "
        f"$s.TargetPath = '{pythonw}'; "
        "$s.Arguments = 'main.py'; "
        f"$s.WorkingDirectory = '{APP_DIR}'; "
        f"{icon_line}"
        "$s.Save()"
    )
    subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                   check=True, timeout=120, creationflags=_NO_WINDOW)


def _linux_desktop_entry():
    icon = APP_DIR / "assets" / "panda.png"
    try:
        if not icon.exists():
            import branding
            icon.parent.mkdir(exist_ok=True)
            branding.save_png(icon)
    except Exception:
        pass
    return ("[Desktop Entry]\nType=Application\nName=Panda Voice\n"
            f"Exec={Path(sys.executable)} {APP_DIR / 'main.py'}\nPath={APP_DIR}\n"
            f"Icon={icon}\nTerminal=false\n")


def autostart_path():
    return (Path(os.environ.get("APPDATA", ""))
            / "Microsoft/Windows/Start Menu/Programs/Startup/Panda Voice.lnk")


def autostart_enabled():
    try:
        if sys.platform == "win32":
            return autostart_path().exists()
        return _LINUX_AUTOSTART.exists()
    except Exception:
        return False


def autostart_target_dir():
    """Папка, на которую СЕЙЧАС указывает автозапуск (None — его нет).

    Ярлык автозапуска создаётся с абсолютным путём: если приложение потом
    переустановили в другую папку, при входе в Windows стартует СТАРАЯ копия
    (и занимает порт одиночного запуска, из-за чего новая молча выходит)."""
    try:
        if sys.platform == "win32":
            lnk = autostart_path()
            if not lnk.exists():
                return None
            out = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; "
                 "$ws = New-Object -ComObject WScript.Shell; "
                 f"$ws.CreateShortcut('{lnk}').WorkingDirectory"],
                capture_output=True, timeout=60, creationflags=_NO_WINDOW)
            path = out.stdout.decode("utf-8", "replace").strip()
            return Path(path) if path else None
        if not _LINUX_AUTOSTART.exists():
            return None
        for line in _LINUX_AUTOSTART.read_text(encoding="utf-8").splitlines():
            if line.startswith("Path="):
                return Path(line[5:].strip())
        return None
    except Exception:
        log.exception("Не удалось прочитать путь автозапуска")
        return None


def disable_autostart():
    if sys.platform == "win32":
        autostart_path().unlink(missing_ok=True)
        # ярлык старого имени из ранних версий
        autostart_path().with_name("Диктовка.lnk").unlink(missing_ok=True)
    else:
        _LINUX_AUTOSTART.unlink(missing_ok=True)


def enable_autostart():
    if sys.platform == "win32":
        _make_lnk(autostart_path())  # тот же путь, что проверяет autostart_enabled
    else:
        _LINUX_AUTOSTART.parent.mkdir(parents=True, exist_ok=True)
        _LINUX_AUTOSTART.write_text(_linux_desktop_entry(), encoding="utf-8")


def make_desktop_shortcut():
    """Ярлык Panda Voice на рабочем столе. Вызывается из install.bat через
    python: bat-файлы обязаны быть ASCII, а Python передаёт юникод корректно."""
    if sys.platform != "win32":
        return  # на Linux ярлык создаёт install.sh
    # ВАЖНО: вывод PowerShell читаем строго в UTF-8 (сначала переключив его
    # OutputEncoding): с text=True путь с кириллицей (русское имя
    # пользователя, «Рабочий стол» в OneDrive) декодировался ANSI/OEM-
    # кодировкой в кракозябры, и ярлык молча не создавался.
    out = subprocess.run(
        ["powershell", "-NoProfile", "-Command",
         "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; "
         "[Environment]::GetFolderPath('Desktop')"],
        capture_output=True, timeout=60, creationflags=_NO_WINDOW)
    desktop = Path(out.stdout.decode("utf-8", "replace").strip()
                   or (Path.home() / "Desktop"))
    _make_lnk(desktop / "Panda Voice.lnk")


def run(cfg):
    print("=" * 60)
    print(" Мастер настройки Panda Voice")
    print("=" * 60)

    if not pick_microphone(cfg):
        return
    appconfig.save(cfg)

    print("\nЗагружаю модель распознавания (может занять минуту-другую)...")
    import asr
    transcriber = asr.load_transcriber(cfg)
    print("Модель загружена.")

    test_dictation(cfg, transcriber)

    if ask("\nДобавить Panda Voice в автозагрузку?", default_yes=False):
        try:
            enable_autostart()
            print("Готово: ярлык добавлен в автозагрузку.")
        except Exception as e:
            print(f"Не получилось ({e}) — можно добавить позже вручную (см. README).")

    cfg["setup_done"] = True
    appconfig.save(cfg)
    print("\nНастройка завершена! Запускайте Panda Voice ярлыком на рабочем столе.")
    print("Шпаргалка: 2×Alt — начать запись, 1×Alt — остановить и вставить текст.")
